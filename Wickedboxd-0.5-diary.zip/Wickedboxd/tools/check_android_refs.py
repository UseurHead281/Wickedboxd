#!/usr/bin/env python3
"""Cross-reference checks that a compiler/linter would do, runnable without the Android SDK.

  1. every R.<type>.<name> in Kotlin and every @type/name in XML exists
  2. every WbIcons.<Name> used in Kotlin is declared in WbIcon.kt
  3. stringResource(R.string.x, a, b)  passes as many arguments as the string has placeholders
  4. russian and english string / plurals resources match (same names)
  5. every activity-alias in the manifest has an AppIconVariant, and vice versa; each alias icon exists
Exit code 1 on any problem.
"""
from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAIN = ROOT / "app/src/main"
problems: list[str] = []


def bad(msg: str) -> None:
    problems.append(msg)


# ------------------------------------------------------------------ resource inventory
res: dict[str, set[str]] = {}
for p in (MAIN / "res").rglob("*"):
    if p.is_file():
        rtype = p.relative_to(MAIN / "res").parts[0].split("-")[0]
        res.setdefault(rtype, set()).add(p.stem)

strings: dict[str, dict[str, str]] = {"ru": {}, "en": {}}
plurals: dict[str, set[str]] = {"ru": set(), "en": set()}
for lang, folder in (("ru", "values"), ("en", "values-en")):
    for xml in (MAIN / "res" / folder).glob("*.xml"):
        for el in ET.parse(xml).getroot():
            name = el.attrib.get("name", "").replace(".", "_")
            if el.tag == "string":
                strings[lang][name] = el.text or ""
                res.setdefault("string", set()).add(name)
            elif el.tag == "plurals":
                plurals[lang].add(name)
                res.setdefault("plurals", set()).add(name)
            elif el.tag in ("color", "style"):
                res.setdefault(el.tag, set()).add(name)

sources = [p for p in (ROOT / "app/src").glob("*/java/**/*.kt")]
code = {p: re.sub(r"//[^\n]*|/\*.*?\*/", "", p.read_text(encoding="utf-8"), flags=re.S) for p in sources}

# 1) R references
for p, text in code.items():
    for t, n in re.findall(r"\bR\.(\w+)\.(\w+)", text):
        if n not in res.get(t, set()):
            bad(f"{p.name}: R.{t}.{n} does not exist")
xml_files = [MAIN / "AndroidManifest.xml", *(MAIN / "res").rglob("*.xml")]
for p in xml_files:
    for t, n in re.findall(r"@(\w+)/([\w.]+)", p.read_text(encoding="utf-8")):
        if t != "android" and n.replace(".", "_") not in res.get(t, set()):
            bad(f"{p.relative_to(ROOT)}: @{t}/{n} does not exist")

# 2) WbIcons members
icon_src = (ROOT / "app/src/main/java/com/wickedboxd/app/core/designsystem/icon/WbIcon.kt").read_text(encoding="utf-8")
declared = set(re.findall(r"^\s+val (\w+) = R\.drawable\.", icon_src, re.M))
for p, text in code.items():
    for n in re.findall(r"\bWbIcons\.(\w+)", text):
        if n not in declared:
            bad(f"{p.name}: WbIcons.{n} is not declared")

# 3) placeholder counts
def placeholders(s: str) -> int:
    idx = [int(m) for m in re.findall(r"%(\d+)\$", s)]
    return max(idx) if idx else len(re.findall(r"%[sd]", s))

for p, text in code.items():
    for m in re.finditer(r"stringResource\(\s*(?:if \([^)]*\) )?R\.string\.(\w+)((?:\s*,\s*[^,()]+(?:\([^)]*\))?)*)\s*\)", text):
        name, rest = m.group(1), m.group(2)
        args = len([a for a in re.split(r",", rest) if a.strip()])
        for lang in ("ru", "en"):
            if name in strings[lang] and placeholders(strings[lang][name]) != args:
                bad(f"{p.name}: stringResource(R.string.{name}) passes {args} arg(s) but the {lang} text has {placeholders(strings[lang][name])} placeholder(s)")

# 4) ru / en parity
for n in sorted(set(strings["ru"]) ^ set(strings["en"])):
    bad(f"string '{n}' exists in only one of values/ and values-en/")
for n in sorted(plurals["ru"] ^ plurals["en"]):
    bad(f"plurals '{n}' exists in only one of values/ and values-en/")
for lang in ("ru", "en"):
    for n, s in strings[lang].items():
        if placeholders(strings["ru"].get(n, s)) != placeholders(strings["en"].get(n, s)):
            bad(f"string '{n}': ru and en have a different number of placeholders")

# 5) launcher aliases <-> AppIconVariant
manifest = (MAIN / "AndroidManifest.xml").read_text(encoding="utf-8")
aliases = set(re.findall(r'<activity-alias\s+android:name="\.alias\.(\w+)"', manifest))
variants = set(re.findall(r'^\s+(\w+)\("\.alias\.(\w+)"\)', (MAIN / "java/com/wickedboxd/app/domain/model/AppSettings.kt").read_text(encoding="utf-8"), re.M))
variant_aliases = {a for _, a in variants}
if aliases != variant_aliases:
    bad(f"manifest aliases {sorted(aliases)} != AppIconVariant aliases {sorted(variant_aliases)}")
for icon in re.findall(r'android:icon="@mipmap/(\w+)"', manifest):
    if icon not in res.get("mipmap", set()):
        bad(f"manifest icon @mipmap/{icon} missing")

if problems:
    print(f"{len(problems)} problem(s):")
    for p in problems:
        print("  -", p)
    sys.exit(1)
print(f"OK - {sum(len(v) for v in code.values()) // 1000}k chars of Kotlin, {len(res.get('string', []))} strings, "
      f"{len(res.get('drawable', []))} drawables, {len(aliases)} launcher aliases: all references resolve.")
