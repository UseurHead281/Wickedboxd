"""Parse the supplied SVG files into a flat list of styled shapes.

Supports exactly what the Wickedboxd packs use: <svg>, <g>, <path>, <circle>, <rect>,
<linearGradient>, transform=translate()/scale(), opacity, fill-rule and the inherited
fill/stroke properties. Anything else fails loudly instead of being silently dropped.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path

from .pathgeom import closed, fmt

SVG_NS = "http://www.w3.org/2000/svg"
ET.register_namespace("", SVG_NS)
_UNSET = "<unset>"


def _t(tag: str) -> str:
    return f"{{{SVG_NS}}}{tag}"


@dataclass
class Gradient:
    x1: float
    y1: float
    x2: float
    y2: float
    units: str  # objectBoundingBox | userSpaceOnUse
    stops: list[tuple[float, str, float]]  # offset, #RRGGBB, opacity


@dataclass
class Shape:
    d: str
    fill: str | None
    stroke: str | None
    stroke_width: float = 1.0
    linecap: str = "butt"
    linejoin: str = "miter"
    fill_rule: str = "nonzero"
    opacity: float = 1.0
    transforms: list[tuple[str, list[float]]] = field(default_factory=list)  # outermost first
    filtered: bool = False  # uses an SVG filter (glow) -> cannot be a VectorDrawable


@dataclass
class SvgDoc:
    source: Path
    width: float
    height: float
    background: str | None  # colour of the full-bleed "plate" rect, if requested
    shapes: list[Shape]
    gradients: dict[str, Gradient]

    @property
    def needs_raster(self) -> bool:
        return any(s.filtered for s in self.shapes)


def paint(value: str) -> str | None:
    v = value.strip()
    if v == "none":
        return None
    if v.lower() == "currentcolor":
        return "#FFFFFF"  # tinted at runtime by Icon(tint = ...)
    if v.startswith("url("):
        return v
    m = re.fullmatch(r"#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})", v)
    if not m:
        raise ValueError(f"unsupported paint {value!r}")
    h = m.group(1)
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return "#" + h.upper()


def _num(v: str) -> float:
    return float(v[:-1]) / 100 if v.endswith("%") else float(v)


def parse_transform(s: str | None) -> list[tuple[str, list[float]]]:
    out = []
    for m in re.finditer(r"(translate|scale|rotate|matrix|skewX|skewY)\s*\(([^)]*)\)", s or ""):
        args = [float(a) for a in re.split(r"[\s,]+", m.group(2).strip()) if a]
        out.append((m.group(1), args))
    return out


def circle_d(cx: float, cy: float, r: float) -> str:
    return (f"M{fmt(cx - r)} {fmt(cy)}a{fmt(r)} {fmt(r)} 0 1 0 {fmt(2 * r)} 0"
            f"a{fmt(r)} {fmt(r)} 0 1 0 {fmt(-2 * r)} 0Z")


def rect_d(x: float, y: float, w: float, h: float, rx: float, ry: float) -> str:
    if rx == 0 and ry == 0:
        return f"M{fmt(x)} {fmt(y)}h{fmt(w)}v{fmt(h)}h{fmt(-w)}Z"
    return (f"M{fmt(x + rx)} {fmt(y)}H{fmt(x + w - rx)}"
            f"A{fmt(rx)} {fmt(ry)} 0 0 1 {fmt(x + w)} {fmt(y + ry)}V{fmt(y + h - ry)}"
            f"A{fmt(rx)} {fmt(ry)} 0 0 1 {fmt(x + w - rx)} {fmt(y + h)}H{fmt(x + rx)}"
            f"A{fmt(rx)} {fmt(ry)} 0 0 1 {fmt(x)} {fmt(y + h - ry)}V{fmt(y + ry)}"
            f"A{fmt(rx)} {fmt(ry)} 0 0 1 {fmt(x + rx)} {fmt(y)}Z")


def _read_gradients(root: ET.Element) -> dict[str, Gradient]:
    out = {}
    for g in root.iter(_t("linearGradient")):
        stops = [
            (_num(s.attrib["offset"]), paint(s.attrib["stop-color"]) or "#000000",
             float(s.attrib.get("stop-opacity", 1)))
            for s in g.findall(_t("stop"))
        ]
        out[g.attrib["id"]] = Gradient(
            _num(g.attrib.get("x1", "0")), _num(g.attrib.get("y1", "0")),
            _num(g.attrib.get("x2", "1")), _num(g.attrib.get("y2", "0")),
            g.attrib.get("gradientUnits", "objectBoundingBox"), stops)
    return out


_INHERITED = ("fill", "stroke", "stroke-width", "stroke-linecap", "stroke-linejoin", "fill-rule")


def load_svg(path: Path, *, plate_is_background: bool = False) -> SvgDoc:
    root = ET.parse(path).getroot()
    vb = [float(v) for v in root.attrib["viewBox"].split()]
    doc = SvgDoc(path, vb[2], vb[3], None, [], _read_gradients(root))
    base = {"fill": _UNSET, "stroke": "none", "stroke-width": "1", "stroke-linecap": "butt",
            "stroke-linejoin": "miter", "fill-rule": "nonzero"}

    def walk(el: ET.Element, style: dict, transforms: list, opacity: float, filtered: bool) -> None:
        tag = el.tag.split("}")[-1]
        if tag in ("defs", "title", "desc", "linearGradient", "stop"):
            return
        st = {**style, **{k: el.attrib[k] for k in _INHERITED if k in el.attrib}}
        tr = transforms + parse_transform(el.attrib.get("transform"))
        op = opacity * float(el.attrib.get("opacity", 1))
        fl = filtered or "filter" in el.attrib
        if tag in ("svg", "g"):
            for child in el:
                walk(child, st, tr, op, fl)
            return
        if tag == "rect" and plate_is_background and tr == [] and \
                float(el.attrib.get("width", 0)) == doc.width and float(el.attrib.get("height", 0)) == doc.height:
            doc.background = paint(st["fill"])
            return
        if tag == "path":
            d = el.attrib["d"]
        elif tag == "circle":
            d = circle_d(float(el.attrib.get("cx", 0)), float(el.attrib.get("cy", 0)), float(el.attrib["r"]))
        elif tag == "rect":
            rx = float(el.attrib.get("rx", el.attrib.get("ry", 0)))
            ry = float(el.attrib.get("ry", rx))
            d = rect_d(float(el.attrib.get("x", 0)), float(el.attrib.get("y", 0)),
                       float(el.attrib["width"]), float(el.attrib["height"]), rx, ry)
        else:
            raise ValueError(f"unsupported element <{tag}> in {path.name}")
        fill = paint(st["fill"]) if st["fill"] != _UNSET else ("#000000" if closed(d) else None)
        doc.shapes.append(Shape(
            d=d, fill=fill, stroke=paint(st["stroke"]), stroke_width=float(st["stroke-width"]),
            linecap=st["stroke-linecap"], linejoin=st["stroke-linejoin"], fill_rule=st["fill-rule"],
            opacity=op, transforms=tr, filtered=fl))

    walk(root, base, [], 1.0, False)
    return doc
