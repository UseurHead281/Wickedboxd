"""Minimal SVG path geometry: flatten a path to sample points, bbox, transforms.

Only what the Wickedboxd pipeline needs (fit-to-safe-zone, gradient bbox).
Limitation: arc flags must be separated by whitespace/commas ("a1 1 0 1 0 2 0"),
which is how every file in the supplied packs is written.
"""
from __future__ import annotations

import math
import re

Point = tuple[float, float]

_TOKEN = re.compile(r"[MmLlHhVvCcSsQqTtAaZz]|[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?")
_CMD = re.compile(r"[MmLlHhVvCcSsQqTtAaZz]")


def fmt(v: float, digits: int = 4) -> str:
    """Compact number formatting: 1.0 -> '1', 0.1700 -> '0.17', -0.0 -> '0'."""
    s = f"{v:.{digits}f}".rstrip("0").rstrip(".")
    return "0" if s in ("", "-0") else s


def closed(d: str) -> bool:
    return bool(re.search(r"[zZ]", d))


def _cubic(p0: Point, p1: Point, p2: Point, p3: Point, n: int) -> list[Point]:
    out = []
    for k in range(1, n + 1):
        t = k / n
        m = 1 - t
        out.append((
            m**3 * p0[0] + 3 * m * m * t * p1[0] + 3 * m * t * t * p2[0] + t**3 * p3[0],
            m**3 * p0[1] + 3 * m * m * t * p1[1] + 3 * m * t * t * p2[1] + t**3 * p3[1],
        ))
    return out


def _quad(p0: Point, p1: Point, p2: Point, n: int) -> list[Point]:
    out = []
    for k in range(1, n + 1):
        t = k / n
        m = 1 - t
        out.append((
            m * m * p0[0] + 2 * m * t * p1[0] + t * t * p2[0],
            m * m * p0[1] + 2 * m * t * p1[1] + t * t * p2[1],
        ))
    return out


def _arc(p1: Point, rx: float, ry: float, phi: float, fa: int, fs: int, p2: Point, n: int) -> list[Point]:
    """SVG elliptical arc (spec F.6.5) sampled at n points."""
    (x1, y1), (x2, y2) = p1, p2
    if rx == 0 or ry == 0 or (x1 == x2 and y1 == y2):
        return [p2]
    rx, ry = abs(rx), abs(ry)
    cp, sp = math.cos(math.radians(phi)), math.sin(math.radians(phi))
    dx, dy = (x1 - x2) / 2, (y1 - y2) / 2
    x1p, y1p = cp * dx + sp * dy, -sp * dx + cp * dy
    lam = x1p**2 / rx**2 + y1p**2 / ry**2
    if lam > 1:
        s = math.sqrt(lam)
        rx, ry = rx * s, ry * s
    num = rx**2 * ry**2 - rx**2 * y1p**2 - ry**2 * x1p**2
    den = rx**2 * y1p**2 + ry**2 * x1p**2
    co = math.sqrt(max(0.0, num / den)) * (-1 if fa == fs else 1)
    cxp, cyp = co * rx * y1p / ry, -co * ry * x1p / rx
    cx = cp * cxp - sp * cyp + (x1 + x2) / 2
    cy = sp * cxp + cp * cyp + (y1 + y2) / 2

    def ang(ux, uy, vx, vy):
        return math.atan2(ux * vy - uy * vx, ux * vx + uy * vy)

    th1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    dth = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry)
    if not fs and dth > 0:
        dth -= 2 * math.pi
    elif fs and dth < 0:
        dth += 2 * math.pi
    out = []
    for k in range(1, n + 1):
        th = th1 + dth * k / n
        out.append((
            cp * rx * math.cos(th) - sp * ry * math.sin(th) + cx,
            sp * rx * math.cos(th) + cp * ry * math.sin(th) + cy,
        ))
    return out


def sample_path(d: str, steps: int = 32) -> list[Point]:
    """Flatten path data to a list of points (curves sampled `steps` times)."""
    t = _TOKEN.findall(d)
    i = 0
    pts: list[Point] = []
    x = y = sx = sy = 0.0
    cmd = ""
    last_c: Point | None = None  # last cubic control point (for S)
    last_q: Point | None = None  # last quadratic control point (for T)

    def nums(n: int) -> list[float]:
        nonlocal i
        vals = [float(t[i + k]) for k in range(n)]
        i += n
        return vals

    while i < len(t):
        if _CMD.fullmatch(t[i]):
            cmd = t[i]
            i += 1
            if cmd in "Zz":
                x, y = sx, sy
                pts.append((x, y))
                last_c = last_q = None
                continue
        up, rel = cmd.upper(), cmd.islower()
        ox, oy = (x, y) if rel else (0.0, 0.0)
        if up == "M":
            nx, ny = nums(2)
            x, y = nx + ox, ny + oy
            sx, sy = x, y
            pts.append((x, y))
            cmd = "l" if rel else "L"  # implicit lineto after moveto
            last_c = last_q = None
        elif up == "L":
            nx, ny = nums(2)
            x, y = nx + ox, ny + oy
            pts.append((x, y))
            last_c = last_q = None
        elif up == "H":
            (nx,) = nums(1)
            x = nx + ox
            pts.append((x, y))
            last_c = last_q = None
        elif up == "V":
            (ny,) = nums(1)
            y = ny + oy
            pts.append((x, y))
            last_c = last_q = None
        elif up == "C":
            x1, y1, x2, y2, nx, ny = nums(6)
            c1, c2, e = (x1 + ox, y1 + oy), (x2 + ox, y2 + oy), (nx + ox, ny + oy)
            pts += _cubic((x, y), c1, c2, e, steps)
            x, y = e
            last_c, last_q = c2, None
        elif up == "S":
            x2, y2, nx, ny = nums(4)
            c1 = (2 * x - last_c[0], 2 * y - last_c[1]) if last_c else (x, y)
            c2, e = (x2 + ox, y2 + oy), (nx + ox, ny + oy)
            pts += _cubic((x, y), c1, c2, e, steps)
            x, y = e
            last_c, last_q = c2, None
        elif up == "Q":
            x1, y1, nx, ny = nums(4)
            c1, e = (x1 + ox, y1 + oy), (nx + ox, ny + oy)
            pts += _quad((x, y), c1, e, steps)
            x, y = e
            last_q, last_c = c1, None
        elif up == "T":
            nx, ny = nums(2)
            c1 = (2 * x - last_q[0], 2 * y - last_q[1]) if last_q else (x, y)
            e = (nx + ox, ny + oy)
            pts += _quad((x, y), c1, e, steps)
            x, y = e
            last_q, last_c = c1, None
        elif up == "A":
            rx, ry, phi, fa, fs, nx, ny = nums(7)
            e = (nx + ox, ny + oy)
            pts += _arc((x, y), rx, ry, phi, int(fa), int(fs), e, steps)
            x, y = e
            last_c = last_q = None
        else:  # pragma: no cover
            raise ValueError(f"unsupported path command {cmd!r}")
    return pts


def bbox(points: list[Point]) -> tuple[float, float, float, float]:
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return min(xs), min(ys), max(xs), max(ys)


def apply_transforms(points: list[Point], transforms: list[tuple[str, list[float]]]) -> list[Point]:
    """Apply an SVG transform list (outermost first) to points."""
    out = points
    for kind, a in reversed(transforms):  # rightmost transform touches the point first
        if kind == "translate":
            tx, ty = a[0], (a[1] if len(a) > 1 else 0.0)
            out = [(px + tx, py + ty) for px, py in out]
        elif kind == "scale":
            sx_, sy_ = a[0], (a[1] if len(a) > 1 else a[0])
            out = [(px * sx_, py * sy_) for px, py in out]
        else:
            raise NotImplementedError(f"transform {kind!r}")
    return out
