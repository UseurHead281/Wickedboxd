"""Emit Android VectorDrawable XML from the shape model.

Path data is copied verbatim (VectorDrawable uses the SVG path grammar), so contours are
never redrawn or simplified. Circles/rects, which VectorDrawable lacks, were already turned
into exact arc paths by model.py.
"""
from __future__ import annotations

from .model import Gradient, Shape
from .pathgeom import bbox, fmt, sample_path

_ANDROID = 'xmlns:android="http://schemas.android.com/apk/res/android"'
_AAPT = 'xmlns:aapt="http://schemas.android.com/aapt"'
_STEP = "    "

Fit = tuple[float, float, float]  # translateX, translateY, uniform scale


def _argb(hex_rgb: str, alpha: float = 1.0) -> str:
    return f"#{round(alpha * 255):02X}{hex_rgb.lstrip('#').upper()}"


def _gradient_lines(g: Gradient, sh: Shape, ind: str) -> list[str]:
    """Gradient in path-local user space.

    objectBoundingBox gradients are converted exactly: the bbox-normalised ramp is an affine
    function of (x, y), so an equivalent user-space start/end pair always exists.
    """
    if g.units == "objectBoundingBox":
        minx, miny, maxx, maxy = bbox(sample_path(sh.d))
        w, h = maxx - minx, maxy - miny
        dx, dy = g.x2 - g.x1, g.y2 - g.y1
        ln = dx * dx + dy * dy
        ax, ay = dx / (w * ln), dy / (h * ln)  # gradient of t w.r.t. x and y
        n2 = ax * ax + ay * ay
        sx, sy = minx + g.x1 * w, miny + g.y1 * h
        ex, ey = sx + ax / n2, sy + ay / n2
    else:
        sx, sy, ex, ey = g.x1, g.y1, g.x2, g.y2
    lines = [
        f'{ind}<aapt:attr name="android:fillColor">',
        f'{ind}{_STEP}<gradient',
        f'{ind}{_STEP * 3}android:type="linear"',
        f'{ind}{_STEP * 3}android:startX="{fmt(sx)}"',
        f'{ind}{_STEP * 3}android:startY="{fmt(sy)}"',
        f'{ind}{_STEP * 3}android:endX="{fmt(ex)}"',
        f'{ind}{_STEP * 3}android:endY="{fmt(ey)}">',
    ]
    for offset, color, op in g.stops:
        lines.append(f'{ind}{_STEP * 2}<item android:offset="{fmt(offset)}" android:color="{_argb(color, op)}"/>')
    lines += [f"{ind}{_STEP}</gradient>", f"{ind}</aapt:attr>"]
    return lines


def _path_lines(sh: Shape, gradients: dict[str, Gradient], ind: str) -> list[str]:
    attrs = [f'android:pathData="{sh.d}"']
    gradient: Gradient | None = None
    if sh.fill:
        if sh.fill.startswith("url("):
            gradient = gradients[sh.fill[5:-1]]
        else:
            attrs.append(f'android:fillColor="{_argb(sh.fill)}"')
        if sh.fill_rule == "evenodd":
            attrs.append('android:fillType="evenOdd"')
    if sh.stroke:
        if sh.stroke.startswith("url("):
            raise ValueError("gradient strokes are not supported")
        attrs.append(f'android:strokeColor="{_argb(sh.stroke)}"')
        attrs.append(f'android:strokeWidth="{fmt(sh.stroke_width)}"')
        if sh.linecap != "butt":
            attrs.append(f'android:strokeLineCap="{sh.linecap}"')
        if sh.linejoin != "miter":
            attrs.append(f'android:strokeLineJoin="{sh.linejoin}"')
    if sh.opacity < 1:
        if sh.fill:
            attrs.append(f'android:fillAlpha="{fmt(sh.opacity)}"')
        if sh.stroke:
            attrs.append(f'android:strokeAlpha="{fmt(sh.opacity)}"')
    tag_open = f"{ind}<path"
    body = "".join(f"\n{ind}{_STEP * 2}{a}" for a in attrs)
    if gradient is None:
        return [f"{tag_open}{body}/>"]
    return [f"{tag_open}{body}>", *_gradient_lines(gradient, sh, ind + _STEP), f"{ind}</path>"]


def _group_open(transforms: list[tuple[str, list[float]]], ind: str) -> tuple[list[str], list[str], str]:
    opens, closes = [], []
    for kind, a in transforms:
        if kind == "translate":
            attrs = f'android:translateX="{fmt(a[0])}" android:translateY="{fmt(a[1] if len(a) > 1 else 0)}"'
        elif kind == "scale":
            attrs = f'android:scaleX="{fmt(a[0])}" android:scaleY="{fmt(a[1] if len(a) > 1 else a[0])}"'
        else:
            raise NotImplementedError(kind)
        opens.append(f"{ind}<group {attrs}>")
        closes.insert(0, f"{ind}</group>")
        ind += _STEP
    return opens, closes, ind


def emit_vector(shapes: list[Shape], gradients: dict[str, Gradient], *, width_dp: float, height_dp: float,
                vp_w: float, vp_h: float, fit: Fit | None = None, comment: str = "") -> str:
    uses_gradient = any(s.fill and s.fill.startswith("url(") for s in shapes)
    out = ['<?xml version="1.0" encoding="utf-8"?>']
    if comment:
        out.append(f"<!-- {comment} -->")
    out += [
        "<vector " + _ANDROID + ("\n    " + _AAPT if uses_gradient else ""),
        f'    android:width="{fmt(width_dp)}dp"',
        f'    android:height="{fmt(height_dp)}dp"',
        f'    android:viewportWidth="{fmt(vp_w)}"',
        f'    android:viewportHeight="{fmt(vp_h)}">',
    ]
    ind = _STEP
    fit_close: list[str] = []
    if fit:
        tx, ty, s = fit
        opens, fit_close, ind = _group_open([("translate", [tx, ty]), ("scale", [s])], ind)
        out += opens
    for sh in shapes:
        opens, closes, inner = _group_open(sh.transforms, ind)
        out += opens
        out += _path_lines(sh, gradients, inner)
        out += closes
    out += fit_close
    out.append("</vector>")
    return "\n".join(out) + "\n"
