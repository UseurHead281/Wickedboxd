"""Verification helpers: turn the *generated* VectorDrawable XML back into SVG and rasterise
it with headless Chromium, so the output can be compared pixel-by-pixel with the original SVG.
"""
from __future__ import annotations

import io
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image

_A = "{http://schemas.android.com/apk/res/android}"
_AAPT = "{http://schemas.android.com/aapt}"


def _f(el: ET.Element, name: str, default: str) -> str:
    return el.attrib.get(_A + name, default)


def vd_to_svg(xml_text: str, *, size_px: int | None = None, color_override: str | None = None) -> str:
    """Return a standalone <svg> element equivalent to the VectorDrawable."""
    root = ET.fromstring(xml_text)
    vw, vh = _f(root, "viewportWidth", "24"), _f(root, "viewportHeight", "24")
    defs: list[str] = []
    body: list[str] = []

    def paint(v: str) -> str:
        return color_override or "#" + v[3:]

    def walk(el: ET.Element) -> None:
        tag = el.tag
        if tag == "group":
            tx, ty = _f(el, "translateX", "0"), _f(el, "translateY", "0")
            sx, sy = _f(el, "scaleX", "1"), _f(el, "scaleY", "1")
            body.append(f'<g transform="translate({tx} {ty}) scale({sx} {sy})">')
            for c in el:
                walk(c)
            body.append("</g>")
        elif tag == "path":
            a = [f'd="{_f(el, "pathData", "")}"']
            grad = el.find(f"{_AAPT}attr/gradient")
            if grad is not None:
                gid = f"g{len(defs)}"
                stops = "".join(
                    f'<stop offset="{i.attrib[_A + "offset"]}" stop-color="#{i.attrib[_A + "color"][3:]}" '
                    f'stop-opacity="{int(i.attrib[_A + "color"][1:3], 16) / 255:.4f}"/>'
                    for i in grad)
                defs.append(
                    f'<linearGradient id="{gid}" gradientUnits="userSpaceOnUse" '
                    f'x1="{_f(grad, "startX", "0")}" y1="{_f(grad, "startY", "0")}" '
                    f'x2="{_f(grad, "endX", "0")}" y2="{_f(grad, "endY", "0")}">{stops}</linearGradient>')
                a.append(f'fill="url(#{gid})"')
            elif _A + "fillColor" in el.attrib:
                a.append(f'fill="{paint(_f(el, "fillColor", ""))}"')
            else:
                a.append('fill="none"')
            if _f(el, "fillType", "nonZero") == "evenOdd":
                a.append('fill-rule="evenodd"')
            if _A + "strokeColor" in el.attrib:
                a.append(f'stroke="{paint(_f(el, "strokeColor", ""))}"')
                a.append(f'stroke-width="{_f(el, "strokeWidth", "0")}"')
                a.append(f'stroke-linecap="{_f(el, "strokeLineCap", "butt")}"')
                a.append(f'stroke-linejoin="{_f(el, "strokeLineJoin", "miter")}"')
                if _A + "strokeAlpha" in el.attrib:
                    a.append(f'stroke-opacity="{_f(el, "strokeAlpha", "1")}"')
            if _A + "fillAlpha" in el.attrib:
                a.append(f'fill-opacity="{_f(el, "fillAlpha", "1")}"')
            body.append(f"<path {' '.join(a)}/>")

    for child in root:
        walk(child)
    size = f' width="{size_px}" height="{size_px}"' if size_px else ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg"{size} viewBox="0 0 {vw} {vh}">'
            f'<defs>{"".join(defs)}</defs>{"".join(body)}</svg>')


class Renderer:
    """Headless Chromium wrapper (one browser for the whole run)."""

    def __enter__(self) -> "Renderer":
        from playwright.sync_api import sync_playwright
        self._pw = sync_playwright().start()
        self._browser = self._pw.chromium.launch()
        return self

    def __exit__(self, *exc) -> None:
        self._browser.close()
        self._pw.stop()

    def shot(self, html: str, w: int, h: int, *, transparent: bool = False) -> Image.Image:
        page = self._browser.new_page(viewport={"width": w, "height": h}, device_scale_factor=1)
        page.set_content(
            "<html><body style='margin:0;padding:0;"
            f"background:{'transparent' if transparent else '#000'}'>{html}</body></html>")
        png = page.screenshot(clip={"x": 0, "y": 0, "width": w, "height": h}, omit_background=transparent)
        page.close()
        return Image.open(io.BytesIO(png)).convert("RGBA")


def diff_stats(a: Image.Image, b: Image.Image) -> tuple[float, int]:
    """Mean and max absolute per-channel difference (0-255) after flattening alpha on black."""
    def flat(img: Image.Image) -> np.ndarray:
        bg = Image.new("RGBA", img.size, (0, 0, 0, 255))
        return np.asarray(Image.alpha_composite(bg, img).convert("RGB"), dtype=np.int16)
    d = np.abs(flat(a) - flat(b))
    return float(d.mean()), int(d.max())
