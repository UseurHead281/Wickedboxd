#!/usr/bin/env python3
"""Static sanity checks for supabase/migrations/*.sql  (a stand-in for running them: no PostgreSQL needed).

It is NOT a SQL parser and cannot prove the migrations run - the real test is
supabase/tests/security_smoke_test.sql on a dev project. It catches the mistakes that are cheap to
catch mechanically:
  1. unbalanced quotes / parentheses / dollar-quotes
  2. statements that start with an unknown keyword (typos)
  3. references to public.<object> that is never created
  4. columns that do not exist in `grant ... (cols)` and `insert into public.t (cols)`
  5. tables without `enable row level security`
  6. SECURITY DEFINER functions without a pinned search_path
  7. policies without the matching `drop policy if exists` (re-runnability)
  8. functions granted in 0004 that do not exist / functions that are neither granted nor triggers
  9. secrets (service_role keys, JWTs) anywhere in the project
Exit code 1 if any hard error is found.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MIGRATIONS = sorted((ROOT / "supabase/migrations").glob("*.sql"))
errors: list[str] = []
notes: list[str] = []


def err(msg: str) -> None:
    errors.append(msg)


# ---------------------------------------------------------------- lexer
def lex(src: str, name: str, expand: bool = False) -> tuple[str, list[str]]:
    """Return (code with strings/comments blanked, list of dollar-quoted bodies); report unbalanced input.
    expand=True keeps (recursively lexed) dollar-quoted bodies inline instead of blanking them."""
    out: list[str] = []
    bodies: list[str] = []
    i, n = 0, len(src)
    depth = 0
    line = 1
    while i < n:
        c = src[i]
        if c == "\n":
            line += 1
        if src.startswith("--", i):
            j = src.find("\n", i)
            j = n if j == -1 else j
            out.append(" " * (j - i))
            i = j
            continue
        if src.startswith("/*", i):
            j = src.find("*/", i + 2)
            if j == -1:
                err(f"{name}:{line}: unterminated /* comment")
                break
            out.append(re.sub(r"[^\n]", " ", src[i:j + 2]))
            line += src[i:j + 2].count("\n")
            i = j + 2
            continue
        if c == "'":
            j = i + 1
            while True:
                if j >= n:
                    err(f"{name}:{line}: unterminated string literal")
                    break
                if src[j] == "'":
                    if j + 1 < n and src[j + 1] == "'":
                        j += 2
                        continue
                    break
                j += 1
            seg = src[i:j + 1]
            out.append("'" + re.sub(r"[^\n]", " ", seg[1:-1]) + "'")
            line += seg.count("\n")
            i = j + 1
            continue
        if c == '"':
            j = src.find('"', i + 1)
            if j == -1:
                err(f"{name}:{line}: unterminated quoted identifier")
                break
            out.append(src[i:j + 1])
            i = j + 1
            continue
        m = re.match(r"\$([A-Za-z_]*)\$", src[i:])
        if m:
            tag = m.group(0)
            j = src.find(tag, i + len(tag))
            if j == -1:
                err(f"{name}:{line}: dollar-quote {tag} is never closed")
                break
            body = src[i + len(tag):j]
            bodies.append(body)
            out.append(tag + (lex(body, name, True)[0] if expand else re.sub(r"[^\n]", " ", body)) + tag)
            line += body.count("\n")
            i = j + len(tag)
            continue
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
            if depth < 0:
                err(f"{name}:{line}: unmatched ')'")
                depth = 0
        out.append(c)
        i += 1
    if depth != 0:
        err(f"{name}: unbalanced parentheses (depth {depth} at end of file)")
    return "".join(out), bodies


def split_statements(code: str) -> list[str]:
    stmts, cur, depth, i = [], [], 0, 0
    while i < len(code):
        c = code[i]
        m = re.match(r"\$([A-Za-z_]*)\$", code[i:])
        if m:
            tag = m.group(0)
            j = code.find(tag, i + len(tag))
            cur.append(code[i:j + len(tag)])
            i = j + len(tag)
            continue
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        if c == ";" and depth == 0:
            stmts.append("".join(cur).strip())
            cur = []
        else:
            cur.append(c)
        i += 1
    tail = "".join(cur).strip()
    if tail:
        stmts.append(tail)
    return [s for s in stmts if s]


# ---------------------------------------------------------------- load everything
files: dict[str, str] = {}
codes: dict[str, str] = {}
expanded: dict[str, str] = {}
all_bodies: dict[str, list[str]] = {}
for p in MIGRATIONS + [ROOT / "supabase/tests/security_smoke_test.sql", ROOT / "supabase/seed_demo.sql"]:
    files[p.name] = p.read_text(encoding="utf-8")
    codes[p.name], all_bodies[p.name] = lex(files[p.name], p.name)
    _n = len(errors)
    expanded[p.name] = lex(files[p.name], p.name, True)[0]
    del errors[_n:]   # structural problems were already reported by the first pass

KNOWN = {"create", "alter", "drop", "insert", "do", "grant", "revoke", "select", "update", "delete", "with",
         "begin", "rollback", "reset", "set", "commit", "comment"}
for name, code in codes.items():
    for s in split_statements(code):
        kw = s.split(None, 1)[0].lower() if s.split() else ""
        if kw not in KNOWN:
            err(f"{name}: statement starts with unknown keyword {kw!r}: {s[:60]!r}")

# ---------------------------------------------------------------- object inventory
mig_code = "\n".join(codes[p.name] for p in MIGRATIONS)
mig_full = "\n".join(files[p.name] for p in MIGRATIONS)
tables = set(re.findall(r"create table if not exists public\.(\w+)", mig_code))
views = set(re.findall(r"create or replace view public\.(\w+)", mig_code))
functions = set(re.findall(r"create or replace function public\.(\w+)", mig_code))
types = set(re.findall(r"create type public\.(\w+)", mig_full))
objects = tables | views | functions | types
notes.append(f"inventory: {len(tables)} tables, {len(views)} views, {len(functions)} functions, {len(types)} types")

# 3) references to public.<x>
for p in MIGRATIONS + [ROOT / "supabase/tests/security_smoke_test.sql", ROOT / "supabase/seed_demo.sql"]:
    text = re.sub(r"--[^\n]*", "", files[p.name])
    for ref in set(re.findall(r"\bpublic\.([a-z_][a-z0-9_]*)", text)):
        if ref not in objects:
            err(f"{p.name}: reference to public.{ref} which is never created")

# ---------------------------------------------------------------- columns per table
columns: dict[str, set[str]] = {}
for m in re.finditer(r"create table if not exists public\.(\w+)\s*\((.*?)\n\);", mig_code, re.S):
    tname, body = m.group(1), m.group(2)
    items, depth, cur = [], 0, []
    for ch in body:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == "," and depth == 0:
            items.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    items.append("".join(cur))
    cols = set()
    for it in items:
        tok = it.strip().split(None, 1)
        if tok and tok[0].lower() not in {"constraint", "primary", "unique", "check", "foreign", "like"}:
            cols.add(tok[0].strip('"'))
    columns[tname] = cols
# the view columns are not needed; for every table make sure we parsed something
for t in tables:
    if not columns.get(t):
        err(f"could not parse columns of table {t}")

# 4a) grant (cols) on public.t
for m in re.finditer(r"grant\s+(?:insert|update|select)\s*\(([^)]*)\)\s*on\s+public\.(\w+)", mig_code, re.I):
    cols = [c.strip() for c in m.group(1).split(",")]
    for c in cols:
        if c not in columns.get(m.group(2), set()):
            err(f"0004: grant on public.{m.group(2)} names unknown column {c!r}")

# 4b) insert into public.t (cols)  (skip template tables used with %I)
for name in [p.name for p in MIGRATIONS] + ["security_smoke_test.sql", "seed_demo.sql"]:
    for m in re.finditer(r"insert\s+into\s+public\.(\w+)\s*\(([^)]*)\)", expanded[name], re.I):
        t = m.group(1)
        for c in [x.strip() for x in m.group(2).split(",")]:
            if c and c not in columns.get(t, set()):
                err(f"{name}: insert into public.{t} names unknown column {c!r}")

# 4c) update public.t set a = ..., b = ...   (assignment targets)
for name in [p.name for p in MIGRATIONS] + ["security_smoke_test.sql"]:
    for m in re.finditer(r"update\s+public\.(\w+)(?:\s+\w+)?\s+set\s+(.*?)(?:\s+where\b|\s+from\b|;)", expanded[name], re.I | re.S):
        t = m.group(1)
        depth, cur, parts = 0, [], []
        for ch in m.group(2):
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            if ch == "," and depth == 0:
                parts.append("".join(cur))
                cur = []
            else:
                cur.append(ch)
        parts.append("".join(cur))
        for part in parts:
            mm = re.match(r"\s*(\w+)\s*=", part)
            if mm and mm.group(1) not in columns.get(t, set()):
                err(f"{name}: update public.{t} sets unknown column {mm.group(1)!r}")

# ---------------------------------------------------------------- 5) RLS coverage
rls = set(re.findall(r"alter table public\.(\w+) enable row level security", mig_code))
for m in re.finditer(r"foreach \w+ in array array\[(.*?)\]\s+loop(.*?)end loop", mig_full, re.S):
    if "enable row level security" in m.group(2):
        rls |= set(re.findall(r"'(\w+)'", m.group(1)))
for t in sorted(tables - rls):
    err(f"table public.{t} has no `enable row level security`")
notes.append(f"RLS enabled on {len(rls & tables)}/{len(tables)} tables")

# ---------------------------------------------------------------- 6) security definer hygiene
for m in re.finditer(r"create or replace function public\.(\w+)\((.*?)\)\s*returns(.*?)\bas\s+\$", mig_code, re.S | re.I):
    header = m.group(0).lower()
    if "security definer" in header and "set search_path" not in header:
        err(f"function public.{m.group(1)} is SECURITY DEFINER without `set search_path`")

# ---------------------------------------------------------------- 7) policies re-runnable
for m in re.finditer(r"create policy (\w+) on (public\.\w+|storage\.objects)", mig_code):
    name, tbl = m.groups()
    if not re.search(rf"drop policy if exists {name} on {re.escape(tbl)}", mig_code):
        err(f"policy {name} on {tbl} has no matching `drop policy if exists`")
policy_names = re.findall(r"create policy (\w+) on", mig_code)
dups = {n for n in policy_names if policy_names.count(n) > 1}
if dups:
    err(f"duplicate policy names: {sorted(dups)}")

# ---------------------------------------------------------------- 8) grants vs functions
granted = set()
for m in re.finditer(r"v_(?:signed_in|anonymous) text\[\] := array\[(.*?)\]", mig_full, re.S):
    granted |= set(re.findall(r"'(\w+)'", m.group(1)))
for g in sorted(granted - functions):
    err(f"0004 grants execute on public.{g} which is never created")
trigger_fns = set()
for m in re.finditer(r"create or replace function public\.(\w+)\(\)\s*returns\s+trigger", mig_code, re.I):
    trigger_fns.add(m.group(1))
ungranted = sorted(functions - granted - trigger_fns)
notes.append(f"{len(trigger_fns)} trigger functions (no client grants), {len(granted & functions)} client-callable functions")
if ungranted:
    err(f"functions that are neither trigger functions nor granted: {ungranted}")

# ---------------------------------------------------------------- 9) secrets anywhere in the project
for path in ROOT.rglob("*"):
    if not path.is_file() or path.suffix in {".png", ".webp", ".jar", ".zip"} or "/design/" in path.as_posix() \
            or path.name in {"sql_static_check.py", "README.md"} or "/.gradle/" in path.as_posix():
        continue
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        continue
    if re.search(r"eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}", text):
        err(f"{path.relative_to(ROOT)}: looks like a JWT / API key")
    if path.suffix in {".kt", ".kts", ".xml", ".properties"}:
        code_only = re.sub(r"<!--.*?-->", "", text, flags=re.S)                     # xml comments
        code_only = re.sub(r"^\s*(//|#).*$", "", code_only, flags=re.M)             # whole-line comments
        code_only = re.sub(r"\s//.*$", "", code_only, flags=re.M)                  # trailing // comments
        if re.search(r"service[_-]?role", code_only, re.I):
            err(f"{path.relative_to(ROOT)}: uses service_role in app code (comments are ignored)")

# ---------------------------------------------------------------- report
for n in notes:
    print("note:", n)
if errors:
    print(f"\n{len(errors)} problem(s):")
    for e in errors:
        print("  -", e)
    sys.exit(1)
print("\nOK - no problems found by the static checks (this does not replace running the smoke test).")
