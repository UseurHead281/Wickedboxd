package com.wickedboxd.app.data.demo

import com.wickedboxd.app.core.config.BackendConfig
import com.wickedboxd.app.data.remote.auth.SupabaseAuthRepository
import com.wickedboxd.app.domain.repository.AuthRepository
import javax.inject.Inject
import javax.inject.Singleton

/** Debug builds: real Supabase Auth when local.properties is filled in, the in-memory demo otherwise. */
@Singleton
class DebugAuthRepository @Inject constructor(
    config: BackendConfig,
    remote: SupabaseAuthRepository,
    demo: DemoAuthRepository,
) : AuthRepository by (if (config.isConfigured) remote else demo)
