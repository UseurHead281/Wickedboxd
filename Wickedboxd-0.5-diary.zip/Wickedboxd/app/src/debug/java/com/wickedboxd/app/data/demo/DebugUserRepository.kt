package com.wickedboxd.app.data.demo

import com.wickedboxd.app.core.config.BackendConfig
import com.wickedboxd.app.data.remote.SupabaseUserRepository
import com.wickedboxd.app.domain.repository.UserRepository
import javax.inject.Inject
import javax.inject.Singleton

/** Debug builds: real Supabase when local.properties is filled in, demo data otherwise. */
@Singleton
class DebugUserRepository @Inject constructor(
    config: BackendConfig,
    remote: SupabaseUserRepository,
    demo: DemoUserRepository,
) : UserRepository by (if (config.isConfigured) remote else demo)
