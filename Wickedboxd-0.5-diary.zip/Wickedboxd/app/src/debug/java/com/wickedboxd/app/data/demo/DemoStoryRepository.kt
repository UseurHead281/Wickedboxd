package com.wickedboxd.app.data.demo

import com.wickedboxd.app.domain.model.CatalogSection
import com.wickedboxd.app.domain.model.Genre
import com.wickedboxd.app.domain.model.RatingBucket
import com.wickedboxd.app.domain.model.StoryCard
import com.wickedboxd.app.domain.model.StoryDetails
import com.wickedboxd.app.domain.model.Tag
import com.wickedboxd.app.domain.repository.StoryNotFoundException
import com.wickedboxd.app.domain.repository.StoryRepository
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.delay

/** Demo story + the names search matches against (genres in both languages, tags). */
class DemoSearchEntry(val card: StoryCard, val genreNames: List<String>, val tagNames: List<String>)

/**
 * DEMO DATA - lives in the `debug` source set only, so it can never ship in a release build.
 * Used by debug builds while no Supabase project is configured, to develop and review the UI.
 * Everything is fictional and prefixed "[DEMO]". State (rating, favourite, want-to-listen) is in memory.
 */
@Singleton
class DemoStoryRepository @Inject constructor() : StoryRepository {

    private class Demo(
        val id: String,
        val title: String,
        val author: String,
        val narrator: String,
        val year: Int,
        val genreIds: List<Int>,
        val tagIds: List<Int>,
        val votes: IntArray, // index 0 = 0.5 stars ... index 9 = 5.0 stars
        val reviews: Int,
        val logs: Int,
        val momentum: Int,
        val addedOrder: Int, // 0 = newest
    )

    private val genres = listOf(
        Genre(1, "creepypasta", "Крипипаста", "Creepypasta"),
        Genre(2, "psychological-horror", "Психологический ужас", "Psychological horror"),
        Genre(3, "paranormal", "Паранормальное", "Paranormal"),
        Genre(4, "urban-legend", "Городские легенды", "Urban legends"),
        Genre(5, "gothic", "Готика", "Gothic"),
        Genre(6, "ghost-story", "Истории с привидениями", "Ghost stories"),
    ).associateBy { it.id }

    private val tags = listOf(
        Tag(1, "одиночество", "одиночество"),
        Tag(2, "неожиданная-концовка", "неожиданная концовка"),
        Tag(3, "городская-мистика", "городская мистика"),
    ).associateBy { it.id }

    private val stories = listOf(
        Demo("demo-01", "[DEMO] Лампа в конце коридора", "Анна Вельская", "Чтец Один", 2021, listOf(2), listOf(1), intArrayOf(0, 1, 0, 2, 3, 6, 9, 14, 11, 8), 14, 52, 9, 3),
        Demo("demo-02", "[DEMO] Девятый этаж", "Игорь Сомов", "Чтец Два", 2019, listOf(4), listOf(3), intArrayOf(1, 0, 2, 3, 5, 9, 12, 10, 6, 3), 9, 41, 2, 7),
        Demo("demo-03", "[DEMO] Тихий абонент", "Мария Дроздова", "Чтец Один", 2023, listOf(3, 2), listOf(2), intArrayOf(0, 0, 1, 1, 2, 4, 8, 15, 18, 12), 22, 74, 14, 1),
        Demo("demo-04", "[DEMO] Дом без окон", "Анна Вельская", "Чтец Два", 2020, listOf(5), emptyList(), intArrayOf(0, 1, 1, 2, 4, 7, 10, 9, 5, 2), 6, 28, 0, 6),
        Demo("demo-05", "[DEMO] Ночной автобус", "Игорь Сомов", "Чтец Один", 2022, listOf(6, 4), listOf(3), intArrayOf(0, 0, 0, 1, 3, 5, 9, 12, 9, 6), 11, 39, 5, 4),
        Demo("demo-06", "[DEMO] Письма из подвала", "Мария Дроздова", "Чтец Два", 2018, listOf(1), listOf(2), intArrayOf(2, 1, 3, 5, 8, 11, 9, 6, 3, 1), 17, 63, 1, 9),
        Demo("demo-07", "[DEMO] Станция Сумеречная", "Анна Вельская", "Чтец Один", 2024, listOf(3), listOf(1), intArrayOf(0, 0, 0, 0, 1, 2, 3, 6, 7, 5), 4, 17, 8, 0),
        Demo("demo-08", "[DEMO] Эхо в колодце", "Игорь Сомов", "Чтец Два", 2017, listOf(1, 5), emptyList(), intArrayOf(1, 2, 2, 4, 6, 8, 7, 4, 2, 1), 8, 35, 0, 10),
        Demo("demo-09", "[DEMO] Свет в окне напротив", "Мария Дроздова", "Чтец Один", 2021, listOf(2), listOf(1, 2), intArrayOf(0, 0, 1, 2, 3, 6, 10, 13, 10, 7), 19, 58, 6, 5),
        Demo("demo-10", "[DEMO] Последний рейс", "Игорь Сомов", "Чтец Один", 2023, listOf(6), listOf(3), intArrayOf(0, 1, 0, 1, 2, 3, 5, 6, 4, 3), 3, 19, 3, 2),
        Demo("demo-11", "[DEMO] Дверь в стене", "Анна Вельская", "Чтец Два", 2016, listOf(5, 1), emptyList(), intArrayOf(0, 0, 0, 0, 0, 1, 2, 3, 2, 1), 2, 9, 0, 11),
        Demo("demo-12", "[DEMO] Голос из рации", "Мария Дроздова", "Чтец Два", 2022, listOf(3, 4), listOf(2), intArrayOf(0, 0, 0, 1, 1, 3, 4, 7, 6, 4), 7, 24, 4, 8),
    )

    private val favorites: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val wanted: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val myRatings = ConcurrentHashMap<String, Double>()

    override suspend fun section(section: CatalogSection, limit: Int, offset: Int): List<StoryCard> {
        delay(LATENCY_MS) // so loading skeletons are visible while designing
        val ordered = when (section) {
            CatalogSection.PopularThisWeek -> stories.sortedByDescending { it.logs }
            CatalogSection.HighestRated -> stories.sortedByDescending { bayes(it) }
            CatalogSection.RecentlyAdded -> stories.sortedBy { it.addedOrder }
            CatalogSection.Trending -> stories.filter { it.momentum > 0 }.sortedByDescending { it.momentum }
            CatalogSection.NewDiscoveries -> stories.filter { it.id !in myRatings }.sortedByDescending { bayes(it) }
            CatalogSection.MostReviewed -> stories.sortedByDescending { it.reviews }
        }
        return ordered.drop(offset).take(limit).map { card(it) }
    }

    override suspend fun details(storyId: String): StoryDetails {
        delay(LATENCY_MS)
        val story = stories.firstOrNull { it.id == storyId } ?: throw StoryNotFoundException()
        return StoryDetails(
            card = card(story),
            description = "Демонстрационная запись для разработки интерфейса. Сюжет выдуман: этот текст нужен, чтобы " +
                "проверить перенос строк, раскрытие описания и отступы на экране истории. ".repeat(3).trim(),
            externalUrl = null,
            genres = story.genreIds.mapNotNull { genres[it] },
            tags = story.tagIds.mapNotNull { tags[it] },
            isWantToListen = story.id in wanted,
            isListened = story.id in myRatings,
        )
    }

    override suspend fun ratingDistribution(storyId: String): List<RatingBucket> {
        delay(LATENCY_MS / 2)
        val story = stories.firstOrNull { it.id == storyId } ?: throw StoryNotFoundException()
        val counts = story.votes.copyOf()
        myRatings[storyId]?.let { counts[((it * 2).toInt() - 1).coerceIn(0, 9)] += 1 }
        return counts.mapIndexedNotNull { i, v -> if (v > 0) RatingBucket((i + 1) * 0.5, v) else null }
    }

    override suspend fun setRating(storyId: String, rating: Double) {
        myRatings[storyId] = rating
    }

    override suspend fun clearRating(storyId: String) {
        myRatings.remove(storyId)
    }

    override suspend fun setFavorite(storyId: String, favorite: Boolean) {
        if (favorite) favorites.add(storyId) else favorites.remove(storyId)
    }

    override suspend fun setWantToListen(storyId: String, want: Boolean) {
        if (want) wanted.add(storyId) else wanted.remove(storyId)
    }

    fun searchIndex(): List<DemoSearchEntry> = stories.map { story ->
        DemoSearchEntry(
            card = card(story),
            genreNames = story.genreIds.mapNotNull { genres[it] }.flatMap { listOf(it.nameRu, it.nameEn) },
            tagNames = story.tagIds.mapNotNull { tags[it]?.name },
        )
    }

    // ------------------------------------------------------------------ helpers
    private fun count(story: Demo): Int = story.votes.sum() + if (story.id in myRatings) 1 else 0

    private fun average(story: Demo): Double? {
        val n = count(story)
        if (n == 0) return null
        val sum = story.votes.withIndex().sumOf { (i, v) -> v * (i + 1) * 0.5 } + (myRatings[story.id] ?: 0.0)
        return sum / n
    }

    private fun bayes(story: Demo): Double {
        val n = count(story)
        return ((average(story) ?: 0.0) * n + 15.0) / (n + 5)
    }

    private fun card(story: Demo) = StoryCard(
        id = story.id,
        title = story.title,
        coverPath = null, // no covers in demo data: the UI shows its placeholder
        authorName = story.author,
        narratorName = story.narrator,
        publishedYear = story.year,
        avgRating = average(story),
        ratingsCount = count(story),
        reviewsCount = story.reviews,
        logsCount = story.logs,
        isFavorite = story.id in favorites,
        myRating = myRatings[story.id],
    )

    private companion object {
        const val LATENCY_MS = 350L
    }
}
