package com.wickedboxd.app.di

import com.wickedboxd.app.data.demo.DebugAuthRepository
import com.wickedboxd.app.data.demo.DebugSearchRepository
import com.wickedboxd.app.data.demo.DebugStoryRepository
import com.wickedboxd.app.data.demo.DebugUserRepository
import com.wickedboxd.app.data.demo.DebugDiaryRepository
import com.wickedboxd.app.domain.repository.AuthRepository
import com.wickedboxd.app.domain.repository.DiaryRepository
import com.wickedboxd.app.domain.repository.SearchRepository
import com.wickedboxd.app.domain.repository.StoryRepository
import com.wickedboxd.app.domain.repository.UserRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/** DEBUG variant: may fall back to demo data. The release variant of this module binds Supabase only. */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds
    @Singleton
    abstract fun bindStoryRepository(impl: DebugStoryRepository): StoryRepository

    @Binds
    @Singleton
    abstract fun bindAuthRepository(impl: DebugAuthRepository): AuthRepository

    @Binds
    @Singleton
    abstract fun bindSearchRepository(impl: DebugSearchRepository): SearchRepository

    @Binds
    @Singleton
    abstract fun bindUserRepository(impl: DebugUserRepository): UserRepository

    @Binds
    @Singleton
    abstract fun bindDiaryRepository(impl: DebugDiaryRepository): DiaryRepository
}
