package com.wickedboxd.app.data.demo

import com.wickedboxd.app.domain.model.SearchScope
import com.wickedboxd.app.domain.model.SearchSuggestion
import com.wickedboxd.app.domain.model.StoryCard
import com.wickedboxd.app.domain.model.SuggestionKind
import com.wickedboxd.app.domain.model.UserCard
import com.wickedboxd.app.domain.repository.SearchRepository
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.delay

/** DEMO ONLY (debug source set): the same matching rules as the SQL functions, over the demo data. */
@Singleton
class DemoSearchRepository @Inject constructor(
    private val stories: DemoStoryRepository,
    private val users: DemoUserRepository,
) : SearchRepository {

    private val logged = mutableListOf<String>()

    override suspend fun suggestions(query: String): List<SearchSuggestion> {
        delay(LATENCY_MS / 2)
        val q = query.trim()
        if (q.length < 2) return emptyList()
        val index = stories.searchIndex()
        val result = mutableListOf<SearchSuggestion>()
        index.filter { it.card.title.startsWith(q, ignoreCase = true) || it.card.title.contains(q, ignoreCase = true) }
            .sortedByDescending { it.card.ratingsCount }
            .take(4)
            .forEach { result += SearchSuggestion(SuggestionKind.Story, it.card.title, it.card.id) }
        index.mapNotNull { it.card.authorName }.distinct().filter { it.contains(q, true) }.take(2)
            .forEach { result += SearchSuggestion(SuggestionKind.Author, it, it) }
        index.mapNotNull { it.card.narratorName }.distinct().filter { it.contains(q, true) }.take(2)
            .forEach { result += SearchSuggestion(SuggestionKind.Narrator, it, it) }
        index.flatMap { it.genreNames }.distinct().filter { it.contains(q, true) }.take(2)
            .forEach { result += SearchSuggestion(SuggestionKind.Genre, it, it) }
        index.flatMap { it.tagNames }.distinct().filter { it.contains(q, true) }.take(2)
            .forEach { result += SearchSuggestion(SuggestionKind.Tag, it, it) }
        users.all().filter { it.username.contains(q.trimStart('@'), true) || it.displayName.contains(q, true) }.take(2)
            .forEach { result += SearchSuggestion(SuggestionKind.User, "${it.displayName} (@${it.username})", it.id) }
        return result
    }

    override suspend fun searchStories(query: String, scope: SearchScope, limit: Int, offset: Int): List<StoryCard> {
        delay(LATENCY_MS)
        val q = query.trim()
        if (q.length < 2) return emptyList()
        fun SearchScope.covers(target: SearchScope) = this == SearchScope.All || this == target
        return stories.searchIndex()
            .filter { e ->
                (scope.covers(SearchScope.Title) && e.card.title.contains(q, true)) ||
                    (scope.covers(SearchScope.Author) && e.card.authorName?.contains(q, true) == true) ||
                    (scope.covers(SearchScope.Narrator) && e.card.narratorName?.contains(q, true) == true) ||
                    (scope.covers(SearchScope.Genre) && e.genreNames.any { it.contains(q, true) }) ||
                    (scope.covers(SearchScope.Tag) && e.tagNames.any { it.contains(q, true) })
            }
            .sortedWith(
                compareBy<DemoSearchEntry> { if (it.card.title.startsWith(q, true)) 0 else if (it.card.title.contains(q, true)) 1 else 2 }
                    .thenByDescending { it.card.ratingsCount }
                    .thenBy { it.card.title },
            )
            .map { it.card }
            .drop(offset)
            .take(limit)
    }

    override suspend fun searchUsers(query: String, limit: Int): List<UserCard> {
        delay(LATENCY_MS)
        val q = query.trim().trimStart('@')
        if (q.length < 2) return emptyList()
        return users.all()
            .filter { it.username.contains(q, true) || it.displayName.contains(q, true) }
            .sortedByDescending { it.followersCount }
            .take(limit)
    }

    override suspend fun popularSearches(): List<String> {
        delay(LATENCY_MS / 2)
        return listOf("психологический ужас", "лампа", "демо", "городская мистика")
    }

    override suspend fun logSearch(query: String) {
        logged += query
    }

    private companion object {
        const val LATENCY_MS = 300L
    }
}
