package com.wickedboxd.app.data.demo

import com.wickedboxd.app.domain.model.UserCard
import com.wickedboxd.app.domain.repository.UserNotFoundException
import com.wickedboxd.app.domain.repository.UserRepository
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.delay

/** DEMO ONLY (debug source set): fictional people, follow state kept in memory. */
@Singleton
class DemoUserRepository @Inject constructor() : UserRepository {

    private class Person(val id: String, val username: String, val name: String, val bio: String?, val followers: Int, val following: Int)

    private val people = listOf(
        Person("demo-u1", "demo_anna", "[DEMO] Анна", "Слушаю страшилки по ночам. Выдуманный профиль для разработки интерфейса.", 128, 54),
        Person("demo-u2", "demo_igor", "[DEMO] Игорь", "Люблю городские легенды и истории про старые дома.", 76, 31),
        Person("demo-u3", "demo_maria", "[DEMO] Мария", null, 203, 12),
        Person("demo-u4", "demo_oleg", "[DEMO] Олег", "Крипипасты, готика, психологический ужас.", 15, 90),
        Person("demo-u5", "demo_vera", "[DEMO] Вера", "Всё, что со словами «не оборачивайся».", 342, 77),
        Person("demo-u6", "demo_nikita", "[DEMO] Никита", null, 9, 4),
    )
    private val followed: MutableSet<String> = ConcurrentHashMap.newKeySet()

    fun all(): List<UserCard> = people.map { card(it) }

    override suspend fun profile(userId: String): UserCard {
        delay(LATENCY_MS)
        val person = people.firstOrNull { it.id == userId } ?: throw UserNotFoundException()
        return card(person)
    }

    override suspend fun setFollowing(userId: String, follow: Boolean) {
        delay(LATENCY_MS / 2)
        if (people.none { it.id == userId }) throw UserNotFoundException()
        if (follow) followed.add(userId) else followed.remove(userId)
    }

    private fun card(p: Person) = UserCard(
        id = p.id,
        username = p.username,
        displayName = p.name,
        bio = p.bio,
        avatarPath = null,
        websiteUrl = null,
        followersCount = p.followers + if (p.id in followed) 1 else 0,
        followingCount = p.following,
        isFollowing = p.id in followed,
        isMe = false,
    )

    private companion object {
        const val LATENCY_MS = 350L
    }
}
