package com.wickedboxd.app.data.demo

import com.wickedboxd.app.core.config.BackendConfig
import com.wickedboxd.app.data.remote.SupabaseDiaryRepository
import com.wickedboxd.app.domain.repository.DiaryRepository
import javax.inject.Inject
import javax.inject.Singleton

/** Debug builds: real Supabase when local.properties is filled in, demo data otherwise. */
@Singleton
class DebugDiaryRepository @Inject constructor(
    config: BackendConfig,
    remote: SupabaseDiaryRepository,
    demo: DemoDiaryRepository,
) : DiaryRepository by (if (config.isConfigured) remote else demo)
