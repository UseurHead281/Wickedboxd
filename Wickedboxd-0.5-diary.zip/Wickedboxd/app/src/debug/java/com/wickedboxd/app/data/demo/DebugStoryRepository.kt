package com.wickedboxd.app.data.demo

import com.wickedboxd.app.core.config.BackendConfig
import com.wickedboxd.app.data.remote.SupabaseStoryRepository
import com.wickedboxd.app.domain.repository.StoryRepository
import javax.inject.Inject
import javax.inject.Singleton

/** Debug builds: real Supabase when local.properties is filled in, demo data otherwise. */
@Singleton
class DebugStoryRepository @Inject constructor(
    config: BackendConfig,
    remote: SupabaseStoryRepository,
    demo: DemoStoryRepository,
) : StoryRepository by (if (config.isConfigured) remote else demo)
