package com.wickedboxd.app.data.demo

import android.content.Intent
import com.wickedboxd.app.domain.model.AuthError
import com.wickedboxd.app.domain.model.AuthException
import com.wickedboxd.app.domain.model.AuthState
import com.wickedboxd.app.domain.model.SignUpOutcome
import com.wickedboxd.app.domain.repository.AuthRepository
import com.wickedboxd.app.domain.validation.AuthValidation
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * DEMO ONLY (debug source set). Lets you walk through the auth screens without a backend:
 * ANY email/password signs in; sign-up always asks for e-mail verification; "alice", "bob" and "demo" count as
 * taken usernames so the availability check can be seen working. Nothing here exists in a release build.
 */
@Singleton
class DemoAuthRepository @Inject constructor() : AuthRepository {

    private val _state = MutableStateFlow<AuthState>(AuthState.SignedOut)
    override val state: StateFlow<AuthState> = _state.asStateFlow()

    private val _passwordRecovery = MutableStateFlow(false)
    override val passwordRecovery: StateFlow<Boolean> = _passwordRecovery.asStateFlow()

    private val takenUsernames = setOf("alice", "bob", "demo")

    override suspend fun signIn(email: String, password: String) {
        delay(LATENCY_MS)
        _state.value = AuthState.SignedIn(userId = "demo-user", email = email.trim())
    }

    override suspend fun signUp(email: String, password: String, username: String): SignUpOutcome {
        delay(LATENCY_MS)
        if (AuthValidation.normalizeUsername(username) in takenUsernames) throw AuthException(AuthError.UsernameTaken)
        return SignUpOutcome.VerificationRequired
    }

    override suspend fun isUsernameAvailable(username: String): Boolean {
        delay(LATENCY_MS / 2)
        return AuthValidation.normalizeUsername(username) !in takenUsernames
    }

    override suspend fun sendPasswordReset(email: String) {
        delay(LATENCY_MS)
    }

    override suspend fun resendVerification(email: String) {
        delay(LATENCY_MS)
    }

    override suspend fun updatePassword(newPassword: String) {
        delay(LATENCY_MS)
        _passwordRecovery.value = false
    }

    override suspend fun signOut() {
        _state.value = AuthState.SignedOut
    }

    override fun handleDeepLink(intent: Intent) = Unit

    private companion object {
        const val LATENCY_MS = 600L
    }
}
