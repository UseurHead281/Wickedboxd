package com.wickedboxd.app.data.demo

import com.wickedboxd.app.domain.model.DiaryEntry
import com.wickedboxd.app.domain.model.LogListenRequest
import com.wickedboxd.app.domain.model.ProfileStats
import com.wickedboxd.app.domain.repository.DiaryRepository
import java.time.LocalDate
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.delay

/** DEMO ONLY (debug source set): an in-memory diary seeded with fictional listens relative to today. */
@Singleton
class DemoDiaryRepository @Inject constructor(
    private val stories: DemoStoryRepository,
) : DiaryRepository {

    private val entries = mutableListOf<DiaryEntry>()
    private var seeded = false

    private fun seedIfNeeded() {
        if (seeded) return
        seeded = true
        val cards = stories.searchIndex().map { it.card }
        val today = LocalDate.now()
        // (days ago, index of the demo story, rating)
        val plan = listOf(
            Triple(0, 2, 4.5), Triple(1, 0, 4.0), Triple(3, 8, 3.5), Triple(3, 4, null), Triple(6, 1, 5.0),
            Triple(9, 6, 4.0), Triple(12, 2, 4.5), Triple(15, 5, 3.0), Triple(22, 9, null), Triple(27, 3, 2.5),
            Triple(33, 7, 4.0), Triple(41, 11, 3.5),
        )
        plan.forEachIndexed { i, (ago, idx, rating) ->
            val card = cards[idx % cards.size]
            entries += DiaryEntry(
                id = "demo-log-$i", storyId = card.id, storyTitle = card.title, storyCoverPath = null,
                authorName = card.authorName, listenedOn = today.minusDays(ago.toLong()), rating = rating,
                note = if (i % 4 == 0) "Демо-заметка: слушал(а) в дороге." else null,
                isRelisten = i == 6, hasReview = i % 5 == 1,
            )
        }
    }

    override suspend fun entries(userId: String, from: LocalDate?, to: LocalDate?, limit: Int, offset: Int): List<DiaryEntry> {
        delay(LATENCY_MS)
        seedIfNeeded()
        return entries
            .filter { (from == null || !it.listenedOn.isBefore(from)) && (to == null || !it.listenedOn.isAfter(to)) }
            .sortedWith(compareByDescending<DiaryEntry> { it.listenedOn }.thenByDescending { it.id })
            .drop(offset)
            .take(limit)
    }

    override suspend fun logListen(request: LogListenRequest): String {
        delay(LATENCY_MS)
        seedIfNeeded()
        val card = stories.searchIndex().map { it.card }.firstOrNull { it.id == request.storyId }
        val id = "demo-log-" + UUID.randomUUID()
        entries += DiaryEntry(
            id = id, storyId = request.storyId, storyTitle = card?.title ?: "[DEMO]", storyCoverPath = null,
            authorName = card?.authorName, listenedOn = request.date, rating = request.rating, note = request.note,
            isRelisten = request.isRelisten, hasReview = !request.review.isNullOrBlank(),
        )
        request.rating?.let { stories.setRating(request.storyId, it) }
        return id
    }

    override suspend fun deleteEntry(entryId: String) {
        delay(LATENCY_MS / 2)
        seedIfNeeded()
        entries.removeAll { it.id == entryId }
    }

    override suspend fun stats(userId: String): ProfileStats {
        delay(LATENCY_MS / 2)
        seedIfNeeded()
        val rated = entries.mapNotNull { it.rating }
        return ProfileStats(
            storiesListened = entries.map { it.storyId }.distinct().size, // unique stories ...
            totalListens = entries.size, // ... and total listens are separate numbers
            averageRating = if (rated.isEmpty()) null else rated.average(),
            reviewsCount = entries.count { it.hasReview },
            listsCount = 0,
            favoritesCount = 0,
        )
    }

    private companion object {
        const val LATENCY_MS = 350L
    }
}
