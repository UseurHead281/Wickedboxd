package com.wickedboxd.app.data.demo

import com.wickedboxd.app.core.config.BackendConfig
import com.wickedboxd.app.data.remote.SupabaseSearchRepository
import com.wickedboxd.app.domain.repository.SearchRepository
import javax.inject.Inject
import javax.inject.Singleton

/** Debug builds: real Supabase when local.properties is filled in, demo data otherwise. */
@Singleton
class DebugSearchRepository @Inject constructor(
    config: BackendConfig,
    remote: SupabaseSearchRepository,
    demo: DemoSearchRepository,
) : SearchRepository by (if (config.isConfigured) remote else demo)
