package com.wickedboxd.app.data.local

import org.junit.Assert.assertEquals
import org.junit.Test

class RecentSearchesTest {

    @Test
    fun newestFirstAndCaseInsensitiveDeduplication() {
        val list = listOf("лампа", "Девятый этаж").withRecentSearch("ЛАМПА")
        assertEquals(listOf("ЛАМПА", "Девятый этаж"), list)
    }

    @Test
    fun keepsAtMostTenItems() {
        var list = emptyList<String>()
        for (i in 1..15) list = list.withRecentSearch("запрос $i")
        assertEquals(RECENT_SEARCHES_MAX, list.size)
        assertEquals("запрос 15", list.first())
        assertEquals("запрос 6", list.last())
    }

    @Test
    fun roundTripsThroughTheStoredString() {
        val items = listOf("a b", "тег", "автор")
        assertEquals(items, decodeRecentSearches(encodeRecentSearches(items)))
        assertEquals(emptyList<String>(), decodeRecentSearches(null))
        assertEquals(emptyList<String>(), decodeRecentSearches("\n \n"))
    }
}
