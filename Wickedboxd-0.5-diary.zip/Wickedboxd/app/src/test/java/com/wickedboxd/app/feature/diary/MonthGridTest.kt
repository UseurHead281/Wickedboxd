package com.wickedboxd.app.feature.diary

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MonthGridTest {

    @Test
    fun februaryStartingOnMondayFillsFourWeeksExactly() {
        // 2027-02-01 is a Monday, and 2027 is not a leap year: 28 days = 4 full weeks when weeks start on Monday
        val cells = monthCells(YearMonth.of(2027, 2), DayOfWeek.MONDAY)
        assertEquals(28, cells.size)
        assertEquals(LocalDate.of(2027, 2, 1), cells.first())
        assertEquals(LocalDate.of(2027, 2, 28), cells.last())
    }

    @Test
    fun leadingAndTrailingPaddingDependOnTheFirstDayOfWeek() {
        // 2026-11-01 is a Sunday
        val monday = monthCells(YearMonth.of(2026, 11), DayOfWeek.MONDAY)
        assertEquals(6, monday.takeWhile { it == null }.size) // Mon..Sat blank before Sunday the 1st
        assertEquals(LocalDate.of(2026, 11, 1), monday[6])
        val sunday = monthCells(YearMonth.of(2026, 11), DayOfWeek.SUNDAY)
        assertEquals(LocalDate.of(2026, 11, 1), sunday.first())
        assertNull(sunday.last()) // November has 30 days: padded to a full week
        assertEquals(0, monday.size % 7)
        assertEquals(0, sunday.size % 7)
    }

    @Test
    fun containsEveryDayOnce() {
        val cells = monthCells(YearMonth.of(2028, 2), DayOfWeek.MONDAY).filterNotNull() // leap year
        assertEquals(29, cells.size)
        assertEquals(cells.distinct(), cells)
    }

    @Test
    fun weekdayOrderRotates() {
        assertEquals(DayOfWeek.MONDAY, weekdayOrder(DayOfWeek.MONDAY).first())
        assertEquals(DayOfWeek.SUNDAY, weekdayOrder(DayOfWeek.MONDAY).last())
        assertEquals(DayOfWeek.SATURDAY, weekdayOrder(DayOfWeek.SUNDAY).last())
    }
}
