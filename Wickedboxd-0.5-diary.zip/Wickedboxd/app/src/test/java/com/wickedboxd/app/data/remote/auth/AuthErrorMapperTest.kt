package com.wickedboxd.app.data.remote.auth

import com.wickedboxd.app.domain.model.AuthError
import org.junit.Assert.assertEquals
import org.junit.Test

class AuthErrorMapperTest {

    @Test
    fun mapsKnownSupabaseMessages() {
        assertEquals(AuthError.InvalidCredentials, mapAuthFailureMessage("Invalid login credentials"))
        assertEquals(AuthError.EmailNotConfirmed, mapAuthFailureMessage("Email not confirmed"))
        assertEquals(AuthError.EmailTaken, mapAuthFailureMessage("User already registered"))
        assertEquals(AuthError.UsernameTaken, mapAuthFailureMessage("Database error saving new user"))
        assertEquals(AuthError.WeakPassword, mapAuthFailureMessage("Password should be at least 6 characters"))
        assertEquals(AuthError.RateLimited, mapAuthFailureMessage("email rate limit exceeded"))
        assertEquals(AuthError.RateLimited, mapAuthFailureMessage("over_email_send_rate_limit"))
    }

    @Test
    fun isCaseInsensitiveAndNullSafe() {
        assertEquals(AuthError.InvalidCredentials, mapAuthFailureMessage("INVALID LOGIN CREDENTIALS"))
        assertEquals(AuthError.Unknown, mapAuthFailureMessage(null))
        assertEquals(AuthError.Unknown, mapAuthFailureMessage("something unexpected"))
    }
}
