package com.wickedboxd.app.domain.validation

import org.junit.Assert.assertEquals
import org.junit.Test

class SearchQueryTest {

    @Test
    fun trimsAndCollapsesWhitespace() {
        assertEquals("тёмный лес", SearchQuery.normalize("  тёмный \n  лес\t"))
        assertEquals("", SearchQuery.normalize("   "))
    }

    @Test
    fun minimumLengthMatchesTheSqlFunctions() {
        // search_* functions in supabase/migrations/0003 return nothing for queries shorter than 2 characters
        assertEquals(2, SearchQuery.MIN_LENGTH)
    }
}
