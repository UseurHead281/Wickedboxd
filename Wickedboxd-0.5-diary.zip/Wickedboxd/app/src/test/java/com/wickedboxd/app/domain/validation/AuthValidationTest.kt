package com.wickedboxd.app.domain.validation

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthValidationTest {

    @Test
    fun acceptsOrdinaryEmails() {
        assertTrue(AuthValidation.isValidEmail("a@b.co"))
        assertTrue(AuthValidation.isValidEmail("  user.name+tag@sub.example.com  "))
    }

    @Test
    fun rejectsBrokenEmails() {
        assertFalse(AuthValidation.isValidEmail(""))
        assertFalse(AuthValidation.isValidEmail("no-at.example.com"))
        assertFalse(AuthValidation.isValidEmail("x@y"))
        assertFalse(AuthValidation.isValidEmail("a b@c.de"))
        assertFalse(AuthValidation.isValidEmail("@c.de"))
        assertFalse(AuthValidation.isValidEmail("a".repeat(250) + "@b.co"))
    }

    @Test
    fun normalizesUsernames() {
        assertEquals("alice_01", AuthValidation.normalizeUsername(" Alice_01 "))
        assertEquals("ab", AuthValidation.normalizeUsername("A B"))
    }

    @Test
    fun validatesUsernames() {
        assertNull(AuthValidation.usernameProblem("alice_01"))
        assertNull(AuthValidation.usernameProblem("ABC")) // normalised to lower case first
        assertEquals(UsernameProblem.Empty, AuthValidation.usernameProblem("   "))
        assertEquals(UsernameProblem.TooShort, AuthValidation.usernameProblem("ab"))
        assertEquals(UsernameProblem.TooLong, AuthValidation.usernameProblem("a".repeat(21)))
        assertEquals(UsernameProblem.InvalidChars, AuthValidation.usernameProblem("bad-name"))
        assertEquals(UsernameProblem.InvalidChars, AuthValidation.usernameProblem("имя_пользователя"))
        assertEquals(UsernameProblem.Reserved, AuthValidation.usernameProblem("Admin"))
        assertEquals(UsernameProblem.Reserved, AuthValidation.usernameProblem("wickedboxd"))
    }

    @Test
    fun validatesPasswords() {
        assertNull(AuthValidation.passwordProblem("12345678"))
        assertEquals(PasswordProblem.TooShort, AuthValidation.passwordProblem("1234567"))
        assertEquals(PasswordProblem.TooLong, AuthValidation.passwordProblem("x".repeat(73)))
        assertNull(AuthValidation.passwordProblem("x".repeat(72)))
    }

    @Test
    fun reservedListMatchesTheDatabaseConstraint() {
        // supabase/migrations/0001_schema.sql: profiles_username_reserved
        val expected = setOf("admin", "administrator", "moderator", "support", "wickedboxd", "root", "system")
        assertEquals(expected, AuthValidation.RESERVED_USERNAMES)
    }
}
