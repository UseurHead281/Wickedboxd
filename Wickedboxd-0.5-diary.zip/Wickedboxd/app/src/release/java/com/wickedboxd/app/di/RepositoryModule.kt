package com.wickedboxd.app.di

import com.wickedboxd.app.data.remote.SupabaseSearchRepository
import com.wickedboxd.app.data.remote.SupabaseStoryRepository
import com.wickedboxd.app.data.remote.SupabaseUserRepository
import com.wickedboxd.app.data.remote.auth.SupabaseAuthRepository
import com.wickedboxd.app.data.remote.SupabaseDiaryRepository
import com.wickedboxd.app.domain.repository.AuthRepository
import com.wickedboxd.app.domain.repository.DiaryRepository
import com.wickedboxd.app.domain.repository.SearchRepository
import com.wickedboxd.app.domain.repository.StoryRepository
import com.wickedboxd.app.domain.repository.UserRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/** RELEASE variant: production data source only. No demo code exists in this build. */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds
    @Singleton
    abstract fun bindStoryRepository(impl: SupabaseStoryRepository): StoryRepository

    @Binds
    @Singleton
    abstract fun bindAuthRepository(impl: SupabaseAuthRepository): AuthRepository

    @Binds
    @Singleton
    abstract fun bindSearchRepository(impl: SupabaseSearchRepository): SearchRepository

    @Binds
    @Singleton
    abstract fun bindUserRepository(impl: SupabaseUserRepository): UserRepository

    @Binds
    @Singleton
    abstract fun bindDiaryRepository(impl: SupabaseDiaryRepository): DiaryRepository
}
