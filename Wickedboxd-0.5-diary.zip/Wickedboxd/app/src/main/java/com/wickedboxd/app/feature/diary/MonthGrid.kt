package com.wickedboxd.app.feature.diary

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

/**
 * Cells of a month calendar, week after week: leading nulls pad the first week, trailing nulls pad the last,
 * so the size is always a multiple of 7. [firstDayOfWeek] comes from the locale (Monday in Russia, Sunday in the US).
 */
internal fun monthCells(month: YearMonth, firstDayOfWeek: DayOfWeek): List<LocalDate?> {
    val lead = (month.atDay(1).dayOfWeek.value - firstDayOfWeek.value + 7) % 7
    val cells = MutableList<LocalDate?>(lead) { null }
    for (day in 1..month.lengthOfMonth()) cells += month.atDay(day)
    while (cells.size % 7 != 0) cells += null
    return cells
}

/** Seven weekdays starting at [firstDayOfWeek], for the calendar header. */
internal fun weekdayOrder(firstDayOfWeek: DayOfWeek): List<DayOfWeek> =
    List(7) { firstDayOfWeek.plus(it.toLong()) }
