package com.wickedboxd.app.feature.story

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.wickedboxd.app.core.designsystem.icon.WbIcon
import com.wickedboxd.app.core.designsystem.icon.WbIcons
import com.wickedboxd.app.core.designsystem.theme.WbTheme
import com.wickedboxd.app.domain.model.RatingBucket
import kotlin.math.abs

/**
 * Ten bars, 0.5 .. 5.0 stars. The user's own rating is drawn in the full accent colour,
 * every other bar in a soft tint; an empty bucket is a thin stub so the scale stays readable.
 */
@Composable
fun RatingDistributionChart(
    buckets: List<RatingBucket>,
    myRating: Double?,
    modifier: Modifier = Modifier,
) {
    val colors = WbTheme.colors
    val votesByRating = buckets.associate { it.rating to it.votes }
    val maxVotes = (buckets.maxOfOrNull { it.votes } ?: 0).coerceAtLeast(1)

    Column(modifier) {
        Row(
            modifier = Modifier.fillMaxWidth().height(64.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            for (step in 1..10) {
                val rating = step * 0.5
                val votes = votesByRating[rating] ?: 0
                val target = if (votes == 0) 0.04f else (votes / maxVotes.toFloat()).coerceIn(0.1f, 1f)
                val fraction by animateFloatAsState(target, tween(450), label = "ratingBar$step")
                val isMine = myRating != null && abs(myRating - rating) < 0.01
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(fraction)
                        .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                        .background(
                            when {
                                isMine -> colors.accent
                                votes > 0 -> colors.accent.copy(alpha = 0.4f)
                                else -> colors.surfaceElevated
                            },
                        ),
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            WbIcon(WbIcons.Star, contentDescription = null, size = 10.dp, tint = colors.textSecondary)
            Row {
                repeat(5) { WbIcon(WbIcons.Star, contentDescription = null, size = 10.dp, tint = colors.textSecondary) }
            }
        }
    }
}
