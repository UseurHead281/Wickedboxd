package com.wickedboxd.app.feature.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wickedboxd.app.domain.model.AuthError
import com.wickedboxd.app.domain.repository.AuthRepository
import com.wickedboxd.app.domain.validation.AuthValidation
import com.wickedboxd.app.domain.validation.PasswordProblem
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ResetPasswordUiState(
    val password: String = "",
    val confirm: String = "",
    val showPassword: Boolean = false,
    val passwordProblem: PasswordProblem? = null,
    val mismatch: Boolean = false,
    val isLoading: Boolean = false,
    val error: AuthError? = null,
)

/** Shown right after the user opened a password-reset link (a recovery session is active). */
@HiltViewModel
class ResetPasswordViewModel @Inject constructor(
    private val auth: AuthRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(ResetPasswordUiState())
    val state: StateFlow<ResetPasswordUiState> = _state.asStateFlow()

    fun onPasswordChange(value: String) = _state.update { it.copy(password = value, passwordProblem = null, mismatch = false, error = null) }

    fun onConfirmChange(value: String) = _state.update { it.copy(confirm = value, mismatch = false, error = null) }

    fun toggleShowPassword() = _state.update { it.copy(showPassword = !it.showPassword) }

    fun submit() {
        val current = _state.value
        if (current.isLoading) return
        val problem = AuthValidation.passwordProblem(current.password)
        val mismatch = current.password != current.confirm
        if (problem != null || mismatch) {
            _state.update { it.copy(passwordProblem = problem, mismatch = mismatch) }
            return
        }
        _state.update { it.copy(isLoading = true, error = null) }
        viewModelScope.launch {
            val error = runAuth { auth.updatePassword(current.password) }
            // on success the repository clears the recovery flag and the app root continues into the app
            _state.update { it.copy(isLoading = false, error = error) }
        }
    }
}
