package com.wickedboxd.app.feature.auth

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.AuthScaffold
import com.wickedboxd.app.core.designsystem.component.WbPrimaryButton
import com.wickedboxd.app.core.designsystem.component.WbTextField
import com.wickedboxd.app.core.designsystem.component.WbTextLink

@Composable
fun RegisterScreen(
    onBack: () -> Unit,
    onSignIn: () -> Unit,
    onVerificationRequired: (String) -> Unit,
    viewModel: RegisterViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current

    LaunchedEffect(Unit) {
        viewModel.verification.collect { email -> onVerificationRequired(email) }
    }

    // username line under the field: error, neutral hint, or the positive "available"
    val usernameError: String?
    val usernameHint: String
    var usernameOk = false
    when (val status = state.usernameStatus) {
        UsernameStatus.Idle -> { usernameError = null; usernameHint = stringResource(R.string.username_hint) }
        is UsernameStatus.Invalid -> { usernameError = stringResource(status.problem.messageRes()); usernameHint = "" }
        UsernameStatus.Checking -> { usernameError = null; usernameHint = stringResource(R.string.username_checking) }
        UsernameStatus.Available -> { usernameError = null; usernameHint = stringResource(R.string.username_available); usernameOk = true }
        UsernameStatus.Taken -> { usernameError = stringResource(R.string.username_taken); usernameHint = "" }
        UsernameStatus.Unchecked -> { usernameError = null; usernameHint = stringResource(R.string.username_unchecked) }
    }

    AuthScaffold(title = stringResource(R.string.register_title), onBack = onBack) {
        EmailField(
            value = state.email,
            onValueChange = viewModel::onEmailChange,
            invalid = state.emailInvalid,
            onDone = { focus.moveFocus(FocusDirection.Down) },
        )
        WbTextField(
            value = state.username,
            onValueChange = viewModel::onUsernameChange,
            label = stringResource(R.string.field_username),
            errorText = usernameError,
            hintText = usernameHint.ifEmpty { null },
            hintIsPositive = usernameOk,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Next),
        )
        PasswordField(
            value = state.password,
            onValueChange = viewModel::onPasswordChange,
            label = stringResource(R.string.field_password),
            show = state.showPassword,
            onToggleShow = viewModel::toggleShowPassword,
            errorText = state.passwordProblem?.let { stringResource(it.messageRes()) },
            hintText = stringResource(R.string.password_hint),
            imeAction = ImeAction.Done,
            onDone = {
                focus.clearFocus()
                viewModel.submit()
            },
        )
        state.error?.let { FormError(stringResource(it.messageRes())) }
        WbPrimaryButton(
            text = stringResource(R.string.register_submit),
            onClick = viewModel::submit,
            loading = state.isLoading,
        )
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            WbTextLink(text = stringResource(R.string.register_have_account), onClick = onSignIn)
        }
    }
}
