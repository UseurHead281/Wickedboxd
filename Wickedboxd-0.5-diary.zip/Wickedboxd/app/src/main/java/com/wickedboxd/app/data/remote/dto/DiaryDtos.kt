package com.wickedboxd.app.data.remote.dto

import com.wickedboxd.app.domain.model.DiaryEntry
import com.wickedboxd.app.domain.model.ProfileStats
import java.time.LocalDate
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Row of the `diary_entries` view. */
@Serializable
data class DiaryEntryDto(
    val id: String,
    @SerialName("story_id") val storyId: String,
    @SerialName("story_title") val storyTitle: String,
    @SerialName("story_cover_path") val storyCoverPath: String? = null,
    @SerialName("author_name") val authorName: String? = null,
    @SerialName("listened_on") val listenedOn: String, // "2026-11-21"
    val rating: Double? = null,
    val note: String? = null,
    @SerialName("is_relisten") val isRelisten: Boolean = false,
    @SerialName("review_id") val reviewId: String? = null,
)

/** Row returned by the `profile_stats` function. */
@Serializable
data class ProfileStatsDto(
    @SerialName("stories_listened") val storiesListened: Int = 0,
    @SerialName("total_listens") val totalListens: Int = 0,
    @SerialName("average_rating") val averageRating: Double? = null,
    @SerialName("reviews_count") val reviewsCount: Int = 0,
    @SerialName("lists_count") val listsCount: Int = 0,
    @SerialName("favorites_count") val favoritesCount: Int = 0,
)

fun DiaryEntryDto.toDomain() = DiaryEntry(
    id = id, storyId = storyId, storyTitle = storyTitle, storyCoverPath = storyCoverPath, authorName = authorName,
    listenedOn = LocalDate.parse(listenedOn), rating = rating, note = note, isRelisten = isRelisten,
    hasReview = reviewId != null,
)

fun ProfileStatsDto.toDomain() = ProfileStats(
    storiesListened = storiesListened, totalListens = totalListens, averageRating = averageRating,
    reviewsCount = reviewsCount, listsCount = listsCount, favoritesCount = favoritesCount,
)
