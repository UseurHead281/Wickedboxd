package com.wickedboxd.app

import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wickedboxd.app.data.local.UserPreferencesRepository
import com.wickedboxd.app.domain.model.AuthState
import com.wickedboxd.app.domain.model.UserSettings
import com.wickedboxd.app.domain.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

@HiltViewModel
class AppViewModel @Inject constructor(
    preferences: UserPreferencesRepository,
    private val auth: AuthRepository,
) : ViewModel() {

    /** Null until DataStore delivers its first value; the system splash screen stays up meanwhile. */
    val settings: StateFlow<UserSettings?> = preferences.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val authState: StateFlow<AuthState> = auth.state
    val passwordRecovery: StateFlow<Boolean> = auth.passwordRecovery

    fun handleDeepLink(intent: Intent) = auth.handleDeepLink(intent)
}
