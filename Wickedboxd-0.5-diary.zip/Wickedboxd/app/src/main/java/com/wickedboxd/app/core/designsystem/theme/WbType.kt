package com.wickedboxd.app.core.designsystem.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Single swap point for the typeface. Today: the system sans-serif (Roboto on most devices).
 * To use Inter/Manrope/etc.: put the .ttf files in res/font and replace this with
 * `FontFamily(Font(R.font.inter_regular), Font(R.font.inter_semibold, FontWeight.SemiBold), ...)`.
 */
val WickedboxdFontFamily: FontFamily = FontFamily.SansSerif

private fun style(size: Int, lineHeight: Int, weight: FontWeight, letterSpacing: Double = 0.0) = TextStyle(
    fontFamily = WickedboxdFontFamily,
    fontSize = size.sp,
    lineHeight = lineHeight.sp,
    fontWeight = weight,
    letterSpacing = letterSpacing.sp,
)

/** Expressive but restrained headings, calm body text. All sizes are sp, so system font scaling works. */
val WbTypography = Typography(
    displaySmall = style(32, 38, FontWeight.Bold, -0.4),
    headlineLarge = style(28, 34, FontWeight.Bold, -0.3),
    headlineMedium = style(24, 30, FontWeight.Bold, -0.2),
    headlineSmall = style(21, 27, FontWeight.SemiBold, -0.1),
    titleLarge = style(20, 26, FontWeight.SemiBold),
    titleMedium = style(16, 22, FontWeight.SemiBold, 0.1),
    titleSmall = style(14, 20, FontWeight.SemiBold, 0.1),
    bodyLarge = style(16, 24, FontWeight.Normal, 0.2),
    bodyMedium = style(14, 21, FontWeight.Normal, 0.2),
    bodySmall = style(12, 18, FontWeight.Normal, 0.2),
    labelLarge = style(14, 20, FontWeight.Medium, 0.1),
    labelMedium = style(12, 16, FontWeight.Medium, 0.3),
    labelSmall = style(11, 14, FontWeight.Medium, 0.3),
)
