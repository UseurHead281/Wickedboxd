package com.wickedboxd.app.domain.repository

import com.wickedboxd.app.domain.model.UserCard

class UserNotFoundException : Exception("user_not_found")

interface UserRepository {
    suspend fun profile(userId: String): UserCard
    suspend fun setFollowing(userId: String, follow: Boolean)
}
