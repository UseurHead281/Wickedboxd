package com.wickedboxd.app.feature.story

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import com.wickedboxd.app.core.config.CoverUrlResolver
import com.wickedboxd.app.core.navigation.StoryRoute
import com.wickedboxd.app.core.util.ErrorKind
import com.wickedboxd.app.core.util.toErrorKind
import com.wickedboxd.app.domain.model.RatingBucket
import com.wickedboxd.app.domain.model.StoryDetails
import com.wickedboxd.app.domain.repository.StoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class StoryDetailUiState(
    val isLoading: Boolean = true,
    val details: StoryDetails? = null,
    val distribution: List<RatingBucket> = emptyList(),
    val error: ErrorKind? = null,
)

sealed interface StoryDetailEvent {
    data class ActionFailed(val kind: ErrorKind) : StoryDetailEvent
}

@HiltViewModel
class StoryDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val stories: StoryRepository,
    private val covers: CoverUrlResolver,
) : ViewModel() {

    private val storyId: String = savedStateHandle.toRoute<StoryRoute>().storyId

    private val _state = MutableStateFlow(StoryDetailUiState())
    val state: StateFlow<StoryDetailUiState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<StoryDetailEvent>(extraBufferCapacity = 1)
    val events: SharedFlow<StoryDetailEvent> = _events.asSharedFlow()

    /** Writes run one at a time, so quick taps cannot overtake each other. */
    private val writeLock = Mutex()

    init {
        load()
    }

    fun coverUrl(path: String?): String? = covers.storyCover(path)

    fun load() {
        _state.update { it.copy(isLoading = it.details == null, error = null) }
        viewModelScope.launch {
            try {
                val (details, distribution) = fetch()
                _state.update { it.copy(isLoading = false, details = details, distribution = distribution, error = null) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.toErrorKind()) }
            }
        }
    }

    fun setRating(rating: Double) =
        write({ it.copy(card = it.card.copy(myRating = rating)) }) { stories.setRating(storyId, rating) }

    fun clearRating() =
        write({ it.copy(card = it.card.copy(myRating = null)) }) { stories.clearRating(storyId) }

    fun toggleFavorite() {
        val target = !(_state.value.details?.card?.isFavorite ?: return)
        write({ it.copy(card = it.card.copy(isFavorite = target)) }) { stories.setFavorite(storyId, target) }
    }

    fun toggleWantToListen() {
        val target = !(_state.value.details?.isWantToListen ?: return)
        write({ it.copy(isWantToListen = target) }) { stories.setWantToListen(storyId, target) }
    }

    /**
     * Optimistic write: the UI changes immediately, the server call follows, and the server's answer
     * (new average, new counts) replaces the local guess. On failure the previous state is restored.
     */
    private fun write(optimistic: (StoryDetails) -> StoryDetails, call: suspend () -> Unit) {
        viewModelScope.launch {
            writeLock.withLock {
                val before = _state.value.details ?: return@withLock
                _state.update { s -> s.copy(details = s.details?.let(optimistic)) }
                try {
                    call()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    _state.update { it.copy(details = before) }
                    _events.tryEmit(StoryDetailEvent.ActionFailed(e.toErrorKind()))
                }
                resync()
            }
        }
    }

    private suspend fun resync() {
        try {
            val (details, distribution) = fetch()
            _state.update { it.copy(details = details, distribution = distribution) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // keep what is on screen; the next action or a reload will resync
        }
    }

    private suspend fun fetch(): Pair<StoryDetails, List<RatingBucket>> = coroutineScope {
        val details = async { stories.details(storyId) }
        val distribution = async { stories.ratingDistribution(storyId) }
        details.await() to distribution.await()
    }
}
