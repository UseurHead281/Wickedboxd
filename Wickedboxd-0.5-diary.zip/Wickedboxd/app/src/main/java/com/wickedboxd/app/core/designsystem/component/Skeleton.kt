package com.wickedboxd.app.core.designsystem.component

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.wickedboxd.app.core.designsystem.theme.CoverShape
import com.wickedboxd.app.core.designsystem.theme.WbTheme

@Composable
fun SkeletonBlock(modifier: Modifier = Modifier, shape: Shape = RoundedCornerShape(8.dp)) {
    Box(modifier = modifier.clip(shape).background(WbTheme.colors.surface).shimmer())
}

/** Placeholder for a horizontal row of covers while a catalogue section loads. */
@Composable
fun CoverRowSkeleton(itemWidth: Dp, modifier: Modifier = Modifier, count: Int = 3) {
    Row(
        modifier = modifier.padding(horizontal = WbDimens.ScreenPadding),
        horizontalArrangement = Arrangement.spacedBy(WbDimens.CoverSpacing),
    ) {
        repeat(count) {
            SkeletonBlock(Modifier.width(itemWidth).aspectRatio(2f / 3f), CoverShape)
        }
    }
}
