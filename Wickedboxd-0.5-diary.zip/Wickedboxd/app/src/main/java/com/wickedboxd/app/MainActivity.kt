package com.wickedboxd.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.core.designsystem.theme.WbTheme
import com.wickedboxd.app.core.designsystem.theme.WickedboxdTheme
import com.wickedboxd.app.core.designsystem.theme.isDarkTheme
import com.wickedboxd.app.domain.model.AuthState
import com.wickedboxd.app.feature.auth.AuthFlow
import com.wickedboxd.app.feature.auth.ResetPasswordScreen
import dagger.hilt.android.AndroidEntryPoint

/** What the user sees at the root of the app. */
private enum class RootScreen { Loading, SignedOut, ResetPassword, App }

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        val startedAt = SystemClock.elapsedRealtime()
        // Hold the splash until settings are loaded (no wrong-theme flash) and the stored session is known - but never
        // longer than a few seconds: offline with an expired token must not freeze the app on the splash.
        splash.setKeepOnScreenCondition {
            val waitingForSession = viewModel.authState.value is AuthState.Loading &&
                SystemClock.elapsedRealtime() - startedAt < SESSION_WAIT_MS
            viewModel.settings.value == null || waitingForSession
        }
        if (savedInstanceState == null) viewModel.handleDeepLink(intent)

        setContent {
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            settings?.let { current ->
                val dark = isDarkTheme(current.themeMode)
                // System-bar icon colours follow the in-app theme, not the phone's theme.
                DisposableEffect(dark) {
                    enableEdgeToEdge(
                        statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                        navigationBarStyle = SystemBarStyle.auto(LightScrim, DarkScrim) { dark },
                    )
                    onDispose { }
                }
                WickedboxdTheme(themeMode = current.themeMode, accent = current.accent) {
                    RootContent()
                }
            }
        }
    }

    // launchMode=singleTask: e-mail confirmation / password-reset links arrive here while the app is running
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        viewModel.handleDeepLink(intent)
    }

    @Composable
    private fun RootContent() {
        val authState by viewModel.authState.collectAsStateWithLifecycle()
        val recovery by viewModel.passwordRecovery.collectAsStateWithLifecycle()
        val screen = when {
            authState is AuthState.SignedIn && recovery -> RootScreen.ResetPassword
            authState is AuthState.SignedIn -> RootScreen.App
            authState is AuthState.SignedOut -> RootScreen.SignedOut
            else -> RootScreen.Loading
        }
        Crossfade(targetState = screen, animationSpec = tween(220), label = "rootScreen") { target ->
            when (target) {
                RootScreen.Loading -> Box(Modifier.fillMaxSize().background(WbTheme.colors.background))
                RootScreen.SignedOut -> AuthFlow(Modifier.fillMaxSize())
                RootScreen.ResetPassword -> ResetPasswordScreen()
                RootScreen.App -> WickedboxdRoot()
            }
        }
    }

    private companion object {
        const val SESSION_WAIT_MS = 3_000L
        val LightScrim = Color.argb(0xE6, 0xFF, 0xFF, 0xFF)
        val DarkScrim = Color.argb(0x80, 0x1B, 0x1B, 0x1B)
    }
}
