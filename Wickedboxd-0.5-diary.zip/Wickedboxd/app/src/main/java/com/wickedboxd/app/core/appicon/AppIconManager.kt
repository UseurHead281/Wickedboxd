package com.wickedboxd.app.core.appicon

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import com.wickedboxd.app.domain.model.AppIconVariant
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Switches the launcher icon by enabling exactly one `<activity-alias>`.
 *
 * Android has no API to change the icon directly; the alias mechanism is the supported way.
 * Some launchers refresh the icon with a short delay, and a few OEM launchers close the app
 * when the alias changes - that is launcher behaviour, not something the app can prevent.
 */
@Singleton
class AppIconManager @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val packageManager: PackageManager get() = context.packageManager

    /** The alias that is currently enabled (Original when nothing was ever changed). */
    fun current(): AppIconVariant =
        AppIconVariant.entries.firstOrNull(::isEnabled) ?: AppIconVariant.Original

    fun apply(variant: AppIconVariant) {
        if (current() == variant) return
        // Enable the new alias first so the app never has zero launcher entries.
        setEnabled(variant, true)
        AppIconVariant.entries.filter { it != variant }.forEach { setEnabled(it, false) }
    }

    private fun isEnabled(variant: AppIconVariant): Boolean =
        when (packageManager.getComponentEnabledSetting(component(variant))) {
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
            // DEFAULT = whatever the manifest says: only Original is enabled there.
            PackageManager.COMPONENT_ENABLED_STATE_DEFAULT -> variant == AppIconVariant.Original
            else -> false
        }

    private fun setEnabled(variant: AppIconVariant, enabled: Boolean) {
        packageManager.setComponentEnabledSetting(
            component(variant),
            if (enabled) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP,
        )
    }

    // Alias class names resolve against the manifest namespace, not applicationId
    // (they differ as soon as a build type adds an applicationIdSuffix).
    private fun component(variant: AppIconVariant) =
        ComponentName(context.packageName, NAMESPACE + variant.aliasName)

    private companion object {
        const val NAMESPACE = "com.wickedboxd.app"
    }
}
