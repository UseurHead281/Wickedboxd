package com.wickedboxd.app.core.designsystem.component

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.wickedboxd.app.core.designsystem.theme.WbTheme

/** Equal-width text tabs with an accent underline under the selected one (Stories / Reviews / Lists / Diary). */
@Composable
fun WbTabStrip(
    titles: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = WbTheme.colors
    Row(modifier = modifier.fillMaxWidth().background(colors.topBar)) {
        titles.forEachIndexed { index, title ->
            val selected = index == selectedIndex
            val textColor by animateColorAsState(
                targetValue = if (selected) colors.textPrimary else colors.textSecondary,
                animationSpec = tween(160),
                label = "tabText",
            )
            val lineColor by animateColorAsState(
                targetValue = if (selected) colors.accent else Color.Transparent,
                animationSpec = tween(160),
                label = "tabLine",
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .selectable(selected = selected, role = Role.Tab, onClick = { onSelect(index) })
                    .padding(top = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge,
                    color = textColor,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(2.dp).background(lineColor))
            }
        }
    }
}
