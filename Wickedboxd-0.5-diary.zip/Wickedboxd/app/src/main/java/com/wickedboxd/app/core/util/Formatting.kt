package com.wickedboxd.app.core.util

import androidx.annotation.PluralsRes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.platform.LocalContext
import java.util.Locale

/** 4.5 -> "4.5" in English, "4,5" in Russian. */
fun formatRating(value: Double): String = String.format(Locale.getDefault(), "%.1f", value)

/** Plural-aware string (Russian has four forms, so never concatenate counts by hand). */
@Composable
@ReadOnlyComposable
fun quantityString(@PluralsRes id: Int, quantity: Int, vararg formatArgs: Any): String =
    LocalContext.current.resources.getQuantityString(id, quantity, *formatArgs)
