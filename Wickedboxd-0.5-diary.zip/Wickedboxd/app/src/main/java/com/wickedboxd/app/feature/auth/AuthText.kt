package com.wickedboxd.app.feature.auth

import androidx.annotation.StringRes
import com.wickedboxd.app.R
import com.wickedboxd.app.domain.model.AuthError
import com.wickedboxd.app.domain.validation.PasswordProblem
import com.wickedboxd.app.domain.validation.UsernameProblem

@StringRes
internal fun AuthError.messageRes(): Int = when (this) {
    AuthError.InvalidCredentials -> R.string.auth_error_invalid_credentials
    AuthError.EmailNotConfirmed -> R.string.auth_error_email_not_confirmed
    AuthError.EmailTaken -> R.string.auth_error_email_taken
    AuthError.UsernameTaken -> R.string.auth_error_username_taken
    AuthError.WeakPassword -> R.string.auth_error_weak_password
    AuthError.RateLimited -> R.string.auth_error_rate_limited
    AuthError.Network -> R.string.error_network
    AuthError.NotConfigured -> R.string.error_not_configured
    AuthError.Unknown -> R.string.error_unknown
}

@StringRes
internal fun UsernameProblem.messageRes(): Int = when (this) {
    UsernameProblem.Empty -> R.string.field_required
    UsernameProblem.TooShort -> R.string.username_too_short
    UsernameProblem.TooLong -> R.string.username_too_long
    UsernameProblem.InvalidChars -> R.string.username_invalid_chars
    UsernameProblem.Reserved -> R.string.username_reserved
}

@StringRes
internal fun PasswordProblem.messageRes(): Int = when (this) {
    PasswordProblem.TooShort -> R.string.password_too_short
    PasswordProblem.TooLong -> R.string.password_too_long
}
