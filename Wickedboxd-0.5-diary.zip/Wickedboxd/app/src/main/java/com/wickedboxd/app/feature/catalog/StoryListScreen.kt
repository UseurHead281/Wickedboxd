package com.wickedboxd.app.feature.catalog

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.EmptyState
import com.wickedboxd.app.core.designsystem.component.ErrorState
import com.wickedboxd.app.core.designsystem.component.SkeletonBlock
import com.wickedboxd.app.core.designsystem.component.StoryCover
import com.wickedboxd.app.core.designsystem.component.WbBackBar
import com.wickedboxd.app.core.designsystem.component.WbDimens
import com.wickedboxd.app.core.designsystem.theme.CoverShape
import com.wickedboxd.app.core.designsystem.theme.WbTheme

private const val LOAD_MORE_THRESHOLD = 6

/** Full list of one catalogue section: three covers per row, endless scrolling. */
@Composable
fun StoryListScreen(
    onBack: () -> Unit,
    onStoryClick: (String) -> Unit,
    viewModel: StoryListViewModel = hiltViewModel(),
) {
    val colors = WbTheme.colors
    val state by viewModel.state.collectAsStateWithLifecycle()
    val gridState = rememberLazyGridState()
    val nearEnd by remember {
        derivedStateOf {
            val last = gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            last >= gridState.layoutInfo.totalItemsCount - LOAD_MORE_THRESHOLD
        }
    }
    LaunchedEffect(nearEnd, state.stories.size) {
        if (nearEnd && state.stories.isNotEmpty()) viewModel.loadMore()
    }

    val error = state.error
    Column(Modifier.fillMaxSize().background(colors.background)) {
        WbBackBar(onBack = onBack, title = stringResource(viewModel.section.titleRes()))
        when {
            state.isLoading -> GridSkeleton()
            error != null && state.stories.isEmpty() -> ErrorState(kind = error, onRetry = viewModel::retry)
            state.stories.isEmpty() -> EmptyState(
                title = stringResource(R.string.catalog_empty_title),
                subtitle = stringResource(R.string.catalog_empty_subtitle),
            )
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                state = gridState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    start = WbDimens.ScreenPadding,
                    end = WbDimens.ScreenPadding,
                    top = 16.dp,
                    bottom = 24.dp,
                ),
                horizontalArrangement = Arrangement.spacedBy(WbDimens.CoverSpacing),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                items(state.stories, key = { it.id }) { story ->
                    StoryCover(
                        title = story.title,
                        coverUrl = viewModel.coverUrl(story.coverPath),
                        rating = story.myRating,
                        isFavorite = story.isFavorite,
                        onClick = { onStoryClick(story.id) },
                    )
                }
                if (state.isLoadingMore) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(strokeWidth = 2.dp, color = colors.accent, modifier = Modifier.size(24.dp))
                        }
                    }
                }
                if (error != null) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        ErrorState(kind = error, onRetry = viewModel::retry, compact = true)
                    }
                }
            }
        }
    }
}

@Composable
private fun GridSkeleton() {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize(),
        userScrollEnabled = false,
        contentPadding = PaddingValues(WbDimens.ScreenPadding),
        horizontalArrangement = Arrangement.spacedBy(WbDimens.CoverSpacing),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        items(12) {
            SkeletonBlock(Modifier.aspectRatio(2f / 3f), CoverShape)
        }
    }
}
