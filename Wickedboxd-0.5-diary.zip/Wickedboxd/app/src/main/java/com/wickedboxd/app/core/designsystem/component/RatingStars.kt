package com.wickedboxd.app.core.designsystem.component

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.icon.WbIcon
import com.wickedboxd.app.core.designsystem.icon.WbIcons
import com.wickedboxd.app.core.designsystem.theme.WbTheme
import com.wickedboxd.app.core.util.formatRating
import kotlin.math.ceil
import kotlin.math.round

/** Read-only 5-star display with half-star precision. */
@Composable
fun RatingStars(
    rating: Double,
    modifier: Modifier = Modifier,
    starSize: Dp = 16.dp,
    spacing: Dp = 2.dp,
) {
    val description = stringResource(R.string.rating_a11y, formatRating(rating))
    Row(
        modifier = modifier.semantics { contentDescription = description },
        horizontalArrangement = Arrangement.spacedBy(spacing),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(5) { index -> Star(fill = starFill(rating, index), size = starSize) }
    }
}

/**
 * Interactive rating, 0.5 .. 5.0 in half-star steps. A tap sets the value; dragging previews it and commits on release,
 * so a swipe causes one write, not twenty. Setting the same value again is the caller's business (see "Remove rating").
 */
@Composable
fun RatingInput(
    value: Double?,
    onValueChange: (Double) -> Unit,
    modifier: Modifier = Modifier,
    starSize: Dp = 40.dp,
    spacing: Dp = 6.dp,
) {
    val currentOnChange by rememberUpdatedState(onValueChange)
    var draft by remember { mutableStateOf<Double?>(null) }
    val shown = draft ?: value ?: 0.0
    val description = stringResource(R.string.rating_a11y, formatRating(shown))

    Row(
        modifier = modifier
            .semantics { contentDescription = description }
            .pointerInput(Unit) {
                detectTapGestures { offset -> currentOnChange(ratingAt(offset.x, size.width)) }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { offset -> draft = ratingAt(offset.x, size.width) },
                    onDragEnd = {
                        draft?.let { currentOnChange(it) }
                        draft = null
                    },
                    onDragCancel = { draft = null },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        draft = ratingAt(change.position.x, size.width)
                    },
                )
            },
        horizontalArrangement = Arrangement.spacedBy(spacing),
    ) {
        repeat(5) { index ->
            val fill = starFill(shown, index)
            val pop by animateFloatAsState(
                targetValue = if (fill > 0f) 1f else 0.88f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
                label = "starPop",
            )
            Star(
                fill = fill,
                size = starSize,
                modifier = Modifier.graphicsLayer {
                    scaleX = pop
                    scaleY = pop
                },
            )
        }
    }
}

/** 0, 0.5 or 1 for the star at [index] (0-based) of a rating. */
internal fun starFill(rating: Double, index: Int): Float {
    val part = (rating - index).coerceIn(0.0, 1.0)
    return (round(part * 2) / 2).toFloat()
}

private fun ratingAt(x: Float, width: Int): Double {
    if (width <= 0) return 0.5
    val fraction = (x / width).coerceIn(0f, 1f)
    return (ceil(fraction * 10.0) / 2.0).coerceIn(0.5, 5.0)
}

@Composable
private fun Star(fill: Float, size: Dp, modifier: Modifier = Modifier) {
    val colors = WbTheme.colors
    Box(modifier = modifier.size(size)) {
        WbIcon(
            WbIcons.Star,
            contentDescription = null,
            size = size,
            tint = if (fill > 0f) colors.star else colors.textSecondary.copy(alpha = 0.55f),
        )
        if (fill > 0f) {
            WbIcon(
                WbIcons.StarFilled,
                contentDescription = null,
                size = size,
                tint = colors.star,
                modifier = Modifier.drawWithContent {
                    clipRect(right = this.size.width * fill) {
                        this@drawWithContent.drawContent()
                    }
                },
            )
        }
    }
}
