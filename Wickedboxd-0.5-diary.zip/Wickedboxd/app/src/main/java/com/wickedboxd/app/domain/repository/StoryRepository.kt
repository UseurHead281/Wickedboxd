package com.wickedboxd.app.domain.repository

import com.wickedboxd.app.domain.model.CatalogSection
import com.wickedboxd.app.domain.model.RatingBucket
import com.wickedboxd.app.domain.model.StoryCard
import com.wickedboxd.app.domain.model.StoryDetails

class StoryNotFoundException : Exception("story_not_found")

interface StoryRepository {
    suspend fun section(section: CatalogSection, limit: Int, offset: Int = 0): List<StoryCard>
    suspend fun details(storyId: String): StoryDetails
    suspend fun ratingDistribution(storyId: String): List<RatingBucket>

    /** Rating in 0.5 steps (0.5..5.0). Replaces the user's current rating. */
    suspend fun setRating(storyId: String, rating: Double)
    suspend fun clearRating(storyId: String)
    suspend fun setFavorite(storyId: String, favorite: Boolean)
    suspend fun setWantToListen(storyId: String, want: Boolean)
}
