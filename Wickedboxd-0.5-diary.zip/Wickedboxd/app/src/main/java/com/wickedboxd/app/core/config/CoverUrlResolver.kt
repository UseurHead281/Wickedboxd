package com.wickedboxd.app.core.config

import android.net.Uri
import javax.inject.Inject
import javax.inject.Singleton

/** Turns object paths stored in the database into public Storage URLs (buckets `covers` and `avatars`). */
@Singleton
class CoverUrlResolver @Inject constructor(
    private val config: BackendConfig,
) {
    fun storyCover(path: String?): String? {
        if (path.isNullOrBlank() || !config.isConfigured) return null
        return "${config.supabaseUrl.trimEnd('/')}/storage/v1/object/public/covers/${Uri.encode(path, "/")}"
    }

    fun avatar(path: String?): String? {
        if (path.isNullOrBlank() || !config.isConfigured) return null
        return "${config.supabaseUrl.trimEnd('/')}/storage/v1/object/public/avatars/${Uri.encode(path, "/")}"
    }
}
