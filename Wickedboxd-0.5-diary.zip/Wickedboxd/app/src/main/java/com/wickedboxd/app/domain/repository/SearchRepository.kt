package com.wickedboxd.app.domain.repository

import com.wickedboxd.app.domain.model.SearchScope
import com.wickedboxd.app.domain.model.SearchSuggestion
import com.wickedboxd.app.domain.model.StoryCard
import com.wickedboxd.app.domain.model.UserCard

interface SearchRepository {
    suspend fun suggestions(query: String): List<SearchSuggestion>
    suspend fun searchStories(query: String, scope: SearchScope, limit: Int, offset: Int): List<StoryCard>
    suspend fun searchUsers(query: String, limit: Int): List<UserCard>

    /** Anonymous top queries of the last two weeks. */
    suspend fun popularSearches(): List<String>

    /** Feeds [popularSearches]. Only the text is stored, never shown with a user. */
    suspend fun logSearch(query: String)
}
