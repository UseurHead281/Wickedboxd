package com.wickedboxd.app.core.designsystem.theme

import androidx.compose.ui.graphics.Color
import com.wickedboxd.app.domain.model.AccentOption

/**
 * Raw brand colours. Dark values are taken verbatim from the product brief; light values follow the same
 * logic (the brief only defines dark). UI code reads [WbTheme.colors] and never these constants.
 */
internal object WbPalette {
    // Dark theme (default)
    val DarkBackground = Color(0xFF17181C)
    val DarkSurface = Color(0xFF202127)
    val DarkSurfaceElevated = Color(0xFF292A32)
    val DarkTopBar = Color(0xFF0E0F12) // "almost black" top/bottom bars; hex is not in the brief
    val DarkDivider = Color(0xFF34353D)
    val DarkTextPrimary = Color(0xFFFFFFFF)
    val DarkTextSecondary = Color(0xFFA4A5AE)
    val DarkError = Color(0xFFFF5C6C)

    // Light theme
    val LightBackground = Color(0xFFF4F3F8)
    val LightSurface = Color(0xFFFFFFFF)
    val LightSurfaceElevated = Color(0xFFEBE9F1)
    val LightTopBar = Color(0xFFFFFFFF)
    val LightDivider = Color(0xFFDAD8E2)
    val LightTextPrimary = Color(0xFF17181C)
    val LightTextSecondary = Color(0xFF666873)
    val LightError = Color(0xFFD92D3F)
}

/** Accent presets; hues are the colours of the brand-icon variants so the app and launcher icon match. */
fun AccentOption.toColor(): Color = when (this) {
    AccentOption.Violet -> Color(0xFF8B45F6) // brief: Primary
    AccentOption.Blue -> Color(0xFF527BFF)
    AccentOption.Red -> Color(0xFFD9364D)
    AccentOption.Orange -> Color(0xFFFF7A18)
    AccentOption.Teal -> Color(0xFF30C6B0)
    AccentOption.Ice -> Color(0xFF83CFFF)
}
