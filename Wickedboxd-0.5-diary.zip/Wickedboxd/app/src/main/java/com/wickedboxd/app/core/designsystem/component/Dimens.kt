package com.wickedboxd.app.core.designsystem.component

import androidx.compose.ui.unit.dp

/** Spacing shared by catalogue screens so rows and grids line up. */
object WbDimens {
    val ScreenPadding = 16.dp
    val CoverSpacing = 10.dp
    val SectionSpacing = 28.dp
}
