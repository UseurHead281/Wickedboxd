package com.wickedboxd.app.feature.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wickedboxd.app.domain.model.AuthError
import com.wickedboxd.app.domain.repository.AuthRepository
import com.wickedboxd.app.domain.validation.AuthValidation
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LoginUiState(
    val email: String = "",
    val password: String = "",
    val showPassword: Boolean = false,
    val emailInvalid: Boolean = false,
    val passwordMissing: Boolean = false,
    val isLoading: Boolean = false,
    val error: AuthError? = null,
)

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val auth: AuthRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(LoginUiState())
    val state: StateFlow<LoginUiState> = _state.asStateFlow()

    fun onEmailChange(value: String) = _state.update { it.copy(email = value, emailInvalid = false, error = null) }

    fun onPasswordChange(value: String) = _state.update { it.copy(password = value, passwordMissing = false, error = null) }

    fun toggleShowPassword() = _state.update { it.copy(showPassword = !it.showPassword) }

    fun submit() {
        val current = _state.value
        if (current.isLoading) return
        val emailOk = AuthValidation.isValidEmail(current.email)
        val passwordOk = current.password.isNotEmpty()
        if (!emailOk || !passwordOk) {
            _state.update { it.copy(emailInvalid = !emailOk, passwordMissing = !passwordOk) }
            return
        }
        _state.update { it.copy(isLoading = true, error = null) }
        viewModelScope.launch {
            val error = runAuth { auth.signIn(current.email, current.password) }
            // on success the app root swaps to the main app by itself (AuthState.SignedIn)
            _state.update { it.copy(isLoading = false, error = error) }
        }
    }
}
