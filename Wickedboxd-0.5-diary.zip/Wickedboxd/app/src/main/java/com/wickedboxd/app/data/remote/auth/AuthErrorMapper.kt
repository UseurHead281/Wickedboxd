package com.wickedboxd.app.data.remote.auth

import com.wickedboxd.app.core.util.BackendNotConfiguredException
import com.wickedboxd.app.core.util.ErrorKind
import com.wickedboxd.app.core.util.toErrorKind
import com.wickedboxd.app.domain.model.AuthError
import com.wickedboxd.app.domain.model.AuthException
import kotlin.coroutines.cancellation.CancellationException

/**
 * Maps a failure message from Supabase Auth (GoTrue) to an [AuthError]. Matching on text is not pretty, but the
 * messages are stable API strings and this keeps all of it in one tested place.
 */
fun mapAuthFailureMessage(message: String?): AuthError {
    val m = message?.lowercase().orEmpty()
    return when {
        "invalid login credentials" in m || "invalid credentials" in m -> AuthError.InvalidCredentials
        "email not confirmed" in m || "not confirmed" in m -> AuthError.EmailNotConfirmed
        "already registered" in m || "already been registered" in m || "email_exists" in m -> AuthError.EmailTaken
        // the sign-up trigger raises a unique violation when the username is taken
        "database error saving new user" in m || "username" in m && ("taken" in m || "duplicate" in m) -> AuthError.UsernameTaken
        "password should be" in m || "weak_password" in m || "password is too" in m -> AuthError.WeakPassword
        "rate limit" in m || "over_email_send_rate_limit" in m || "too many requests" in m || "429" in m -> AuthError.RateLimited
        else -> AuthError.Unknown
    }
}

fun Throwable.toAuthError(): AuthError = when {
    this is CancellationException -> throw this
    this is AuthException -> error
    this is BackendNotConfiguredException -> AuthError.NotConfigured
    toErrorKind() == ErrorKind.Network -> AuthError.Network
    else -> mapAuthFailureMessage(message)
}
