package com.wickedboxd.app.core.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.wickedboxd.app.feature.activity.ActivityScreen
import com.wickedboxd.app.feature.add.AddScreen
import com.wickedboxd.app.feature.catalog.CatalogScreen
import com.wickedboxd.app.feature.catalog.StoryListScreen
import com.wickedboxd.app.feature.profile.ProfileScreen
import com.wickedboxd.app.feature.search.SearchScreen
import com.wickedboxd.app.feature.story.StoryDetailScreen
import com.wickedboxd.app.feature.user.UserProfileScreen

private const val FadeInMillis = 220
private const val FadeOutMillis = 90

@Composable
fun WickedboxdNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier,
) {
    val openStory: (String) -> Unit = { id -> navController.navigate(StoryRoute(id)) }
    val openUser: (String) -> Unit = { id -> navController.navigate(UserRoute(id)) }

    NavHost(
        navController = navController,
        startDestination = CatalogRoute,
        modifier = modifier,
        // Tabs cross-fade: quick fade-out, slightly delayed fade-in. No sliding between tabs.
        enterTransition = { fadeIn(tween(FadeInMillis, delayMillis = 60)) },
        exitTransition = { fadeOut(tween(FadeOutMillis)) },
        popEnterTransition = { fadeIn(tween(FadeInMillis, delayMillis = 60)) },
        popExitTransition = { fadeOut(tween(FadeOutMillis)) },
    ) {
        composable<CatalogRoute> {
            CatalogScreen(
                onStoryClick = openStory,
                onSeeAll = { section -> navController.navigate(StoryListRoute(section.name)) },
            )
        }
        composable<SearchRoute> { SearchScreen(onStoryClick = openStory, onUserClick = openUser) }
        composable<AddRoute>(
            // Modal: rises from the bottom, leaves the same way.
            enterTransition = { slideInVertically(tween(280)) { it } },
            exitTransition = { fadeOut(tween(FadeOutMillis)) },
            popEnterTransition = { fadeIn(tween(FadeInMillis)) },
            popExitTransition = { slideOutVertically(tween(240)) { it } },
        ) {
            AddScreen(onClose = { navController.popBackStack() })
        }
        composable<ActivityRoute> { ActivityScreen() }
        composable<ProfileRoute> { ProfileScreen() }

        // Drill-down pages: a short slide in from the right, a quiet fade out underneath.
        composable<StoryListRoute>(
            enterTransition = { slideInHorizontally(tween(260)) { it / 6 } + fadeIn(tween(FadeInMillis)) },
            exitTransition = { fadeOut(tween(FadeOutMillis)) },
            popEnterTransition = { fadeIn(tween(FadeInMillis)) },
            popExitTransition = { slideOutHorizontally(tween(220)) { it / 6 } + fadeOut(tween(180)) },
        ) {
            StoryListScreen(onBack = { navController.popBackStack() }, onStoryClick = openStory)
        }
        composable<StoryRoute>(
            enterTransition = { slideInHorizontally(tween(260)) { it / 6 } + fadeIn(tween(FadeInMillis)) },
            exitTransition = { fadeOut(tween(FadeOutMillis)) },
            popEnterTransition = { fadeIn(tween(FadeInMillis)) },
            popExitTransition = { slideOutHorizontally(tween(220)) { it / 6 } + fadeOut(tween(180)) },
        ) {
            StoryDetailScreen(
                onBack = { navController.popBackStack() },
                onLogListen = { id -> navController.navigate(AddRoute(id)) { launchSingleTop = true } },
            )
        }
        composable<UserRoute>(
            enterTransition = { slideInHorizontally(tween(260)) { it / 6 } + fadeIn(tween(FadeInMillis)) },
            exitTransition = { fadeOut(tween(FadeOutMillis)) },
            popEnterTransition = { fadeIn(tween(FadeInMillis)) },
            popExitTransition = { slideOutHorizontally(tween(220)) { it / 6 } + fadeOut(tween(180)) },
        ) {
            UserProfileScreen(onBack = { navController.popBackStack() })
        }
    }
}
