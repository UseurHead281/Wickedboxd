package com.wickedboxd.app.feature.search

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.EmptyState
import com.wickedboxd.app.core.designsystem.component.ErrorState
import com.wickedboxd.app.core.designsystem.component.SkeletonBlock
import com.wickedboxd.app.core.designsystem.component.StoryCover
import com.wickedboxd.app.core.designsystem.component.WbDimens
import com.wickedboxd.app.core.designsystem.component.WbFilterChip
import com.wickedboxd.app.core.designsystem.component.WbSearchField
import com.wickedboxd.app.core.designsystem.component.WbTabStrip
import com.wickedboxd.app.core.designsystem.icon.WbIcon
import com.wickedboxd.app.core.designsystem.icon.WbIcons
import com.wickedboxd.app.core.designsystem.theme.CoverShape
import com.wickedboxd.app.core.designsystem.theme.WbTheme
import com.wickedboxd.app.domain.model.SearchScope
import com.wickedboxd.app.domain.model.SuggestionKind
import com.wickedboxd.app.domain.validation.SearchQuery
import com.wickedboxd.app.feature.user.UserRow

private enum class SearchMode { Idle, Suggestions, Results }

private const val LOAD_MORE_THRESHOLD = 6

/**
 * Search: nothing typed -> recent + popular queries; typing -> live suggestions (stories, authors, narrators,
 * genres, tags, users); submitted -> results with "Stories / Users" tabs and category chips.
 */
@Composable
fun SearchScreen(
    onStoryClick: (String) -> Unit,
    onUserClick: (String) -> Unit,
    viewModel: SearchViewModel = hiltViewModel(),
) {
    val colors = WbTheme.colors
    val state by viewModel.state.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is SearchEvent.OpenStory -> onStoryClick(event.id)
                is SearchEvent.OpenUser -> onUserClick(event.id)
            }
        }
    }

    val mode = when {
        state.submitted != null -> SearchMode.Results
        SearchQuery.normalize(state.query).length >= SearchQuery.MIN_LENGTH -> SearchMode.Suggestions
        else -> SearchMode.Idle
    }

    Column(Modifier.fillMaxSize().background(colors.background)) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(colors.topBar)
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
        ) {
            WbSearchField(
                value = state.query,
                onValueChange = viewModel::onQueryChange,
                hint = stringResource(R.string.search_hint),
                onSearch = {
                    focus.clearFocus()
                    viewModel.submit()
                },
            )
        }
        HorizontalDivider(color = colors.divider)
        Crossfade(
            targetState = mode,
            modifier = Modifier.weight(1f),
            animationSpec = tween(150),
            label = "searchMode",
        ) { current ->
            when (current) {
                SearchMode.Idle -> IdleContent(
                    state = state,
                    onSubmit = { query ->
                        focus.clearFocus()
                        viewModel.submit(query)
                    },
                    onRemoveRecent = viewModel::removeRecent,
                    onClearRecent = viewModel::clearRecent,
                )
                SearchMode.Suggestions -> SuggestionsContent(
                    state = state,
                    onSubmitQuery = {
                        focus.clearFocus()
                        viewModel.submit()
                    },
                    onSuggestion = { suggestion ->
                        focus.clearFocus()
                        viewModel.onSuggestionClick(suggestion)
                    },
                )
                SearchMode.Results -> ResultsContent(
                    state = state,
                    coverUrl = viewModel::coverUrl,
                    avatarUrl = viewModel::avatarUrl,
                    onSelectTab = viewModel::selectTab,
                    onSelectScope = viewModel::selectScope,
                    onRetry = viewModel::retry,
                    onLoadMore = viewModel::loadMoreStories,
                    onStoryClick = onStoryClick,
                    onUserClick = onUserClick,
                )
            }
        }
    }
}

// ------------------------------------------------------------------ idle: history + popular
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun IdleContent(
    state: SearchUiState,
    onSubmit: (String) -> Unit,
    onRemoveRecent: (String) -> Unit,
    onClearRecent: () -> Unit,
) {
    if (state.recent.isEmpty() && state.popular.isEmpty()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            EmptyState(title = stringResource(R.string.nav_search), subtitle = stringResource(R.string.search_idle_hint))
        }
    } else {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)) {
            if (state.recent.isNotEmpty()) {
                item(key = "recent-title") {
                    BlockTitle(
                        title = stringResource(R.string.search_recent),
                        action = stringResource(R.string.search_recent_clear),
                        onAction = onClearRecent,
                    )
                }
                items(state.recent, key = { "recent:$it" }) { query ->
                    SearchLine(
                        icon = WbIcons.Clock,
                        text = query,
                        onClick = { onSubmit(query) },
                        trailing = {
                            IconAction(
                                icon = WbIcons.Close,
                                description = stringResource(R.string.search_recent_remove),
                                onClick = { onRemoveRecent(query) },
                            )
                        },
                    )
                }
            }
            if (state.popular.isNotEmpty()) {
                item(key = "popular-title") { BlockTitle(title = stringResource(R.string.search_popular)) }
                item(key = "popular-chips") {
                    FlowRow(
                        modifier = Modifier.padding(horizontal = WbDimens.ScreenPadding),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        state.popular.forEach { query ->
                            WbFilterChip(text = query, selected = false, onClick = { onSubmit(query) })
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ typing: autocomplete
@Composable
private fun SuggestionsContent(
    state: SearchUiState,
    onSubmitQuery: () -> Unit,
    onSuggestion: (com.wickedboxd.app.domain.model.SearchSuggestion) -> Unit,
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp)) {
        item(key = "search-for") {
            SearchLine(
                icon = WbIcons.Search,
                text = stringResource(R.string.search_for, SearchQuery.normalize(state.query)),
                onClick = onSubmitQuery,
            )
        }
        items(state.suggestions, key = { "${it.kind}:${it.ref}:${it.label}" }) { suggestion ->
            SearchLine(
                icon = suggestion.kind.icon(),
                text = suggestion.label,
                secondary = stringResource(suggestion.kind.labelRes()),
                onClick = { onSuggestion(suggestion) },
            )
        }
    }
}

// ------------------------------------------------------------------ results
@Composable
private fun ResultsContent(
    state: SearchUiState,
    coverUrl: (String?) -> String?,
    avatarUrl: (String?) -> String?,
    onSelectTab: (SearchTab) -> Unit,
    onSelectScope: (SearchScope) -> Unit,
    onRetry: () -> Unit,
    onLoadMore: () -> Unit,
    onStoryClick: (String) -> Unit,
    onUserClick: (String) -> Unit,
) {
    val colors = WbTheme.colors
    val titles = listOf(stringResource(R.string.search_tab_stories), stringResource(R.string.search_tab_users))
    Column(Modifier.fillMaxSize()) {
        WbTabStrip(
            titles = titles,
            selectedIndex = state.tab.ordinal,
            onSelect = { onSelectTab(SearchTab.entries[it]) },
        )
        HorizontalDivider(color = colors.divider)
        when (state.tab) {
            SearchTab.Stories -> StoriesResults(state, coverUrl, onSelectScope, onRetry, onLoadMore, onStoryClick)
            SearchTab.Users -> UsersResults(state, avatarUrl, onRetry, onUserClick)
        }
    }
}

@Composable
private fun StoriesResults(
    state: SearchUiState,
    coverUrl: (String?) -> String?,
    onSelectScope: (SearchScope) -> Unit,
    onRetry: () -> Unit,
    onLoadMore: () -> Unit,
    onStoryClick: (String) -> Unit,
) {
    val colors = WbTheme.colors
    val error = state.error
    Column(Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = WbDimens.ScreenPadding, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(SearchScope.entries, key = { it.name }) { scope ->
                WbFilterChip(
                    text = stringResource(scope.labelRes()),
                    selected = scope == state.scope,
                    onClick = { onSelectScope(scope) },
                )
            }
        }
        when {
            state.storiesLoading -> StoryGridSkeleton()
            error != null && state.stories.isEmpty() -> ErrorState(kind = error, onRetry = onRetry)
            state.storiesLoaded && state.stories.isEmpty() -> EmptyState(
                title = stringResource(R.string.search_empty_title),
                subtitle = stringResource(R.string.search_empty_subtitle),
            )
            else -> {
                val gridState = rememberLazyGridState()
                val nearEnd by remember {
                    derivedStateOf {
                        val last = gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                        last >= gridState.layoutInfo.totalItemsCount - LOAD_MORE_THRESHOLD
                    }
                }
                LaunchedEffect(nearEnd, state.stories.size) {
                    if (nearEnd && state.stories.isNotEmpty()) onLoadMore()
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    state = gridState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = WbDimens.ScreenPadding, end = WbDimens.ScreenPadding, top = 4.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(WbDimens.CoverSpacing),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    items(state.stories, key = { it.id }) { story ->
                        StoryCover(
                            title = story.title,
                            coverUrl = coverUrl(story.coverPath),
                            rating = story.myRating,
                            isFavorite = story.isFavorite,
                            onClick = { onStoryClick(story.id) },
                        )
                    }
                    if (state.storiesLoadingMore) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(strokeWidth = 2.dp, color = colors.accent, modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UsersResults(
    state: SearchUiState,
    avatarUrl: (String?) -> String?,
    onRetry: () -> Unit,
    onUserClick: (String) -> Unit,
) {
    val error = state.error
    when {
        state.usersLoading -> UsersSkeleton()
        error != null && state.users.isEmpty() -> ErrorState(kind = error, onRetry = onRetry)
        state.usersLoaded && state.users.isEmpty() -> EmptyState(
            title = stringResource(R.string.search_empty_title),
            subtitle = stringResource(R.string.search_empty_subtitle),
        )
        else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(state.users, key = { it.id }) { user ->
                UserRow(user = user, avatarUrl = avatarUrl(user.avatarPath), onClick = { onUserClick(user.id) })
            }
        }
    }
}

@Composable
private fun StoryGridSkeleton() {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize(),
        userScrollEnabled = false,
        contentPadding = PaddingValues(start = WbDimens.ScreenPadding, end = WbDimens.ScreenPadding, top = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(WbDimens.CoverSpacing),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        items(9) { SkeletonBlock(Modifier.aspectRatio(2f / 3f), CoverShape) }
    }
}

@Composable
private fun UsersSkeleton() {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        repeat(6) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                SkeletonBlock(Modifier.size(48.dp), CircleShape)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SkeletonBlock(Modifier.size(width = 160.dp, height = 14.dp))
                    SkeletonBlock(Modifier.size(width = 96.dp, height = 12.dp))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ small pieces
@Composable
private fun BlockTitle(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
    val colors = WbTheme.colors
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = WbDimens.ScreenPadding, end = 8.dp, top = 12.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = colors.textSecondary,
            modifier = Modifier.weight(1f),
        )
        if (action != null && onAction != null) {
            Text(
                text = action,
                style = MaterialTheme.typography.labelLarge,
                color = colors.accent,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(role = Role.Button, onClick = onAction)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun SearchLine(
    @DrawableRes icon: Int,
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    secondary: String? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    val colors = WbTheme.colors
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(start = WbDimens.ScreenPadding, end = if (trailing != null) 8.dp else WbDimens.ScreenPadding),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        WbIcon(icon, contentDescription = null, size = 20.dp, tint = colors.textSecondary)
        Column(Modifier.weight(1f)) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyLarge,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (secondary != null) {
                Text(text = secondary, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary, maxLines = 1)
            }
        }
        trailing?.invoke()
    }
}

@Composable
private fun IconAction(@DrawableRes icon: Int, description: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        WbIcon(icon, contentDescription = description, size = 18.dp, tint = WbTheme.colors.textSecondary)
    }
}

@DrawableRes
private fun SuggestionKind.icon(): Int = when (this) {
    SuggestionKind.Story -> WbIcons.Catalog
    SuggestionKind.Author -> WbIcons.Edit
    SuggestionKind.Narrator -> WbIcons.Headphones
    SuggestionKind.Genre -> WbIcons.Lists
    SuggestionKind.Tag -> WbIcons.Filter
    SuggestionKind.User -> WbIcons.Profile
}

@StringRes
private fun SuggestionKind.labelRes(): Int = when (this) {
    SuggestionKind.Story -> R.string.kind_story
    SuggestionKind.Author -> R.string.kind_author
    SuggestionKind.Narrator -> R.string.kind_narrator
    SuggestionKind.Genre -> R.string.kind_genre
    SuggestionKind.Tag -> R.string.kind_tag
    SuggestionKind.User -> R.string.kind_user
}

@StringRes
private fun SearchScope.labelRes(): Int = when (this) {
    SearchScope.All -> R.string.scope_all
    SearchScope.Title -> R.string.scope_title
    SearchScope.Author -> R.string.scope_author
    SearchScope.Narrator -> R.string.scope_narrator
    SearchScope.Genre -> R.string.scope_genre
    SearchScope.Tag -> R.string.scope_tag
}
