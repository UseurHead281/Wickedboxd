package com.wickedboxd.app.feature.auth

import kotlinx.serialization.Serializable

@Serializable
data object AuthWelcomeRoute

@Serializable
data object AuthLoginRoute

@Serializable
data object AuthRegisterRoute

@Serializable
data object AuthForgotRoute

@Serializable
data class AuthVerifyRoute(val email: String)
