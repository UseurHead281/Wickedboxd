package com.wickedboxd.app.core.util

import java.io.IOException
import kotlin.coroutines.cancellation.CancellationException

/** Thrown when local.properties has no Supabase URL / anon key yet. */
class BackendNotConfiguredException : Exception("backend_not_configured")

/** What the UI can tell the user. Kept tiny on purpose: one message per recovery action. */
enum class ErrorKind { Network, NotConfigured, Unauthorized, Unknown }

private val NETWORK_ERROR_NAMES = setOf(
    "UnresolvedAddressException", "UnknownHostException", "HttpRequestTimeoutException", "SocketTimeoutException",
    "ConnectTimeoutException", "ConnectException", "HttpRequestException",
)

/** Never swallows coroutine cancellation: it is rethrown. */
fun Throwable.toErrorKind(): ErrorKind = when {
    this is CancellationException -> throw this
    this is BackendNotConfiguredException -> ErrorKind.NotConfigured
    this is IOException || this::class.simpleName in NETWORK_ERROR_NAMES -> ErrorKind.Network
    message?.contains("JWT", ignoreCase = true) == true ||
        message?.contains("not_authenticated", ignoreCase = true) == true -> ErrorKind.Unauthorized
    else -> ErrorKind.Unknown
}
