package com.wickedboxd.app.core.navigation

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.selection.selectable
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import com.wickedboxd.app.core.designsystem.icon.WbIcon
import com.wickedboxd.app.core.designsystem.icon.WbIcons
import com.wickedboxd.app.core.designsystem.theme.WbTheme

private val BarHeight = 64.dp
private val ActionIconSize = 48.dp // the accent disc is 20/24 of this -> 40dp disc
private const val MaxFontScale = 1.15f

/**
 * Wickedboxd bottom navigation: Catalog, Search, Add (accent disc), Activity, Profile.
 * [selected] is null on screens that do not belong to a tab.
 */
@Composable
fun WbBottomBar(
    selected: TopLevelDestination?,
    onDestinationClick: (TopLevelDestination) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = WbTheme.colors
    CappedFontScale(MaxFontScale) {
        Column(modifier = modifier.background(colors.topBar)) {
            HorizontalDivider(color = colors.divider)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .height(BarHeight),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TopLevelDestination.entries.forEach { destination ->
                    BottomBarItem(
                        destination = destination,
                        selected = destination == selected,
                        onClick = { onDestinationClick(destination) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

@Composable
private fun BottomBarItem(
    destination: TopLevelDestination,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = WbTheme.colors
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val pressScale by animateFloatAsState(if (pressed) 0.9f else 1f, tween(90), label = "bottomBarPress")
    val tint by animateColorAsState(
        targetValue = if (selected) colors.textPrimary else colors.textSecondary,
        animationSpec = tween(180),
        label = "bottomBarTint",
    )
    val label = stringResource(destination.label)

    Box(
        modifier = modifier
            .fillMaxHeight()
            .selectable(
                selected = selected,
                interactionSource = interactionSource,
                indication = null,
                role = if (destination.isAction) Role.Button else Role.Tab,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (destination.isAction) {
            // Two tintable layers of the supplied "add accent" icon: the disc follows the user's accent colour.
            Box(
                modifier = Modifier.graphicsLayer { scaleX = pressScale; scaleY = pressScale },
                contentAlignment = Alignment.Center,
            ) {
                WbIcon(WbIcons.AddLogAccentBackground, null, size = ActionIconSize, tint = colors.accent)
                WbIcon(WbIcons.AddLogAccentForeground, label, size = ActionIconSize, tint = colors.onAccent)
            }
        } else {
            Column(
                modifier = Modifier.graphicsLayer { scaleX = pressScale; scaleY = pressScale },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                WbIcon(destination.icon, contentDescription = null, tint = tint)
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = tint,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/** Bars keep a stable layout when the user enlarges system fonts. */
@Composable
private fun CappedFontScale(max: Float, content: @Composable () -> Unit) {
    val density = LocalDensity.current
    val capped = remember(density) { Density(density.density, minOf(density.fontScale, max)) }
    CompositionLocalProvider(LocalDensity provides capped, content = content)
}
