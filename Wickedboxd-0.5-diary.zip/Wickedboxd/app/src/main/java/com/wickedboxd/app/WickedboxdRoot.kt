package com.wickedboxd.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.wickedboxd.app.core.designsystem.theme.WbTheme
import com.wickedboxd.app.core.navigation.TopLevelDestination
import com.wickedboxd.app.core.navigation.WbBottomBar
import com.wickedboxd.app.core.navigation.WickedboxdNavHost

/**
 * App shell: bottom bar + navigation host.
 * The bar stays visible on the four tabs AND on drill-down pages (story, "see all") opened from them, with the tab
 * they came from highlighted; it is hidden only on the modal Add screen.
 */
@Composable
fun WickedboxdRoot() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination

    // The tab whose root is on screen right now (null on drill-down pages).
    val currentTab = TopLevelDestination.entries.firstOrNull { top ->
        currentDestination?.hierarchy?.any { it.hasRoute(top.route::class) } == true
    }
    var lastTab by rememberSaveable { mutableStateOf(TopLevelDestination.Catalog) }
    LaunchedEffect(currentTab) {
        if (currentTab != null && !currentTab.isAction) lastTab = currentTab
    }
    val showBottomBar = currentTab?.isAction != true
    val selected = if (currentTab?.isAction == true) null else (currentTab ?: lastTab)

    Scaffold(
        containerColor = WbTheme.colors.background,
        // Each screen draws its own top bar and applies status-bar insets itself.
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            AnimatedVisibility(
                visible = showBottomBar,
                enter = slideInVertically(tween(200)) { it } + fadeIn(tween(200)),
                exit = slideOutVertically(tween(160)) { it } + fadeOut(tween(160)),
            ) {
                WbBottomBar(
                    selected = selected,
                    onDestinationClick = { target ->
                        when {
                            target.isAction -> navController.navigate(target.route) { launchSingleTop = true }
                            // tapping the current tab while deep inside it returns to the tab's root
                            target == selected && currentTab == null ->
                                navController.popBackStack(target.route, inclusive = false)
                            else -> navController.navigate(target.route) {
                                // One back stack per tab, state kept when switching back.
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    },
                )
            }
        },
    ) { innerPadding ->
        WickedboxdNavHost(navController = navController, modifier = Modifier.padding(innerPadding))
    }
}
