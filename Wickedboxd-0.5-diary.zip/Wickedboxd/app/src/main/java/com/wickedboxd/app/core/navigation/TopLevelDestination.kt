package com.wickedboxd.app.core.navigation

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import com.wickedboxd.app.R

/**
 * The five bottom-bar entries, left to right. [isAction] marks the centre button, which opens a modal
 * "log a listen" screen instead of switching tab.
 */
enum class TopLevelDestination(
    val route: Any,
    @DrawableRes val icon: Int,
    @StringRes val label: Int,
    val isAction: Boolean = false,
) {
    Catalog(CatalogRoute, R.drawable.ic_wb_catalog, R.string.nav_catalog),
    Search(SearchRoute, R.drawable.ic_wb_search, R.string.nav_search),
    Add(AddRoute(), R.drawable.ic_wb_add_log, R.string.nav_add, isAction = true),
    Activity(ActivityRoute, R.drawable.ic_wb_activity, R.string.nav_activity),
    Profile(ProfileRoute, R.drawable.ic_wb_profile, R.string.nav_profile),
}
