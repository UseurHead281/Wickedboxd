package com.wickedboxd.app.feature.auth

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.AuthScaffold
import com.wickedboxd.app.core.designsystem.component.WbPrimaryButton
import com.wickedboxd.app.core.designsystem.theme.WbTheme

/** Shown instead of the app right after a password-reset link was opened. */
@Composable
fun ResetPasswordScreen(viewModel: ResetPasswordViewModel = hiltViewModel()) {
    val colors = WbTheme.colors
    val state by viewModel.state.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current

    AuthScaffold(title = stringResource(R.string.reset_title)) {
        Text(
            text = stringResource(R.string.reset_description),
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary,
        )
        PasswordField(
            value = state.password,
            onValueChange = viewModel::onPasswordChange,
            label = stringResource(R.string.field_new_password),
            show = state.showPassword,
            onToggleShow = viewModel::toggleShowPassword,
            errorText = state.passwordProblem?.let { stringResource(it.messageRes()) },
            hintText = stringResource(R.string.password_hint),
            imeAction = ImeAction.Next,
            onDone = { focus.moveFocus(FocusDirection.Down) },
        )
        PasswordField(
            value = state.confirm,
            onValueChange = viewModel::onConfirmChange,
            label = stringResource(R.string.field_confirm_password),
            show = state.showPassword,
            onToggleShow = viewModel::toggleShowPassword,
            errorText = if (state.mismatch) stringResource(R.string.password_mismatch) else null,
            imeAction = ImeAction.Done,
            onDone = {
                focus.clearFocus()
                viewModel.submit()
            },
        )
        state.error?.let { FormError(stringResource(it.messageRes())) }
        WbPrimaryButton(
            text = stringResource(R.string.reset_submit),
            onClick = viewModel::submit,
            loading = state.isLoading,
        )
    }
}
