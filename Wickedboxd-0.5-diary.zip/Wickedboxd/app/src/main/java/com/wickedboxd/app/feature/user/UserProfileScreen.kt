package com.wickedboxd.app.feature.user

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.Avatar
import com.wickedboxd.app.core.designsystem.component.EmptyState
import com.wickedboxd.app.core.designsystem.component.ErrorState
import com.wickedboxd.app.core.designsystem.component.SkeletonBlock
import com.wickedboxd.app.core.designsystem.component.WbBackBar
import com.wickedboxd.app.core.designsystem.component.WbPrimaryButton
import com.wickedboxd.app.core.designsystem.component.WbSecondaryButton
import com.wickedboxd.app.core.designsystem.theme.WbTheme
import com.wickedboxd.app.core.util.quantityString
import com.wickedboxd.app.domain.model.UserCard

/**
 * Public profile: identity, counters and the follow button. Stats, rating chart, diary calendar and the
 * Stories / Reviews / Lists / Favorites tabs are added in the profile stage.
 */
@Composable
fun UserProfileScreen(
    onBack: () -> Unit,
    viewModel: UserProfileViewModel = hiltViewModel(),
) {
    val colors = WbTheme.colors
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val failedText = stringResource(R.string.user_follow_failed)
    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                UserProfileEvent.FollowFailed -> snackbarHostState.showSnackbar(failedText)
            }
        }
    }

    Box(Modifier.fillMaxSize().background(colors.background)) {
        Column(Modifier.fillMaxSize()) {
            WbBackBar(onBack = onBack)
            val user = state.user
            val error = state.error
            when {
                user != null -> ProfileContent(
                    user = user,
                    avatarUrl = viewModel.avatarUrl(user.avatarPath),
                    onToggleFollow = viewModel::toggleFollow,
                )
                state.isLoading -> ProfileSkeleton()
                state.notFound -> EmptyState(
                    title = stringResource(R.string.user_not_found),
                    subtitle = stringResource(R.string.user_not_found_subtitle),
                )
                error != null -> ErrorState(kind = error, onRetry = viewModel::load)
            }
        }
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
        )
    }
}

@Composable
private fun ProfileContent(user: UserCard, avatarUrl: String?, onToggleFollow: () -> Unit) {
    val colors = WbTheme.colors
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Avatar(name = user.displayName, imageUrl = avatarUrl, size = 96.dp)
        Spacer(Modifier.height(4.dp))
        Text(
            text = user.displayName,
            style = MaterialTheme.typography.headlineSmall,
            color = colors.textPrimary,
            textAlign = TextAlign.Center,
        )
        Text(text = "@${user.username}", style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary)
        user.bio?.takeIf { it.isNotBlank() }?.let { bio ->
            Text(
                text = bio,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp),
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp), modifier = Modifier.padding(top = 6.dp)) {
            Text(
                text = quantityString(R.plurals.followers_count, user.followersCount, user.followersCount),
                style = MaterialTheme.typography.titleSmall,
                color = colors.textPrimary,
            )
            Text(
                text = quantityString(R.plurals.following_count, user.followingCount, user.followingCount),
                style = MaterialTheme.typography.titleSmall,
                color = colors.textPrimary,
            )
        }
        Spacer(Modifier.height(8.dp))
        when {
            user.isMe -> Text(
                text = stringResource(R.string.user_this_is_you),
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
            )
            user.isFollowing -> WbSecondaryButton(
                text = stringResource(R.string.user_following),
                onClick = onToggleFollow,
                modifier = Modifier.widthIn(max = 320.dp),
            )
            else -> WbPrimaryButton(
                text = stringResource(R.string.user_follow),
                onClick = onToggleFollow,
                modifier = Modifier.widthIn(max = 320.dp),
            )
        }
    }
}

@Composable
private fun ProfileSkeleton() {
    Column(
        modifier = Modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        SkeletonBlock(Modifier.size(96.dp), CircleShape)
        SkeletonBlock(Modifier.size(width = 180.dp, height = 24.dp))
        SkeletonBlock(Modifier.size(width = 110.dp, height = 16.dp))
        SkeletonBlock(Modifier.size(width = 240.dp, height = 16.dp))
    }
}
