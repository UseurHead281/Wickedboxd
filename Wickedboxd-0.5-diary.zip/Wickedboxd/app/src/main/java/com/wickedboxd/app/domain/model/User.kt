package com.wickedboxd.app.domain.model

/** Public identity of a user plus the relation of the signed-in user to them. Never contains the role. */
data class UserCard(
    val id: String,
    val username: String,
    val displayName: String,
    val bio: String?,
    val avatarPath: String?,
    val websiteUrl: String?,
    val followersCount: Int,
    val followingCount: Int,
    val isFollowing: Boolean,
    val isMe: Boolean,
)
