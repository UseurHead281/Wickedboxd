package com.wickedboxd.app.feature.auth

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.AuthScaffold
import com.wickedboxd.app.core.designsystem.component.WbSecondaryButton
import com.wickedboxd.app.core.designsystem.component.WbTextLink
import com.wickedboxd.app.core.designsystem.theme.WbTheme

/**
 * "Check your mail". The account exists but cannot sign in until the link in the message is opened on this phone
 * (it returns to the app through the wickedboxd://auth-callback deep link and signs the user in).
 */
@Composable
fun VerifyEmailScreen(
    onBackToLogin: () -> Unit,
    viewModel: VerifyEmailViewModel = hiltViewModel(),
) {
    val colors = WbTheme.colors
    val state by viewModel.state.collectAsStateWithLifecycle()

    AuthScaffold(title = stringResource(R.string.verify_title), onBack = onBackToLogin) {
        Text(
            text = stringResource(R.string.verify_description, viewModel.email),
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary,
        )
        state.error?.let { FormError(stringResource(it.messageRes())) }
        if (state.sentAgain) {
            Text(
                text = stringResource(R.string.verify_sent_again),
                style = MaterialTheme.typography.bodyMedium,
                color = colors.accent,
            )
        }
        WbSecondaryButton(
            text = if (state.cooldownSeconds > 0) {
                stringResource(R.string.verify_resend_in, state.cooldownSeconds)
            } else {
                stringResource(R.string.verify_resend)
            },
            onClick = viewModel::resend,
            enabled = state.cooldownSeconds == 0 && !state.isSending,
        )
        WbTextLink(text = stringResource(R.string.back_to_login), onClick = onBackToLogin)
    }
}
