package com.wickedboxd.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class WickedboxdApp : Application()
