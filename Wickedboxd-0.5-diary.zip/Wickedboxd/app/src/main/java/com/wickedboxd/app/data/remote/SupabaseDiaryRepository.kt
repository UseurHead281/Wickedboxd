package com.wickedboxd.app.data.remote

import com.wickedboxd.app.core.config.BackendConfig
import com.wickedboxd.app.core.util.BackendNotConfiguredException
import com.wickedboxd.app.data.remote.dto.DiaryEntryDto
import com.wickedboxd.app.data.remote.dto.ProfileStatsDto
import com.wickedboxd.app.data.remote.dto.toDomain
import com.wickedboxd.app.domain.model.DiaryEntry
import com.wickedboxd.app.domain.model.LogListenRequest
import com.wickedboxd.app.domain.model.ProfileStats
import com.wickedboxd.app.domain.repository.DiaryRepository
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Order
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.put

/**
 * Reads the `diary_entries` view (RLS decides whose entries are visible); writes go through `log_listen`,
 * which creates the entry and upserts rating + review in one transaction with the caller's rights.
 */
@Singleton
class SupabaseDiaryRepository @Inject constructor(
    private val supabase: SupabaseClient,
    private val config: BackendConfig,
) : DiaryRepository {

    override suspend fun entries(userId: String, from: LocalDate?, to: LocalDate?, limit: Int, offset: Int): List<DiaryEntry> {
        if (!config.isConfigured) throw BackendNotConfiguredException()
        return supabase.from("diary_entries")
            .select {
                filter {
                    eq("user_id", userId)
                    if (from != null) gte("listened_on", from.toString())
                    if (to != null) lte("listened_on", to.toString())
                }
                order("listened_on", Order.DESCENDING)
                order("created_at", Order.DESCENDING)
                range(offset.toLong(), (offset + limit - 1).toLong())
            }
            .decodeList<DiaryEntryDto>()
            .map { it.toDomain() }
    }

    override suspend fun logListen(request: LogListenRequest): String =
        supabase.callRpc(config, "log_listen") {
            put("p_story_id", request.storyId)
            put("p_listened_on", request.date.toString())
            if (request.rating != null) put("p_rating", request.rating) else put("p_rating", JsonNull)
            put("p_note", request.note)
            put("p_review_body", request.review)
            put("p_is_relisten", request.isRelisten)
        }.decodeAs<String>()

    override suspend fun deleteEntry(entryId: String) {
        if (!config.isConfigured) throw BackendNotConfiguredException()
        supabase.from("listening_logs").delete { filter { eq("id", entryId) } }
    }

    override suspend fun stats(userId: String): ProfileStats =
        supabase.callRpc(config, "profile_stats") { put("p_user_id", userId) }
            .decodeList<ProfileStatsDto>().firstOrNull()?.toDomain()
            ?: ProfileStats(0, 0, null, 0, 0, 0)
}
