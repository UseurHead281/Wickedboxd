package com.wickedboxd.app.data.remote

import com.wickedboxd.app.core.config.BackendConfig
import com.wickedboxd.app.data.remote.dto.PopularSearchDto
import com.wickedboxd.app.data.remote.dto.ProfileCardDto
import com.wickedboxd.app.data.remote.dto.StoryCardDto
import com.wickedboxd.app.data.remote.dto.SuggestionDto
import com.wickedboxd.app.data.remote.dto.toDomain
import com.wickedboxd.app.domain.model.SearchScope
import com.wickedboxd.app.domain.model.SearchSuggestion
import com.wickedboxd.app.domain.model.StoryCard
import com.wickedboxd.app.domain.model.UserCard
import com.wickedboxd.app.domain.repository.SearchRepository
import io.github.jan.supabase.SupabaseClient
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.serialization.json.put

/** All matching happens in the database (ILIKE + trigram indexes, escaped input): see migrations 0003. */
@Singleton
class SupabaseSearchRepository @Inject constructor(
    private val supabase: SupabaseClient,
    private val config: BackendConfig,
) : SearchRepository {

    override suspend fun suggestions(query: String): List<SearchSuggestion> =
        supabase.callRpc(config, "search_suggestions") {
            put("p_query", query)
            put("p_limit", SUGGESTION_LIMIT)
        }.decodeList<SuggestionDto>().mapNotNull { it.toDomain() }

    override suspend fun searchStories(query: String, scope: SearchScope, limit: Int, offset: Int): List<StoryCard> =
        supabase.callRpc(config, "search_stories") {
            put("p_query", query)
            put("p_limit", limit)
            put("p_offset", offset)
            put("p_scope", scope.rpcName)
        }.decodeList<StoryCardDto>().map { it.toDomain() }

    override suspend fun searchUsers(query: String, limit: Int): List<UserCard> =
        supabase.callRpc(config, "search_users") {
            put("p_query", query)
            put("p_limit", limit)
        }.decodeList<ProfileCardDto>().map { it.toDomain() }

    override suspend fun popularSearches(): List<String> =
        supabase.callRpc(config, "popular_searches") { put("p_limit", POPULAR_LIMIT) }
            .decodeList<PopularSearchDto>().map { it.query }

    override suspend fun logSearch(query: String) {
        supabase.callRpc(config, "log_search") { put("p_query", query) }
    }

    private companion object {
        const val SUGGESTION_LIMIT = 8
        const val POPULAR_LIMIT = 8
    }
}
