package com.wickedboxd.app.data.remote.dto

import com.wickedboxd.app.domain.model.Genre
import com.wickedboxd.app.domain.model.RatingBucket
import com.wickedboxd.app.domain.model.StoryCard
import com.wickedboxd.app.domain.model.StoryDetails
import com.wickedboxd.app.domain.model.Tag
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Row of the `story_cards` view / result of `catalog_section` and `search_stories`. */
@Serializable
data class StoryCardDto(
    val id: String,
    val title: String,
    @SerialName("cover_path") val coverPath: String? = null,
    @SerialName("published_year") val publishedYear: Int? = null,
    @SerialName("author_name") val authorName: String? = null,
    @SerialName("narrator_name") val narratorName: String? = null,
    @SerialName("avg_rating") val avgRating: Double? = null,
    @SerialName("ratings_count") val ratingsCount: Int = 0,
    @SerialName("reviews_count") val reviewsCount: Int = 0,
    @SerialName("logs_count") val logsCount: Int = 0,
    @SerialName("is_favorite") val isFavorite: Boolean = false,
    @SerialName("my_rating") val myRating: Double? = null,
)

@Serializable
data class GenreDto(
    val id: Int,
    val slug: String,
    @SerialName("name_ru") val nameRu: String,
    @SerialName("name_en") val nameEn: String,
)

@Serializable
data class TagDto(val id: Int, val slug: String, val name: String)

/** Row of the `story_details` view (story_cards columns + description, genres, tags, flags). */
@Serializable
data class StoryDetailsDto(
    val id: String,
    val title: String,
    @SerialName("cover_path") val coverPath: String? = null,
    @SerialName("published_year") val publishedYear: Int? = null,
    @SerialName("author_name") val authorName: String? = null,
    @SerialName("narrator_name") val narratorName: String? = null,
    @SerialName("avg_rating") val avgRating: Double? = null,
    @SerialName("ratings_count") val ratingsCount: Int = 0,
    @SerialName("reviews_count") val reviewsCount: Int = 0,
    @SerialName("logs_count") val logsCount: Int = 0,
    @SerialName("is_favorite") val isFavorite: Boolean = false,
    @SerialName("my_rating") val myRating: Double? = null,
    val description: String? = null,
    @SerialName("external_url") val externalUrl: String? = null,
    val genres: List<GenreDto> = emptyList(),
    val tags: List<TagDto> = emptyList(),
    @SerialName("is_want_to_listen") val isWantToListen: Boolean = false,
    @SerialName("is_listened") val isListened: Boolean = false,
)

/** Row of `story_rating_distribution`. */
@Serializable
data class RatingBucketDto(val rating: Double, val votes: Int)

fun StoryCardDto.toDomain() = StoryCard(
    id = id, title = title, coverPath = coverPath, authorName = authorName, narratorName = narratorName,
    publishedYear = publishedYear, avgRating = avgRating, ratingsCount = ratingsCount,
    reviewsCount = reviewsCount, logsCount = logsCount, isFavorite = isFavorite, myRating = myRating,
)

fun StoryDetailsDto.toDomain() = StoryDetails(
    card = StoryCard(
        id = id, title = title, coverPath = coverPath, authorName = authorName, narratorName = narratorName,
        publishedYear = publishedYear, avgRating = avgRating, ratingsCount = ratingsCount,
        reviewsCount = reviewsCount, logsCount = logsCount, isFavorite = isFavorite, myRating = myRating,
    ),
    description = description,
    externalUrl = externalUrl,
    genres = genres.map { Genre(it.id, it.slug, it.nameRu, it.nameEn) },
    tags = tags.map { Tag(it.id, it.slug, it.name) },
    isWantToListen = isWantToListen,
    isListened = isListened,
)

fun RatingBucketDto.toDomain() = RatingBucket(rating = rating, votes = votes)
