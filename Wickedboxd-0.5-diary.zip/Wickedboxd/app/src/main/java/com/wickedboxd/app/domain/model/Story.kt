package com.wickedboxd.app.domain.model

/** What a cover card needs: no description, no tags - keep list payloads small. */
data class StoryCard(
    val id: String,
    val title: String,
    val coverPath: String?,
    val authorName: String?,
    val narratorName: String?,
    val publishedYear: Int?,
    val avgRating: Double?,
    val ratingsCount: Int,
    val reviewsCount: Int,
    val logsCount: Int,
    val isFavorite: Boolean,
    val myRating: Double?,
)

data class Genre(val id: Int, val slug: String, val nameRu: String, val nameEn: String)

data class Tag(val id: Int, val slug: String, val name: String)

data class StoryDetails(
    val card: StoryCard,
    val description: String?,
    val externalUrl: String?,
    val genres: List<Genre>,
    val tags: List<Tag>,
    val isWantToListen: Boolean,
    val isListened: Boolean,
)

/** [votes] users gave exactly [rating] stars (0.5 .. 5.0, step 0.5). */
data class RatingBucket(val rating: Double, val votes: Int)

/** Home-screen sections in display order. [rpcName] is the `p_section` argument of the SQL function `catalog_section`. */
enum class CatalogSection(val rpcName: String) {
    PopularThisWeek("popular_week"),
    HighestRated("highest_rated"),
    RecentlyAdded("recent"),
    Trending("trending"),
    NewDiscoveries("new_discoveries"),
    MostReviewed("most_reviewed"),
}
