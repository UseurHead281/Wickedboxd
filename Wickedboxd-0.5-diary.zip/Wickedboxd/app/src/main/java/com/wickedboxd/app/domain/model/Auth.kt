package com.wickedboxd.app.domain.model

sealed interface AuthState {
    /** The stored session is still being read / refreshed. */
    data object Loading : AuthState
    data object SignedOut : AuthState
    data class SignedIn(val userId: String, val email: String?) : AuthState
}

enum class SignUpOutcome {
    /** "Confirm email" is on: the account exists but cannot sign in until the link in the email is opened. */
    VerificationRequired,
    SignedIn,
}

/** Everything the UI can say about a failed auth call. One value = one message and one recovery action. */
enum class AuthError {
    InvalidCredentials,
    EmailNotConfirmed,
    EmailTaken,
    UsernameTaken,
    WeakPassword,
    RateLimited,
    Network,
    NotConfigured,
    Unknown,
}

class AuthException(val error: AuthError, cause: Throwable? = null) : Exception(error.name, cause)
