package com.wickedboxd.app.data.remote

import com.wickedboxd.app.core.config.BackendConfig
import com.wickedboxd.app.core.util.BackendNotConfiguredException
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.result.PostgrestResult
import kotlinx.serialization.json.JsonObjectBuilder
import kotlinx.serialization.json.buildJsonObject

/** Calls a SQL function, failing fast with a clear error when the project has no Supabase keys yet. */
internal suspend fun SupabaseClient.callRpc(
    config: BackendConfig,
    function: String,
    params: JsonObjectBuilder.() -> Unit = {},
): PostgrestResult {
    if (!config.isConfigured) throw BackendNotConfiguredException()
    return postgrest.rpc(function, buildJsonObject(params))
}
