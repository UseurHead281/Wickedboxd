package com.wickedboxd.app.feature.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wickedboxd.app.domain.model.AuthError
import com.wickedboxd.app.domain.repository.AuthRepository
import com.wickedboxd.app.domain.validation.AuthValidation
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ForgotPasswordUiState(
    val email: String = "",
    val emailInvalid: Boolean = false,
    val isLoading: Boolean = false,
    val sent: Boolean = false,
    val error: AuthError? = null,
)

@HiltViewModel
class ForgotPasswordViewModel @Inject constructor(
    private val auth: AuthRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(ForgotPasswordUiState())
    val state: StateFlow<ForgotPasswordUiState> = _state.asStateFlow()

    fun onEmailChange(value: String) = _state.update { it.copy(email = value, emailInvalid = false, error = null, sent = false) }

    fun submit() {
        val current = _state.value
        if (current.isLoading) return
        if (!AuthValidation.isValidEmail(current.email)) {
            _state.update { it.copy(emailInvalid = true) }
            return
        }
        _state.update { it.copy(isLoading = true, error = null) }
        viewModelScope.launch {
            val error = runAuth { auth.sendPasswordReset(current.email) }
            // The confirmation never says whether the address has an account (no user enumeration).
            _state.update { it.copy(isLoading = false, error = error, sent = error == null) }
        }
    }
}
