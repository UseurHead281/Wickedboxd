package com.wickedboxd.app.feature.user

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import com.wickedboxd.app.core.config.CoverUrlResolver
import com.wickedboxd.app.core.navigation.UserRoute
import com.wickedboxd.app.core.util.ErrorKind
import com.wickedboxd.app.core.util.toErrorKind
import com.wickedboxd.app.domain.model.UserCard
import com.wickedboxd.app.domain.repository.UserNotFoundException
import com.wickedboxd.app.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class UserProfileUiState(
    val isLoading: Boolean = true,
    val user: UserCard? = null,
    val notFound: Boolean = false,
    val error: ErrorKind? = null,
)

sealed interface UserProfileEvent {
    data object FollowFailed : UserProfileEvent
}

@HiltViewModel
class UserProfileViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val users: UserRepository,
    private val covers: CoverUrlResolver,
) : ViewModel() {

    private val userId: String = savedStateHandle.toRoute<UserRoute>().userId

    private val _state = MutableStateFlow(UserProfileUiState())
    val state: StateFlow<UserProfileUiState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<UserProfileEvent>(extraBufferCapacity = 1)
    val events: SharedFlow<UserProfileEvent> = _events.asSharedFlow()

    private val writeLock = Mutex()

    init {
        load()
    }

    fun avatarUrl(path: String?): String? = covers.avatar(path)

    fun load() {
        _state.update { it.copy(isLoading = it.user == null, error = null, notFound = false) }
        viewModelScope.launch {
            try {
                val user = users.profile(userId)
                _state.update { it.copy(isLoading = false, user = user) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: UserNotFoundException) {
                _state.update { it.copy(isLoading = false, notFound = true) }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.toErrorKind()) }
            }
        }
    }

    /** Optimistic: the button and the counter change at once; the server's numbers replace the guess afterwards. */
    fun toggleFollow() {
        viewModelScope.launch {
            writeLock.withLock {
                val before = _state.value.user ?: return@withLock
                if (before.isMe) return@withLock
                val target = !before.isFollowing
                _state.update {
                    it.copy(
                        user = before.copy(
                            isFollowing = target,
                            followersCount = (before.followersCount + if (target) 1 else -1).coerceAtLeast(0),
                        ),
                    )
                }
                try {
                    users.setFollowing(userId, target)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    _state.update { it.copy(user = before) }
                    _events.tryEmit(UserProfileEvent.FollowFailed)
                }
                resync()
            }
        }
    }

    private suspend fun resync() {
        try {
            val fresh = users.profile(userId)
            _state.update { it.copy(user = fresh) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // keep what is on screen
        }
    }
}
