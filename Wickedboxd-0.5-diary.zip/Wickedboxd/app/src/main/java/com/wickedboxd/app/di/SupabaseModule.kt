package com.wickedboxd.app.di

import com.wickedboxd.app.BuildConfig
import android.content.Context
import com.wickedboxd.app.core.config.BackendConfig
import com.wickedboxd.app.data.remote.auth.SecureSessionManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.serializer.KotlinXSerializer
import io.github.jan.supabase.storage.Storage
import javax.inject.Singleton
import kotlinx.serialization.json.Json

@Module
@InstallIn(SingletonComponent::class)
object SupabaseModule {

    @Provides
    @Singleton
    fun provideBackendConfig(): BackendConfig =
        BackendConfig(BuildConfig.SUPABASE_URL, BuildConfig.SUPABASE_ANON_KEY)

    /**
     * When local.properties has no Supabase keys yet the client is built against a placeholder host so the
     * app still starts; repositories check [BackendConfig.isConfigured] and show a clear "not configured" state.
     */
    @Provides
    @Singleton
    fun provideSupabaseClient(
        config: BackendConfig,
        @ApplicationContext context: Context,
    ): SupabaseClient = createSupabaseClient(
        supabaseUrl = if (config.isConfigured) config.supabaseUrl else "https://not-configured.invalid",
        supabaseKey = config.supabaseAnonKey.ifBlank { "not-configured" },
    ) {
        // views may gain columns later; never fail decoding because of an extra key
        defaultSerializer = KotlinXSerializer(Json { ignoreUnknownKeys = true })
        install(Auth) {
            scheme = "wickedboxd" // must match the VIEW intent-filter in AndroidManifest.xml
            host = "auth-callback"
            sessionManager = SecureSessionManager(context) // encrypted with an Android Keystore key
        }
        install(Postgrest)
        install(Storage)
    }
}
