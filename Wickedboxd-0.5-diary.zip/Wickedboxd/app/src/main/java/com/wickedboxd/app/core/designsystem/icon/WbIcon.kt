package com.wickedboxd.app.core.designsystem.icon

import androidx.annotation.DrawableRes
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.wickedboxd.app.R

/**
 * The supplied Wickedboxd icon pack, converted to VectorDrawables by tools/convert_assets.py.
 * Originals: design/ui-icons/svg. Icons are single-colour; tint them via [WbIcon].
 */
object WbIcons {
    val Catalog = R.drawable.ic_wb_catalog
    val Search = R.drawable.ic_wb_search
    val AddLog = R.drawable.ic_wb_add_log
    val AddLogAccentBackground = R.drawable.ic_wb_add_log_accent_bg
    val AddLogAccentForeground = R.drawable.ic_wb_add_log_accent_fg
    val Activity = R.drawable.ic_wb_activity
    val Profile = R.drawable.ic_wb_profile
    val Reviews = R.drawable.ic_wb_reviews
    val Lists = R.drawable.ic_wb_lists
    val Diary = R.drawable.ic_wb_diary
    val Star = R.drawable.ic_wb_star
    val Bookmark = R.drawable.ic_wb_bookmark
    val Headphones = R.drawable.ic_wb_headphones
    val UserFollow = R.drawable.ic_wb_user_follow
    val Settings = R.drawable.ic_wb_settings
    val Edit = R.drawable.ic_wb_edit
    val Back = R.drawable.ic_wb_back
    val ChevronRight = R.drawable.ic_wb_chevron_right
    val Close = R.drawable.ic_wb_close
    val Filter = R.drawable.ic_wb_filter
    val Calendar = R.drawable.ic_wb_calendar
    val Clock = R.drawable.ic_wb_clock
    val More = R.drawable.ic_wb_more
    val Warning = R.drawable.ic_wb_warning

    // filled twins of the supplied outline icons (same contour, fill added)
    val StarFilled = R.drawable.ic_wb_star_filled
    val BookmarkFilled = R.drawable.ic_wb_bookmark_filled

    // extras authored in the pack's style (design/extra-icons) - the supplied pack has no heart / check
    val Heart = R.drawable.ic_wb_x_heart
    val HeartFilled = R.drawable.ic_wb_x_heart_filled
    val Check = R.drawable.ic_wb_x_check

    /** Full-colour brand mark (not tintable) for Welcome / empty states. */
    val LogoMark = R.drawable.ic_wb_logo_mark
}

@Composable
fun WbIcon(
    @DrawableRes id: Int,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
    size: Dp = 24.dp,
) {
    Icon(
        painter = painterResource(id),
        contentDescription = contentDescription,
        modifier = modifier.size(size),
        tint = tint,
    )
}
