package com.wickedboxd.app.feature.auth

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.wickedboxd.app.core.designsystem.theme.WbTheme

/** Everything a signed-out user can see: Welcome -> Login / Registration -> Verify e-mail, Forgot password. */
@Composable
fun AuthFlow(modifier: Modifier = Modifier) {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = AuthWelcomeRoute,
        modifier = modifier.background(WbTheme.colors.background),
        enterTransition = { fadeIn(tween(200)) + slideInHorizontally(tween(240)) { it / 8 } },
        exitTransition = { fadeOut(tween(120)) },
        popEnterTransition = { fadeIn(tween(200)) },
        popExitTransition = { fadeOut(tween(160)) + slideOutHorizontally(tween(200)) { it / 8 } },
    ) {
        composable<AuthWelcomeRoute> {
            WelcomeScreen(
                onCreateAccount = { navController.navigate(AuthRegisterRoute) },
                onSignIn = { navController.navigate(AuthLoginRoute) },
            )
        }
        composable<AuthLoginRoute> {
            LoginScreen(
                onBack = { navController.popBackStack() },
                onForgotPassword = { navController.navigate(AuthForgotRoute) },
                onRegister = {
                    navController.navigate(AuthRegisterRoute) { popUpTo<AuthLoginRoute> { inclusive = true } }
                },
                onNeedsVerification = { email -> navController.navigate(AuthVerifyRoute(email)) },
            )
        }
        composable<AuthRegisterRoute> {
            RegisterScreen(
                onBack = { navController.popBackStack() },
                onSignIn = {
                    navController.navigate(AuthLoginRoute) { popUpTo<AuthRegisterRoute> { inclusive = true } }
                },
                onVerificationRequired = { email ->
                    navController.navigate(AuthVerifyRoute(email)) { popUpTo<AuthRegisterRoute> { inclusive = true } }
                },
            )
        }
        composable<AuthForgotRoute> {
            ForgotPasswordScreen(onBack = { navController.popBackStack() })
        }
        composable<AuthVerifyRoute> {
            VerifyEmailScreen(
                onBackToLogin = {
                    navController.navigate(AuthLoginRoute) { popUpTo(AuthWelcomeRoute) }
                },
            )
        }
    }
}
