package com.wickedboxd.app.feature.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.WbSecondaryButton
import com.wickedboxd.app.core.designsystem.theme.WbTheme
import com.wickedboxd.app.domain.model.AuthState

/**
 * Interim profile screen: the real one (stats, rating chart, diary calendar, settings) is built in a later stage.
 * Sign-out already works, which also makes the whole auth flow testable end to end.
 */
@Composable
fun ProfileScreen(viewModel: ProfileViewModel = hiltViewModel()) {
    val colors = WbTheme.colors
    val auth by viewModel.authState.collectAsStateWithLifecycle()
    val email = (auth as? AuthState.SignedIn)?.email

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .statusBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(text = stringResource(R.string.nav_profile), style = MaterialTheme.typography.headlineSmall, color = colors.textPrimary)
        if (email != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.profile_signed_in_as, email),
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                textAlign = TextAlign.Center,
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.shell_placeholder),
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        WbSecondaryButton(
            text = stringResource(R.string.profile_sign_out),
            onClick = viewModel::signOut,
            modifier = Modifier.widthIn(max = 320.dp),
        )
    }
}
