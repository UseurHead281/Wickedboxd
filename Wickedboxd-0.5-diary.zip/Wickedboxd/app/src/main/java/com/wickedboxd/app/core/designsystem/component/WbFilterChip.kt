package com.wickedboxd.app.core.designsystem.component

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.background
import com.wickedboxd.app.core.designsystem.theme.WbTheme

/** Single-choice pill (search categories). Selected: accent outline and a soft accent fill. */
@Composable
fun WbFilterChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = WbTheme.colors
    val fill by animateColorAsState(
        targetValue = if (selected) colors.accent.copy(alpha = 0.18f) else colors.surface,
        animationSpec = tween(160),
        label = "chipFill",
    )
    val border by animateColorAsState(
        targetValue = if (selected) colors.accent else colors.divider,
        animationSpec = tween(160),
        label = "chipBorder",
    )
    val shape = RoundedCornerShape(50)
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = if (selected) colors.textPrimary else colors.textSecondary,
        modifier = modifier
            .clip(shape)
            .background(fill)
            .border(BorderStroke(1.dp, border), shape)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}
