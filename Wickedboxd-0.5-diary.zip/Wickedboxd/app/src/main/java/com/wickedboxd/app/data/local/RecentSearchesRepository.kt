package com.wickedboxd.app.data.local

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.wickedboxd.app.domain.validation.SearchQuery
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

internal const val RECENT_SEARCHES_MAX = 10
private const val SEPARATOR = '\n'

internal fun decodeRecentSearches(raw: String?): List<String> =
    raw.orEmpty().split(SEPARATOR).map { it.trim() }.filter { it.isNotEmpty() }.take(RECENT_SEARCHES_MAX)

internal fun encodeRecentSearches(items: List<String>): String = items.take(RECENT_SEARCHES_MAX).joinToString(SEPARATOR.toString())

/** Most recent first, case-insensitive de-duplication, capped at [RECENT_SEARCHES_MAX]. Kept on this device only. */
internal fun List<String>.withRecentSearch(query: String): List<String> =
    (listOf(query) + filterNot { it.equals(query, ignoreCase = true) }).take(RECENT_SEARCHES_MAX)

@Singleton
class RecentSearchesRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>,
) {
    val recent: Flow<List<String>> = dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { decodeRecentSearches(it[KEY]) }

    suspend fun add(query: String) {
        val normalized = SearchQuery.normalize(query)
        if (normalized.length < SearchQuery.MIN_LENGTH) return
        dataStore.edit { prefs -> prefs[KEY] = encodeRecentSearches(decodeRecentSearches(prefs[KEY]).withRecentSearch(normalized)) }
    }

    suspend fun remove(query: String) {
        dataStore.edit { prefs ->
            prefs[KEY] = encodeRecentSearches(decodeRecentSearches(prefs[KEY]).filterNot { it.equals(query, ignoreCase = true) })
        }
    }

    suspend fun clear() {
        dataStore.edit { it.remove(KEY) }
    }

    private companion object {
        val KEY = stringPreferencesKey("recent_searches")
    }
}
