package com.wickedboxd.app.data.remote

import com.wickedboxd.app.core.config.BackendConfig
import com.wickedboxd.app.core.util.BackendNotConfiguredException
import com.wickedboxd.app.data.remote.dto.ProfileCardDto
import com.wickedboxd.app.data.remote.dto.toDomain
import com.wickedboxd.app.domain.model.UserCard
import com.wickedboxd.app.domain.repository.UserNotFoundException
import com.wickedboxd.app.domain.repository.UserRepository
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.serialization.json.put

@Singleton
class SupabaseUserRepository @Inject constructor(
    private val supabase: SupabaseClient,
    private val config: BackendConfig,
) : UserRepository {

    override suspend fun profile(userId: String): UserCard {
        if (!config.isConfigured) throw BackendNotConfiguredException()
        return supabase.from("profile_cards")
            .select { filter { eq("id", userId) } }
            .decodeList<ProfileCardDto>()
            .firstOrNull()
            ?.toDomain()
            ?: throw UserNotFoundException()
    }

    override suspend fun setFollowing(userId: String, follow: Boolean) {
        supabase.callRpc(config, "set_follow") {
            put("p_user_id", userId)
            put("p_follow", follow)
        }
    }
}
