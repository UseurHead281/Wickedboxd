package com.wickedboxd.app.domain.repository

import android.content.Intent
import com.wickedboxd.app.domain.model.AuthState
import com.wickedboxd.app.domain.model.SignUpOutcome
import kotlinx.coroutines.flow.StateFlow

/** All calls throw [com.wickedboxd.app.domain.model.AuthException] with a user-presentable error. */
interface AuthRepository {
    val state: StateFlow<AuthState>

    /** True after the user opened a password-reset link: the app must ask for a new password before anything else. */
    val passwordRecovery: StateFlow<Boolean>

    suspend fun signIn(email: String, password: String)
    suspend fun signUp(email: String, password: String, username: String): SignUpOutcome
    suspend fun isUsernameAvailable(username: String): Boolean
    suspend fun sendPasswordReset(email: String)
    suspend fun resendVerification(email: String)
    suspend fun updatePassword(newPassword: String)
    suspend fun signOut()

    /** Email-confirmation and password-reset links arrive as wickedboxd://auth-callback#... intents. */
    fun handleDeepLink(intent: Intent)
}
