package com.wickedboxd.app.feature.auth

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import com.wickedboxd.app.domain.model.AuthError
import com.wickedboxd.app.domain.repository.AuthRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class VerifyEmailUiState(
    val cooldownSeconds: Int = RESEND_COOLDOWN_SECONDS,
    val isSending: Boolean = false,
    val sentAgain: Boolean = false,
    val error: AuthError? = null,
)

private const val RESEND_COOLDOWN_SECONDS = 60 // matches Supabase's default per-address e-mail rate limit

@HiltViewModel
class VerifyEmailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val auth: AuthRepository,
) : ViewModel() {

    val email: String = savedStateHandle.toRoute<AuthVerifyRoute>().email

    private val _state = MutableStateFlow(VerifyEmailUiState())
    val state: StateFlow<VerifyEmailUiState> = _state.asStateFlow()

    private var cooldownJob: Job? = null

    init {
        startCooldown() // a message was sent a moment ago
    }

    fun resend() {
        val current = _state.value
        if (current.cooldownSeconds > 0 || current.isSending) return
        _state.update { it.copy(isSending = true, error = null, sentAgain = false) }
        viewModelScope.launch {
            val error = runAuth { auth.resendVerification(email) }
            _state.update { it.copy(isSending = false, error = error, sentAgain = error == null) }
            if (error == null) startCooldown()
        }
    }

    private fun startCooldown() {
        cooldownJob?.cancel()
        cooldownJob = viewModelScope.launch {
            for (second in RESEND_COOLDOWN_SECONDS downTo 1) {
                _state.update { it.copy(cooldownSeconds = second) }
                delay(1_000)
            }
            _state.update { it.copy(cooldownSeconds = 0) }
        }
    }
}
