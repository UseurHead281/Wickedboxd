package com.wickedboxd.app.core.designsystem.component

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.icon.WbIcon
import com.wickedboxd.app.core.designsystem.icon.WbIcons
import com.wickedboxd.app.core.designsystem.theme.CoverShape
import com.wickedboxd.app.core.designsystem.theme.WbTheme
import com.wickedboxd.app.core.util.formatRating

private val BadgeBackground = Color(0xCC0E0F12)

/**
 * A story cover, always 2:3 so the grid never jumps. The placeholder (brand mark + title) is drawn first and the
 * image fades in over it, so a missing, slow or failed cover still looks intentional.
 *
 * [rating] is the signed-in user's own rating (a small badge); [isFavorite] adds a heart. Nothing else is
 * printed on the cover - keep it quiet.
 */
@Composable
fun StoryCover(
    title: String,
    coverUrl: String?,
    modifier: Modifier = Modifier,
    rating: Double? = null,
    isFavorite: Boolean = false,
    onClick: (() -> Unit)? = null,
) {
    val colors = WbTheme.colors
    val clickable = if (onClick != null) Modifier.pressableScale(onClick) else Modifier
    Box(
        modifier = modifier
            .then(clickable)
            .aspectRatio(2f / 3f)
            .clip(CoverShape)
            .background(colors.surfaceElevated),
    ) {
        CoverPlaceholder(title)
        if (coverUrl != null) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current).data(coverUrl).crossfade(true).build(),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
        if (rating != null) {
            RatingBadge(rating, Modifier.align(Alignment.BottomStart).padding(6.dp))
        }
        if (isFavorite) {
            FavoriteBadge(Modifier.align(Alignment.TopEnd).padding(6.dp))
        }
    }
}

@Composable
private fun CoverPlaceholder(title: String) {
    val colors = WbTheme.colors
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(colors.surfaceElevated, colors.surface)))
            .padding(8.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            painter = painterResource(WbIcons.LogoMark),
            contentDescription = null,
            alpha = 0.3f,
            modifier = Modifier.size(28.dp),
        )
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
            maxLines = 4,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp),
        )
    }
}

@Composable
private fun RatingBadge(rating: Double, modifier: Modifier = Modifier) {
    val colors = WbTheme.colors
    val value = formatRating(rating)
    val description = stringResource(R.string.my_rating_badge_a11y, value)
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(BadgeBackground)
            .padding(horizontal = 5.dp, vertical = 2.dp)
            .semantics(mergeDescendants = true) { contentDescription = description },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        WbIcon(WbIcons.StarFilled, contentDescription = null, size = 10.dp, tint = colors.star)
        Text(text = value, style = MaterialTheme.typography.labelSmall, color = Color.White)
    }
}

@Composable
private fun FavoriteBadge(modifier: Modifier = Modifier) {
    val colors = WbTheme.colors
    Box(
        modifier = modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(BadgeBackground),
        contentAlignment = Alignment.Center,
    ) {
        WbIcon(
            WbIcons.HeartFilled,
            contentDescription = stringResource(R.string.favorite_badge_a11y),
            size = 13.dp,
            tint = colors.accent,
        )
    }
}
