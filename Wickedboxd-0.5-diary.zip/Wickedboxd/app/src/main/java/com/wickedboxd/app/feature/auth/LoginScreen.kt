package com.wickedboxd.app.feature.auth

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.AuthScaffold
import com.wickedboxd.app.core.designsystem.component.WbPrimaryButton
import com.wickedboxd.app.core.designsystem.component.WbTextLink
import com.wickedboxd.app.domain.model.AuthError

@Composable
fun LoginScreen(
    onBack: () -> Unit,
    onForgotPassword: () -> Unit,
    onRegister: () -> Unit,
    onNeedsVerification: (String) -> Unit,
    viewModel: LoginViewModel = hiltViewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current

    AuthScaffold(title = stringResource(R.string.login_title), onBack = onBack) {
        EmailField(
            value = state.email,
            onValueChange = viewModel::onEmailChange,
            invalid = state.emailInvalid,
            onDone = { focus.moveFocus(FocusDirection.Down) },
        )
        PasswordField(
            value = state.password,
            onValueChange = viewModel::onPasswordChange,
            label = stringResource(R.string.field_password),
            show = state.showPassword,
            onToggleShow = viewModel::toggleShowPassword,
            errorText = if (state.passwordMissing) stringResource(R.string.field_required) else null,
            imeAction = ImeAction.Done,
            onDone = {
                focus.clearFocus()
                viewModel.submit()
            },
        )
        state.error?.let { FormError(stringResource(it.messageRes())) }
        if (state.error == AuthError.EmailNotConfirmed) {
            WbTextLink(
                text = stringResource(R.string.login_resend_verification),
                onClick = { onNeedsVerification(state.email.trim()) },
            )
        }
        WbPrimaryButton(
            text = stringResource(R.string.login_submit),
            onClick = viewModel::submit,
            loading = state.isLoading,
        )
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            WbTextLink(text = stringResource(R.string.login_forgot), onClick = onForgotPassword)
            WbTextLink(text = stringResource(R.string.login_no_account), onClick = onRegister)
        }
    }
}
