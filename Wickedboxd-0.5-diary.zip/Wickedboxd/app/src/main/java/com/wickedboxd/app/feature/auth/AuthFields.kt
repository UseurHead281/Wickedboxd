package com.wickedboxd.app.feature.auth

import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.WbTextField
import com.wickedboxd.app.core.designsystem.theme.WbTheme

/** Password input with a text "Show / Hide" toggle (the icon pack has no eye icon). */
@Composable
internal fun PasswordField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    show: Boolean,
    onToggleShow: () -> Unit,
    modifier: Modifier = Modifier,
    errorText: String? = null,
    hintText: String? = null,
    imeAction: ImeAction = ImeAction.Done,
    onDone: () -> Unit = {},
) {
    val colors = WbTheme.colors
    WbTextField(
        value = value,
        onValueChange = onValueChange,
        label = label,
        modifier = modifier,
        errorText = errorText,
        hintText = hintText,
        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = imeAction),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        trailing = {
            TextButton(onClick = onToggleShow) {
                Text(
                    text = stringResource(if (show) R.string.password_hide else R.string.password_show),
                    color = colors.textSecondary,
                    style = MaterialTheme.typography.labelMedium,
                )
            }
        },
    )
}

@Composable
internal fun EmailField(
    value: String,
    onValueChange: (String) -> Unit,
    invalid: Boolean,
    modifier: Modifier = Modifier,
    imeAction: ImeAction = ImeAction.Next,
    onDone: () -> Unit = {},
) {
    WbTextField(
        value = value,
        onValueChange = onValueChange,
        label = stringResource(R.string.field_email),
        modifier = modifier,
        errorText = if (invalid) stringResource(R.string.field_email_invalid) else null,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = imeAction),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
    )
}

@Composable
internal fun FormError(text: String, modifier: Modifier = Modifier) {
    Text(text = text, style = MaterialTheme.typography.bodyMedium, color = WbTheme.colors.error, modifier = modifier)
}
