package com.wickedboxd.app.core.designsystem.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.wickedboxd.app.domain.model.AccentOption

/** Semantic colour tokens. Extends Material's scheme with what Wickedboxd needs (elevated surface, bars, stars). */
@Immutable
data class WbColors(
    val isDark: Boolean,
    val background: Color,
    val surface: Color,
    val surfaceElevated: Color,
    val topBar: Color,
    val divider: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    val onAccent: Color,
    val star: Color,
    val error: Color,
)

internal fun wbColors(dark: Boolean, accent: Color): WbColors {
    // Light accents (ice, teal, orange) need dark content on top for contrast.
    val onAccent = if (accent.luminance() > 0.45f) Color(0xFF101014) else Color.White
    return if (dark) {
        WbColors(
            isDark = true,
            background = WbPalette.DarkBackground,
            surface = WbPalette.DarkSurface,
            surfaceElevated = WbPalette.DarkSurfaceElevated,
            topBar = WbPalette.DarkTopBar,
            divider = WbPalette.DarkDivider,
            textPrimary = WbPalette.DarkTextPrimary,
            textSecondary = WbPalette.DarkTextSecondary,
            accent = accent,
            onAccent = onAccent,
            star = accent,
            error = WbPalette.DarkError,
        )
    } else {
        WbColors(
            isDark = false,
            background = WbPalette.LightBackground,
            surface = WbPalette.LightSurface,
            surfaceElevated = WbPalette.LightSurfaceElevated,
            topBar = WbPalette.LightTopBar,
            divider = WbPalette.LightDivider,
            textPrimary = WbPalette.LightTextPrimary,
            textSecondary = WbPalette.LightTextSecondary,
            accent = accent,
            onAccent = onAccent,
            star = accent,
            error = WbPalette.LightError,
        )
    }
}

val LocalWbColors = staticCompositionLocalOf { wbColors(dark = true, accent = AccentOption.Violet.toColor()) }
