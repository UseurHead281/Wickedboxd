package com.wickedboxd.app.feature.auth

import com.wickedboxd.app.domain.model.AuthError
import com.wickedboxd.app.domain.model.AuthException
import kotlin.coroutines.cancellation.CancellationException

/** Runs [block]. Returns null on success, the [AuthError] on failure. Coroutine cancellation is always rethrown. */
internal suspend fun runAuth(block: suspend () -> Unit): AuthError? = try {
    block()
    null
} catch (e: CancellationException) {
    throw e
} catch (e: AuthException) {
    e.error
} catch (e: Exception) {
    AuthError.Unknown
}
