package com.wickedboxd.app.data.remote

import com.wickedboxd.app.core.config.BackendConfig
import com.wickedboxd.app.core.util.BackendNotConfiguredException
import com.wickedboxd.app.data.remote.dto.RatingBucketDto
import com.wickedboxd.app.data.remote.dto.StoryCardDto
import com.wickedboxd.app.data.remote.dto.StoryDetailsDto
import com.wickedboxd.app.data.remote.dto.toDomain
import com.wickedboxd.app.domain.model.CatalogSection
import com.wickedboxd.app.domain.model.RatingBucket
import com.wickedboxd.app.domain.model.StoryCard
import com.wickedboxd.app.domain.model.StoryDetails
import com.wickedboxd.app.domain.repository.StoryNotFoundException
import com.wickedboxd.app.domain.repository.StoryRepository
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.result.PostgrestResult
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.serialization.json.JsonObjectBuilder
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Production implementation. Reads go through the `security_invoker` views and RPCs from
 * supabase/migrations/0003, so Row Level Security decides what the signed-in user may see;
 * writes use the idempotent RPCs (set_rating, set_favorite, ...), never raw table access.
 */
@Singleton
class SupabaseStoryRepository @Inject constructor(
    private val supabase: SupabaseClient,
    private val config: BackendConfig,
) : StoryRepository {

    override suspend fun section(section: CatalogSection, limit: Int, offset: Int): List<StoryCard> =
        rpc("catalog_section") {
            put("p_section", section.rpcName)
            put("p_limit", limit)
            put("p_offset", offset)
        }.decodeList<StoryCardDto>().map { it.toDomain() }

    override suspend fun details(storyId: String): StoryDetails {
        requireConfigured()
        return supabase.from("story_details")
            .select { filter { eq("id", storyId) } }
            .decodeList<StoryDetailsDto>()
            .firstOrNull()
            ?.toDomain()
            ?: throw StoryNotFoundException()
    }

    override suspend fun ratingDistribution(storyId: String): List<RatingBucket> =
        rpc("story_rating_distribution") { put("p_story_id", storyId) }
            .decodeList<RatingBucketDto>().map { it.toDomain() }

    override suspend fun setRating(storyId: String, rating: Double) {
        rpc("set_rating") {
            put("p_story_id", storyId)
            put("p_rating", rating)
        }
    }

    override suspend fun clearRating(storyId: String) {
        rpc("clear_rating") { put("p_story_id", storyId) }
    }

    override suspend fun setFavorite(storyId: String, favorite: Boolean) {
        rpc("set_favorite") {
            put("p_story_id", storyId)
            put("p_favorite", favorite)
        }
    }

    override suspend fun setWantToListen(storyId: String, want: Boolean) {
        rpc("set_want_to_listen") {
            put("p_story_id", storyId)
            put("p_want", want)
        }
    }

    private suspend fun rpc(function: String, params: JsonObjectBuilder.() -> Unit): PostgrestResult {
        requireConfigured()
        return supabase.postgrest.rpc(function, buildJsonObject(params))
    }

    private fun requireConfigured() {
        if (!config.isConfigured) throw BackendNotConfiguredException()
    }
}
