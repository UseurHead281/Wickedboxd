package com.wickedboxd.app.data.remote.dto

import com.wickedboxd.app.domain.model.SearchSuggestion
import com.wickedboxd.app.domain.model.SuggestionKind
import com.wickedboxd.app.domain.model.UserCard
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Row of the `profile_cards` view / result of `search_users`. */
@Serializable
data class ProfileCardDto(
    val id: String,
    val username: String,
    @SerialName("display_name") val displayName: String,
    val bio: String? = null,
    @SerialName("avatar_path") val avatarPath: String? = null,
    @SerialName("website_url") val websiteUrl: String? = null,
    @SerialName("followers_count") val followersCount: Int = 0,
    @SerialName("following_count") val followingCount: Int = 0,
    @SerialName("is_following") val isFollowing: Boolean = false,
    @SerialName("is_me") val isMe: Boolean = false,
)

@Serializable
data class SuggestionDto(val kind: String, val label: String, val ref: String)

@Serializable
data class PopularSearchDto(val query: String, val searches: Int = 0)

fun ProfileCardDto.toDomain() = UserCard(
    id = id, username = username, displayName = displayName, bio = bio, avatarPath = avatarPath,
    websiteUrl = websiteUrl, followersCount = followersCount, followingCount = followingCount,
    isFollowing = isFollowing, isMe = isMe,
)

/** Unknown kinds (a newer server) are dropped instead of crashing the screen. */
fun SuggestionDto.toDomain(): SearchSuggestion? {
    val k = when (kind) {
        "story" -> SuggestionKind.Story
        "author" -> SuggestionKind.Author
        "narrator" -> SuggestionKind.Narrator
        "genre" -> SuggestionKind.Genre
        "tag" -> SuggestionKind.Tag
        "user" -> SuggestionKind.User
        else -> return null
    }
    return SearchSuggestion(k, label, ref)
}
