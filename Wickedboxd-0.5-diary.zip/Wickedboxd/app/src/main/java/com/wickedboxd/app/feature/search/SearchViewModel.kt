package com.wickedboxd.app.feature.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wickedboxd.app.core.config.CoverUrlResolver
import com.wickedboxd.app.core.util.ErrorKind
import com.wickedboxd.app.core.util.toErrorKind
import com.wickedboxd.app.data.local.RecentSearchesRepository
import com.wickedboxd.app.domain.model.SearchScope
import com.wickedboxd.app.domain.model.SearchSuggestion
import com.wickedboxd.app.domain.model.StoryCard
import com.wickedboxd.app.domain.model.SuggestionKind
import com.wickedboxd.app.domain.model.UserCard
import com.wickedboxd.app.domain.repository.SearchRepository
import com.wickedboxd.app.domain.validation.SearchQuery
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class SearchTab { Stories, Users }

sealed interface SearchEvent {
    data class OpenStory(val id: String) : SearchEvent
    data class OpenUser(val id: String) : SearchEvent
}

data class SearchUiState(
    val query: String = "",
    /** Non-null = the results screen is showing this query; null = the user is still typing. */
    val submitted: String? = null,
    val tab: SearchTab = SearchTab.Stories,
    val scope: SearchScope = SearchScope.All,
    val suggestions: List<SearchSuggestion> = emptyList(),
    val recent: List<String> = emptyList(),
    val popular: List<String> = emptyList(),
    val stories: List<StoryCard> = emptyList(),
    val storiesLoading: Boolean = false,
    val storiesLoadingMore: Boolean = false,
    val storiesLoaded: Boolean = false,
    val storiesEnd: Boolean = false,
    val users: List<UserCard> = emptyList(),
    val usersLoading: Boolean = false,
    val usersLoaded: Boolean = false,
    val error: ErrorKind? = null,
)

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val search: SearchRepository,
    private val recentSearches: RecentSearchesRepository,
    private val covers: CoverUrlResolver,
) : ViewModel() {

    private val _state = MutableStateFlow(SearchUiState())
    val state: StateFlow<SearchUiState> = _state.asStateFlow()

    private val _events = Channel<SearchEvent>(Channel.BUFFERED)
    val events: Flow<SearchEvent> = _events.receiveAsFlow()

    private var suggestionsJob: Job? = null
    private var storiesJob: Job? = null
    private var usersJob: Job? = null

    init {
        viewModelScope.launch {
            recentSearches.recent.collect { list -> _state.update { it.copy(recent = list) } }
        }
        viewModelScope.launch {
            val popular = quietly { search.popularSearches() }.orEmpty()
            _state.update { it.copy(popular = popular) }
        }
    }

    fun coverUrl(path: String?): String? = covers.storyCover(path)

    fun avatarUrl(path: String?): String? = covers.avatar(path)

    /** Typing: back to suggestions mode, autocomplete after a short pause. */
    fun onQueryChange(text: String) {
        suggestionsJob?.cancel()
        val query = SearchQuery.normalize(text)
        _state.update {
            it.copy(
                query = text,
                submitted = null,
                suggestions = if (query.length < SearchQuery.MIN_LENGTH) emptyList() else it.suggestions,
                error = null,
            )
        }
        if (query.length >= SearchQuery.MIN_LENGTH) {
            suggestionsJob = viewModelScope.launch {
                delay(SUGGESTION_DEBOUNCE_MS) // one request when the user pauses, not one per key press
                val list = quietly { search.suggestions(query) }.orEmpty()
                _state.update { if (SearchQuery.normalize(it.query) == query) it.copy(suggestions = list) else it }
            }
        }
    }

    fun submit(rawQuery: String = _state.value.query, scope: SearchScope = SearchScope.All, tab: SearchTab = SearchTab.Stories) {
        val query = SearchQuery.normalize(rawQuery)
        if (query.length < SearchQuery.MIN_LENGTH) return
        suggestionsJob?.cancel()
        _state.update {
            it.copy(
                query = query, submitted = query, tab = tab, scope = scope, suggestions = emptyList(),
                stories = emptyList(), storiesLoaded = false, storiesEnd = false,
                users = emptyList(), usersLoaded = false, error = null,
            )
        }
        viewModelScope.launch {
            recentSearches.add(query)
            quietly { search.logSearch(query) }
        }
        loadActiveTab()
    }

    fun selectTab(tab: SearchTab) {
        _state.update { it.copy(tab = tab, error = null) }
        loadActiveTab()
    }

    fun selectScope(scope: SearchScope) {
        if (scope == _state.value.scope) return
        _state.update { it.copy(scope = scope, error = null) }
        loadStories(reset = true)
    }

    fun retry() {
        _state.update { it.copy(error = null) }
        loadActiveTab(force = true)
    }

    fun loadMoreStories() {
        val s = _state.value
        if (s.storiesLoading || s.storiesLoadingMore || s.storiesEnd || !s.storiesLoaded || s.error != null) return
        loadStories(reset = false)
    }

    fun onSuggestionClick(suggestion: SearchSuggestion) {
        when (suggestion.kind) {
            SuggestionKind.Story -> _events.trySend(SearchEvent.OpenStory(suggestion.ref))
            SuggestionKind.User -> _events.trySend(SearchEvent.OpenUser(suggestion.ref))
            SuggestionKind.Author -> submit(suggestion.label, SearchScope.Author)
            SuggestionKind.Narrator -> submit(suggestion.label, SearchScope.Narrator)
            SuggestionKind.Genre -> submit(suggestion.label, SearchScope.Genre)
            SuggestionKind.Tag -> submit(suggestion.label, SearchScope.Tag)
        }
    }

    fun removeRecent(query: String) {
        viewModelScope.launch { recentSearches.remove(query) }
    }

    fun clearRecent() {
        viewModelScope.launch { recentSearches.clear() }
    }

    private fun loadActiveTab(force: Boolean = false) {
        val s = _state.value
        if (s.submitted == null) return
        when (s.tab) {
            SearchTab.Stories -> if (force || !s.storiesLoaded) loadStories(reset = true)
            SearchTab.Users -> if (force || !s.usersLoaded) loadUsers()
        }
    }

    private fun loadStories(reset: Boolean) {
        val query = _state.value.submitted ?: return
        val scope = _state.value.scope
        storiesJob?.cancel()
        val offset = if (reset) 0 else _state.value.stories.size
        storiesJob = viewModelScope.launch {
            _state.update {
                it.copy(
                    storiesLoading = reset,
                    storiesLoadingMore = !reset,
                    stories = if (reset) emptyList() else it.stories,
                    storiesEnd = if (reset) false else it.storiesEnd,
                    storiesLoaded = if (reset) false else it.storiesLoaded,
                    error = null,
                )
            }
            try {
                val page = search.searchStories(query, scope, PAGE_SIZE, offset)
                _state.update { s ->
                    s.copy(
                        stories = (if (reset) page else s.stories + page).distinctBy { it.id },
                        storiesLoading = false,
                        storiesLoadingMore = false,
                        storiesLoaded = true,
                        storiesEnd = page.size < PAGE_SIZE,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(storiesLoading = false, storiesLoadingMore = false, error = e.toErrorKind()) }
            }
        }
    }

    private fun loadUsers() {
        val query = _state.value.submitted ?: return
        usersJob?.cancel()
        usersJob = viewModelScope.launch {
            _state.update { it.copy(usersLoading = true, error = null) }
            try {
                val users = search.searchUsers(query, PAGE_SIZE)
                _state.update { it.copy(users = users, usersLoading = false, usersLoaded = true) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(usersLoading = false, error = e.toErrorKind()) }
            }
        }
    }

    /** Optional extras (autocomplete, popular, logging) must never break search itself. */
    private suspend fun <T> quietly(block: suspend () -> T): T? = try {
        block()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

    private companion object {
        const val SUGGESTION_DEBOUNCE_MS = 300L
        const val PAGE_SIZE = 30
    }
}
