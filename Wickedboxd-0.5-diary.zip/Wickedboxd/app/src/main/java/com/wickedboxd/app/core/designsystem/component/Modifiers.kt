package com.wickedboxd.app.core.designsystem.component

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import com.wickedboxd.app.core.designsystem.theme.WbTheme

/** Clickable with a subtle press-down scale instead of a ripple: quiet, and cheap on long lists. */
@Composable
fun Modifier.pressableScale(
    onClick: () -> Unit,
    pressedScale: Float = 0.96f,
    onClickLabel: String? = null,
): Modifier {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) pressedScale else 1f, tween(90), label = "pressScale")
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = interactionSource,
            indication = null,
            onClickLabel = onClickLabel,
            onClick = onClick,
        )
}

/** Skeleton shimmer. The animation is read in the draw phase only, so it never recomposes anything. */
fun Modifier.shimmer(): Modifier = composed {
    val colors = WbTheme.colors
    val transition = rememberInfiniteTransition(label = "shimmer")
    val progress = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 1300, easing = LinearEasing)),
        label = "shimmerProgress",
    )
    drawBehind {
        val width = size.width
        val x = width * (progress.value * 3f - 1f)
        drawRect(
            Brush.horizontalGradient(
                colors = listOf(colors.surface, colors.surfaceElevated, colors.surface),
                startX = x - width * 0.6f,
                endX = x + width * 0.6f,
            ),
        )
    }
}
