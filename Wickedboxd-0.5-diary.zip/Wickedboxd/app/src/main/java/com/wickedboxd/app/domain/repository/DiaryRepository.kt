package com.wickedboxd.app.domain.repository

import com.wickedboxd.app.domain.model.DiaryEntry
import com.wickedboxd.app.domain.model.LogListenRequest
import com.wickedboxd.app.domain.model.ProfileStats
import java.time.LocalDate

interface DiaryRepository {
    /** Newest first. [from]/[to] are inclusive and optional (the calendar asks for one month). */
    suspend fun entries(userId: String, from: LocalDate? = null, to: LocalDate? = null, limit: Int, offset: Int = 0): List<DiaryEntry>

    /** Creates a diary entry (and upserts the user's rating / review). Returns the new entry id. */
    suspend fun logListen(request: LogListenRequest): String

    suspend fun deleteEntry(entryId: String)

    suspend fun stats(userId: String): ProfileStats
}
