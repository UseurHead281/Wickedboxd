package com.wickedboxd.app.domain.validation

object SearchQuery {
    /** Same minimum as the SQL functions (they return nothing for shorter input). */
    const val MIN_LENGTH = 2

    /** Trims and collapses whitespace; the result never contains a line break. */
    fun normalize(raw: String): String = raw.trim().replace(Regex("\\s+"), " ")
}
