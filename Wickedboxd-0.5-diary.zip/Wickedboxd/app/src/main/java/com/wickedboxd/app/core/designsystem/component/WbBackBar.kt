package com.wickedboxd.app.core.designsystem.component

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.icon.WbIcon
import com.wickedboxd.app.core.designsystem.icon.WbIcons
import com.wickedboxd.app.core.designsystem.theme.WbTheme

/** Top bar of drill-down screens: near-black, back arrow, optional title. Handles the status-bar inset itself. */
@Composable
fun WbBackBar(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    title: String? = null,
) {
    val colors = WbTheme.colors
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(colors.topBar)
            .statusBarsPadding()
            .height(48.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) {
            WbIcon(WbIcons.Back, contentDescription = stringResource(R.string.action_back), tint = colors.textPrimary)
        }
        if (title != null) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 16.dp),
            )
        }
    }
}
