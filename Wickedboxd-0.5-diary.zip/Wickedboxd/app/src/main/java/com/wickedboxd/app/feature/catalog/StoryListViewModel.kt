package com.wickedboxd.app.feature.catalog

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import com.wickedboxd.app.core.config.CoverUrlResolver
import com.wickedboxd.app.core.navigation.StoryListRoute
import com.wickedboxd.app.core.util.ErrorKind
import com.wickedboxd.app.core.util.toErrorKind
import com.wickedboxd.app.domain.model.CatalogSection
import com.wickedboxd.app.domain.model.StoryCard
import com.wickedboxd.app.domain.repository.StoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class StoryListUiState(
    val stories: List<StoryCard> = emptyList(),
    val isLoading: Boolean = true, // first page
    val isLoadingMore: Boolean = false,
    val endReached: Boolean = false,
    val error: ErrorKind? = null,
)

/** "See all" for one catalogue section: offset pagination, 30 stories per page. */
@HiltViewModel
class StoryListViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val stories: StoryRepository,
    private val covers: CoverUrlResolver,
) : ViewModel() {

    val section: CatalogSection = CatalogSection.valueOf(savedStateHandle.toRoute<StoryListRoute>().section)

    private val _state = MutableStateFlow(StoryListUiState())
    val state: StateFlow<StoryListUiState> = _state.asStateFlow()

    private var job: Job? = null

    init {
        loadMore()
    }

    fun coverUrl(path: String?): String? = covers.storyCover(path)

    fun retry() {
        _state.update { it.copy(error = null) }
        loadMore()
    }

    fun loadMore() {
        val current = _state.value
        if (job?.isActive == true || current.endReached || current.error != null) return
        job = viewModelScope.launch {
            _state.update { it.copy(isLoading = it.stories.isEmpty(), isLoadingMore = it.stories.isNotEmpty()) }
            try {
                val page = stories.section(section, PAGE_SIZE, current.stories.size)
                _state.update { s ->
                    s.copy(
                        // offset paging can repeat an item when the ranking shifts between requests
                        stories = (s.stories + page).distinctBy { it.id },
                        isLoading = false,
                        isLoadingMore = false,
                        endReached = page.size < PAGE_SIZE,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, isLoadingMore = false, error = e.toErrorKind()) }
            }
        }
    }

    private companion object {
        const val PAGE_SIZE = 30
    }
}
