package com.wickedboxd.app.core.config

/**
 * Supabase connection settings, read from local.properties at build time (see app/build.gradle.kts).
 * Only the public anon key lives in the app; all authorisation is enforced by Row Level Security.
 */
data class BackendConfig(
    val supabaseUrl: String,
    val supabaseAnonKey: String,
) {
    val isConfigured: Boolean
        get() = supabaseUrl.startsWith("https://") && supabaseAnonKey.isNotBlank()
}
