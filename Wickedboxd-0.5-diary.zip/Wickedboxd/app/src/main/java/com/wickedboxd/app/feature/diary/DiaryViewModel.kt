package com.wickedboxd.app.feature.diary

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wickedboxd.app.core.config.CoverUrlResolver
import com.wickedboxd.app.core.util.ErrorKind
import com.wickedboxd.app.core.util.toErrorKind
import com.wickedboxd.app.domain.model.AuthState
import com.wickedboxd.app.domain.model.DiaryEntry
import com.wickedboxd.app.domain.model.ProfileStats
import com.wickedboxd.app.domain.repository.AuthRepository
import com.wickedboxd.app.domain.repository.DiaryChangeBus
import com.wickedboxd.app.domain.repository.DiaryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import java.time.YearMonth
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class DiaryMode { List, Calendar }

data class DiaryUiState(
    val mode: DiaryMode = DiaryMode.List,
    val month: YearMonth = YearMonth.now(),
    val selectedDay: LocalDate? = null,
    val entries: List<DiaryEntry> = emptyList(),
    val isLoading: Boolean = true,
    val isLoadingMore: Boolean = false,
    val endReached: Boolean = false,
    val monthEntries: List<DiaryEntry> = emptyList(),
    val monthLoading: Boolean = false,
    val stats: ProfileStats? = null,
    val error: ErrorKind? = null,
    val pendingDelete: DiaryEntry? = null,
)

/** The signed-in user's diary: chronological list (paged) and a month calendar. */
@HiltViewModel
class DiaryViewModel @Inject constructor(
    private val diary: DiaryRepository,
    private val auth: AuthRepository,
    private val bus: DiaryChangeBus,
    private val covers: CoverUrlResolver,
) : ViewModel() {

    private val _state = MutableStateFlow(DiaryUiState())
    val state: StateFlow<DiaryUiState> = _state.asStateFlow()

    private var listJob: Job? = null
    private var monthJob: Job? = null

    private val userId: String? get() = (auth.state.value as? AuthState.SignedIn)?.userId

    init {
        reload()
        viewModelScope.launch { bus.changes.collect { reload() } }
    }

    fun coverUrl(path: String?): String? = covers.storyCover(path)

    fun reload() {
        loadFirstPage()
        loadStats()
        if (_state.value.mode == DiaryMode.Calendar) loadMonth()
    }

    fun setMode(mode: DiaryMode) {
        _state.update { it.copy(mode = mode) }
        if (mode == DiaryMode.Calendar) loadMonth()
    }

    fun changeMonth(delta: Int) {
        _state.update { it.copy(month = it.month.plusMonths(delta.toLong()), selectedDay = null, monthEntries = emptyList()) }
        loadMonth()
    }

    fun selectDay(day: LocalDate) = _state.update { it.copy(selectedDay = if (it.selectedDay == day) null else day) }

    fun loadMore() {
        val s = _state.value
        if (s.isLoading || s.isLoadingMore || s.endReached || s.error != null) return
        val uid = userId ?: return
        listJob = viewModelScope.launch {
            _state.update { it.copy(isLoadingMore = true) }
            try {
                val page = diary.entries(uid, null, null, PAGE_SIZE, s.entries.size)
                _state.update { it.copy(entries = (it.entries + page).distinctBy { e -> e.id }, isLoadingMore = false, endReached = page.size < PAGE_SIZE) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(isLoadingMore = false, error = e.toErrorKind()) }
            }
        }
    }

    fun retry() {
        _state.update { it.copy(error = null) }
        reload()
    }

    fun askDelete(entry: DiaryEntry) = _state.update { it.copy(pendingDelete = entry) }

    fun cancelDelete() = _state.update { it.copy(pendingDelete = null) }

    fun confirmDelete() {
        val entry = _state.value.pendingDelete ?: return
        _state.update { it.copy(pendingDelete = null) }
        viewModelScope.launch {
            try {
                diary.deleteEntry(entry.id)
                bus.notifyChanged() // reloads list, month and stats
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(error = e.toErrorKind()) }
            }
        }
    }

    private fun loadFirstPage() {
        val uid = userId ?: return
        listJob?.cancel()
        listJob = viewModelScope.launch {
            _state.update { it.copy(isLoading = it.entries.isEmpty(), error = null) }
            try {
                val page = diary.entries(uid, null, null, PAGE_SIZE, 0)
                _state.update { it.copy(entries = page, isLoading = false, endReached = page.size < PAGE_SIZE) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.toErrorKind()) }
            }
        }
    }

    private fun loadStats() {
        val uid = userId ?: return
        viewModelScope.launch {
            try {
                val stats = diary.stats(uid)
                _state.update { it.copy(stats = stats) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // the numbers are decoration; the diary itself still works
            }
        }
    }

    private fun loadMonth() {
        val uid = userId ?: return
        val month = _state.value.month
        monthJob?.cancel()
        monthJob = viewModelScope.launch {
            _state.update { it.copy(monthLoading = true) }
            try {
                val entries = diary.entries(uid, month.atDay(1), month.atEndOfMonth(), MONTH_LIMIT, 0)
                _state.update { if (it.month == month) it.copy(monthEntries = entries, monthLoading = false) else it }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(monthLoading = false, error = e.toErrorKind()) }
            }
        }
    }

    private companion object {
        const val PAGE_SIZE = 30
        const val MONTH_LIMIT = 200
    }
}
