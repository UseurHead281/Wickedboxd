package com.wickedboxd.app.domain.model

/** "Search by category" for stories. [rpcName] is the `p_scope` argument of the SQL function `search_stories`. */
enum class SearchScope(val rpcName: String) {
    All("all"),
    Title("title"),
    Author("author"),
    Narrator("narrator"),
    Genre("genre"),
    Tag("tag"),
}

enum class SuggestionKind { Story, Author, Narrator, Genre, Tag, User }

/**
 * One autocomplete line. [ref] is the story id for [SuggestionKind.Story], the user id for [SuggestionKind.User];
 * for the other kinds the [label] itself is what gets searched.
 */
data class SearchSuggestion(val kind: SuggestionKind, val label: String, val ref: String)
