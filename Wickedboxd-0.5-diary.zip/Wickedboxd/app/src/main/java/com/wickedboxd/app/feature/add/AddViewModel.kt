package com.wickedboxd.app.feature.add

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.toRoute
import com.wickedboxd.app.core.config.CoverUrlResolver
import com.wickedboxd.app.core.navigation.AddRoute
import com.wickedboxd.app.core.util.ErrorKind
import com.wickedboxd.app.core.util.toErrorKind
import com.wickedboxd.app.domain.model.LogListenRequest
import com.wickedboxd.app.domain.model.SearchScope
import com.wickedboxd.app.domain.model.StoryCard
import com.wickedboxd.app.domain.repository.DiaryChangeBus
import com.wickedboxd.app.domain.repository.DiaryRepository
import com.wickedboxd.app.domain.repository.SearchRepository
import com.wickedboxd.app.domain.repository.StoryRepository
import com.wickedboxd.app.domain.validation.SearchQuery
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Same limits as the CHECK constraints in supabase/migrations/0001 (listening_logs.note, reviews.body). */
const val NOTE_MAX_LENGTH = 1000
const val REVIEW_MAX_LENGTH = 5000

data class AddUiState(
    val story: StoryCard? = null,
    val storyLoading: Boolean = false,
    val query: String = "",
    val results: List<StoryCard> = emptyList(),
    val searching: Boolean = false,
    val searched: Boolean = false,
    val date: LocalDate = LocalDate.now(),
    val rating: Double? = null,
    val note: String = "",
    val review: String = "",
    val isRelisten: Boolean = false,
    val isSaving: Boolean = false,
    val storyMissing: Boolean = false,
    val error: ErrorKind? = null,
) {
    val noteTooLong: Boolean get() = note.length > NOTE_MAX_LENGTH
    val reviewTooLong: Boolean get() = review.length > REVIEW_MAX_LENGTH
    val canSave: Boolean get() = story != null && !noteTooLong && !reviewTooLong && !isSaving
}

@HiltViewModel
class AddViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val diary: DiaryRepository,
    private val stories: StoryRepository,
    private val search: SearchRepository,
    private val bus: DiaryChangeBus,
    private val covers: CoverUrlResolver,
) : ViewModel() {

    private val _state = MutableStateFlow(AddUiState())
    val state: StateFlow<AddUiState> = _state.asStateFlow()

    private val _saved = Channel<Unit>(Channel.BUFFERED)
    val saved: Flow<Unit> = _saved.receiveAsFlow()

    private var searchJob: Job? = null

    init {
        savedStateHandle.toRoute<AddRoute>().storyId?.let { preselect(it) }
    }

    fun coverUrl(path: String?): String? = covers.storyCover(path)

    fun onQueryChange(text: String) {
        searchJob?.cancel()
        val query = SearchQuery.normalize(text)
        _state.update { it.copy(query = text, results = emptyList(), searching = false, searched = false, storyMissing = false) }
        if (query.length < SearchQuery.MIN_LENGTH) return
        searchJob = viewModelScope.launch {
            delay(SEARCH_DEBOUNCE_MS)
            _state.update { it.copy(searching = true) }
            val found = try {
                search.searchStories(query, SearchScope.All, RESULT_LIMIT, 0)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
            _state.update { if (SearchQuery.normalize(it.query) == query) it.copy(results = found, searching = false, searched = true) else it }
        }
    }

    fun selectStory(card: StoryCard) {
        searchJob?.cancel()
        _state.update {
            it.copy(
                story = card, query = "", results = emptyList(), searching = false, searched = false,
                storyMissing = false, rating = it.rating ?: card.myRating,
            )
        }
        markRelistenIfAlreadyListened(card.id)
    }

    fun clearStory() = _state.update { it.copy(story = null, isRelisten = false) }

    fun onDateChange(date: LocalDate) = _state.update { it.copy(date = date) }

    fun onRatingChange(rating: Double?) = _state.update { it.copy(rating = rating) }

    fun onNoteChange(text: String) = _state.update { it.copy(note = text, error = null) }

    fun onReviewChange(text: String) = _state.update { it.copy(review = text, error = null) }

    fun onRelistenChange(value: Boolean) = _state.update { it.copy(isRelisten = value) }

    fun save() {
        val current = _state.value
        if (current.isSaving) return
        val story = current.story
        if (story == null) {
            _state.update { it.copy(storyMissing = true) }
            return
        }
        if (!current.canSave) return
        _state.update { it.copy(isSaving = true, error = null) }
        viewModelScope.launch {
            try {
                diary.logListen(
                    LogListenRequest(
                        storyId = story.id,
                        date = current.date,
                        rating = current.rating,
                        note = current.note.trim().ifEmpty { null },
                        review = current.review.trim().ifEmpty { null },
                        isRelisten = current.isRelisten,
                    ),
                )
                bus.notifyChanged()
                _state.update { it.copy(isSaving = false) }
                _saved.send(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(isSaving = false, error = e.toErrorKind()) }
            }
        }
    }

    private fun preselect(storyId: String) {
        _state.update { it.copy(storyLoading = true) }
        viewModelScope.launch {
            try {
                val details = stories.details(storyId)
                _state.update {
                    it.copy(
                        story = details.card, storyLoading = false, rating = details.card.myRating,
                        isRelisten = details.isListened,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(storyLoading = false) } // the user can still pick a story by hand
            }
        }
    }

    /** Listening to a story again is the common case; default the switch accordingly. */
    private fun markRelistenIfAlreadyListened(storyId: String) {
        viewModelScope.launch {
            try {
                val listened = stories.details(storyId).isListened
                _state.update { if (it.story?.id == storyId) it.copy(isRelisten = listened) else it }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // purely a convenience
            }
        }
    }

    private companion object {
        const val SEARCH_DEBOUNCE_MS = 300L
        const val RESULT_LIMIT = 10
    }
}
