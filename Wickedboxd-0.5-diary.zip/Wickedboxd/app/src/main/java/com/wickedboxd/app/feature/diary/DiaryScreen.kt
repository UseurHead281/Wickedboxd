package com.wickedboxd.app.feature.diary

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.EmptyState
import com.wickedboxd.app.core.designsystem.component.ErrorState
import com.wickedboxd.app.core.designsystem.component.RatingStars
import com.wickedboxd.app.core.designsystem.component.SkeletonBlock
import com.wickedboxd.app.core.designsystem.component.StoryCover
import com.wickedboxd.app.core.designsystem.component.WbFilterChip
import com.wickedboxd.app.core.designsystem.icon.WbIcon
import com.wickedboxd.app.core.designsystem.icon.WbIcons
import com.wickedboxd.app.core.designsystem.theme.WbTheme
import com.wickedboxd.app.domain.model.DiaryEntry
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.WeekFields
import java.util.Locale

private const val LOAD_MORE_THRESHOLD = 5

private sealed interface DiaryListItem {
    data class Header(val month: YearMonth) : DiaryListItem
    data class Entry(val entry: DiaryEntry) : DiaryListItem
}

/**
 * The user's diary: a chronological list grouped by month, or a month calendar where days with listens are marked
 * and a tapped day shows its entries. One entry per listen: listening to a story twice gives two rows.
 */
@Composable
fun DiaryContent(
    onStoryClick: (String) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: DiaryViewModel = hiltViewModel(),
) {
    val colors = WbTheme.colors
    val state by viewModel.state.collectAsStateWithLifecycle()
    val error = state.error

    Column(modifier.fillMaxSize().background(colors.background)) {
        DiaryHeader(state = state, onMode = viewModel::setMode)
        when {
            state.isLoading -> DiarySkeleton()
            error != null && state.entries.isEmpty() -> ErrorState(kind = error, onRetry = viewModel::retry)
            state.mode == DiaryMode.Calendar -> DiaryCalendar(
                state = state,
                coverUrl = viewModel::coverUrl,
                onPreviousMonth = { viewModel.changeMonth(-1) },
                onNextMonth = { viewModel.changeMonth(1) },
                onSelectDay = viewModel::selectDay,
                onStoryClick = onStoryClick,
                onAskDelete = viewModel::askDelete,
            )
            state.entries.isEmpty() -> EmptyState(
                title = stringResource(R.string.diary_empty_title),
                subtitle = stringResource(R.string.diary_empty_subtitle),
            )
            else -> DiaryList(
                state = state,
                coverUrl = viewModel::coverUrl,
                onLoadMore = viewModel::loadMore,
                onStoryClick = onStoryClick,
                onAskDelete = viewModel::askDelete,
            )
        }
    }

    state.pendingDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = viewModel::cancelDelete,
            title = { Text(text = stringResource(R.string.diary_delete_title)) },
            text = { Text(text = stringResource(R.string.diary_delete_message, entry.storyTitle)) },
            confirmButton = {
                TextButton(onClick = viewModel::confirmDelete) {
                    Text(text = stringResource(R.string.action_delete), color = colors.error)
                }
            },
            dismissButton = {
                TextButton(onClick = viewModel::cancelDelete) {
                    Text(text = stringResource(R.string.action_cancel), color = colors.textSecondary)
                }
            },
        )
    }
}

@Composable
private fun DiaryHeader(state: DiaryUiState, onMode: (DiaryMode) -> Unit) {
    val colors = WbTheme.colors
    Column(
        modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        state.stats?.let { stats ->
            // two different numbers on purpose: unique stories vs. total listens (repeat listens count in the second)
            Text(
                text = stringResource(R.string.diary_stats, stats.storiesListened, stats.totalListens),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WbFilterChip(
                text = stringResource(R.string.diary_mode_list),
                selected = state.mode == DiaryMode.List,
                onClick = { onMode(DiaryMode.List) },
            )
            WbFilterChip(
                text = stringResource(R.string.diary_mode_calendar),
                selected = state.mode == DiaryMode.Calendar,
                onClick = { onMode(DiaryMode.Calendar) },
            )
        }
    }
}

// ------------------------------------------------------------------ list mode
@Composable
private fun DiaryList(
    state: DiaryUiState,
    coverUrl: (String?) -> String?,
    onLoadMore: () -> Unit,
    onStoryClick: (String) -> Unit,
    onAskDelete: (DiaryEntry) -> Unit,
) {
    val colors = WbTheme.colors
    val rows = remember(state.entries) {
        buildList<DiaryListItem> {
            var current: YearMonth? = null
            state.entries.forEach { entry ->
                val month = YearMonth.from(entry.listenedOn)
                if (month != current) {
                    add(DiaryListItem.Header(month))
                    current = month
                }
                add(DiaryListItem.Entry(entry))
            }
        }
    }
    val listState = rememberLazyListState()
    val nearEnd by remember {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            last >= listState.layoutInfo.totalItemsCount - LOAD_MORE_THRESHOLD
        }
    }
    LaunchedEffect(nearEnd, rows.size) {
        if (nearEnd) onLoadMore()
    }
    LazyColumn(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        items(
            rows,
            key = { row ->
                when (row) {
                    is DiaryListItem.Header -> "month-${row.month}"
                    is DiaryListItem.Entry -> row.entry.id
                }
            },
        ) { row ->
            when (row) {
                is DiaryListItem.Header -> MonthTitle(row.month)
                is DiaryListItem.Entry -> DiaryRow(
                    entry = row.entry,
                    coverUrl = coverUrl(row.entry.storyCoverPath),
                    onClick = { onStoryClick(row.entry.storyId) },
                    onDelete = { onAskDelete(row.entry) },
                )
            }
        }
        if (state.isLoadingMore) {
            item(key = "loading-more") {
                Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(strokeWidth = 2.dp, color = colors.accent, modifier = Modifier.size(24.dp))
                }
            }
        }
    }
}

@Composable
private fun MonthTitle(month: YearMonth) {
    Text(
        text = monthLabel(month),
        style = MaterialTheme.typography.titleSmall,
        color = WbTheme.colors.textSecondary,
        modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 4.dp),
    )
}

@Composable
private fun DiaryRow(
    entry: DiaryEntry,
    coverUrl: String?,
    onClick: () -> Unit,
    onDelete: () -> Unit,
) {
    val colors = WbTheme.colors
    var menuOpen by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(role = Role.Button, onClick = onClick)
            .padding(start = 16.dp, end = 4.dp, top = 10.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.width(36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = entry.listenedOn.dayOfMonth.toString(),
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary,
            )
            Text(
                text = entry.listenedOn.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()),
                style = MaterialTheme.typography.labelSmall,
                color = colors.textSecondary,
                maxLines = 1,
            )
        }
        StoryCover(title = entry.storyTitle, coverUrl = coverUrl, modifier = Modifier.width(52.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                text = entry.storyTitle,
                style = MaterialTheme.typography.titleSmall,
                color = colors.textPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            entry.authorName?.let {
                Text(text = it, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (entry.rating != null || entry.isRelisten) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    entry.rating?.let { RatingStars(rating = it, starSize = 12.dp, spacing = 1.dp) }
                    if (entry.isRelisten) {
                        Text(
                            text = stringResource(R.string.diary_relisten),
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.accent,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(colors.accent.copy(alpha = 0.16f))
                                .padding(horizontal = 8.dp, vertical = 2.dp),
                        )
                    }
                }
            }
            entry.note?.let {
                Text(text = it, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        Box {
            IconButton(onClick = { menuOpen = true }) {
                WbIcon(
                    WbIcons.More,
                    contentDescription = stringResource(R.string.diary_entry_menu),
                    size = 20.dp,
                    tint = colors.textSecondary,
                )
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text(text = stringResource(R.string.action_delete), color = colors.error) },
                    onClick = {
                        menuOpen = false
                        onDelete()
                    },
                )
            }
        }
    }
}

// ------------------------------------------------------------------ calendar mode
@Composable
private fun DiaryCalendar(
    state: DiaryUiState,
    coverUrl: (String?) -> String?,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onSelectDay: (LocalDate) -> Unit,
    onStoryClick: (String) -> Unit,
    onAskDelete: (DiaryEntry) -> Unit,
) {
    val colors = WbTheme.colors
    val firstDayOfWeek = remember { WeekFields.of(Locale.getDefault()).firstDayOfWeek }
    val weeks = remember(state.month, firstDayOfWeek) { monthCells(state.month, firstDayOfWeek).chunked(7) }
    val perDay = remember(state.monthEntries) { state.monthEntries.groupBy { it.listenedOn } }
    val today = remember { LocalDate.now() }
    val selected = state.selectedDay
    val dayEntries = selected?.let { perDay[it] }.orEmpty()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item(key = "month-nav") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onPreviousMonth) {
                    WbIcon(
                        WbIcons.ChevronRight,
                        contentDescription = stringResource(R.string.diary_prev_month),
                        modifier = Modifier.rotate(180f),
                        tint = colors.textPrimary,
                    )
                }
                Text(
                    text = monthLabel(state.month),
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onNextMonth) {
                    WbIcon(
                        WbIcons.ChevronRight,
                        contentDescription = stringResource(R.string.diary_next_month),
                        tint = colors.textPrimary,
                    )
                }
            }
        }
        item(key = "weekdays") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                weekdayOrder(firstDayOfWeek).forEach { day ->
                    Text(
                        text = day.getDisplayName(TextStyle.SHORT, Locale.getDefault()),
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.textSecondary,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
        items(weeks.size, key = { "week-$it-${state.month}" }) { index ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                weeks[index].forEach { day ->
                    DayCell(
                        day = day,
                        hasEntries = day != null && perDay.containsKey(day),
                        selected = day != null && day == selected,
                        isToday = day == today,
                        onClick = { if (day != null) onSelectDay(day) },
                    )
                }
            }
        }
        item(key = "divider") { HorizontalDivider(color = colors.divider, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)) }
        when {
            selected == null -> item(key = "pick-day") {
                Text(
                    text = stringResource(R.string.diary_pick_day),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(16.dp),
                )
            }
            dayEntries.isEmpty() -> item(key = "day-empty") {
                Text(
                    text = stringResource(R.string.diary_day_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(16.dp),
                )
            }
            else -> items(dayEntries, key = { it.id }) { entry ->
                DiaryRow(
                    entry = entry,
                    coverUrl = coverUrl(entry.storyCoverPath),
                    onClick = { onStoryClick(entry.storyId) },
                    onDelete = { onAskDelete(entry) },
                )
            }
        }
    }
}

@Composable
private fun RowScope.DayCell(
    day: LocalDate?,
    hasEntries: Boolean,
    selected: Boolean,
    isToday: Boolean,
    onClick: () -> Unit,
) {
    val colors = WbTheme.colors
    Box(
        modifier = Modifier.weight(1f).aspectRatio(1f).padding(3.dp),
        contentAlignment = Alignment.Center,
    ) {
        if (day != null) {
            val fill by animateColorAsState(
                targetValue = when {
                    selected -> colors.accent
                    hasEntries -> colors.accent.copy(alpha = 0.22f)
                    else -> Color.Transparent
                },
                animationSpec = tween(150),
                label = "dayFill",
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(fill)
                    .then(if (isToday && !selected) Modifier.border(1.dp, colors.accent, CircleShape) else Modifier)
                    .clickable(role = Role.Button, onClick = onClick),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = day.dayOfMonth.toString(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = when {
                        selected -> colors.onAccent
                        hasEntries -> colors.textPrimary
                        else -> colors.textSecondary
                    },
                )
            }
        }
    }
}

@Composable
private fun DiarySkeleton() {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        repeat(4) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SkeletonBlock(Modifier.size(width = 36.dp, height = 40.dp))
                SkeletonBlock(Modifier.size(width = 52.dp, height = 78.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SkeletonBlock(Modifier.size(width = 180.dp, height = 16.dp))
                    SkeletonBlock(Modifier.size(width = 110.dp, height = 12.dp))
                }
            }
        }
    }
}

/** "ноябрь 2026" -> "Ноябрь 2026" (standalone month name in the user's language). */
private fun monthLabel(month: YearMonth): String =
    month.format(DateTimeFormatter.ofPattern("LLLL yyyy", Locale.getDefault()))
        .replaceFirstChar { it.titlecase(Locale.getDefault()) }
