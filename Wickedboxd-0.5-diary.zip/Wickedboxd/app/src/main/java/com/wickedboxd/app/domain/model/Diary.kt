package com.wickedboxd.app.domain.model

import java.time.LocalDate

/** One listen. Listening to the same story twice gives two entries. */
data class DiaryEntry(
    val id: String,
    val storyId: String,
    val storyTitle: String,
    val storyCoverPath: String?,
    val authorName: String?,
    val listenedOn: LocalDate,
    val rating: Double?,
    val note: String?,
    val isRelisten: Boolean,
    val hasReview: Boolean,
)

/** What the "log a listen" form sends. Rating and review are the user's current ones for the story (see log_listen). */
data class LogListenRequest(
    val storyId: String,
    val date: LocalDate,
    val rating: Double?,
    val note: String?,
    val review: String?,
    val isRelisten: Boolean,
)

/** Numbers of a profile. Unique stories and total listens are deliberately separate figures. */
data class ProfileStats(
    val storiesListened: Int,
    val totalListens: Int,
    val averageRating: Double?,
    val reviewsCount: Int,
    val listsCount: Int,
    val favoritesCount: Int,
)
