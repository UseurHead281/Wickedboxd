package com.wickedboxd.app.feature.catalog

import androidx.annotation.StringRes
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.CoverRowSkeleton
import com.wickedboxd.app.core.designsystem.component.EmptyState
import com.wickedboxd.app.core.designsystem.component.ErrorState
import com.wickedboxd.app.core.designsystem.component.SectionHeader
import com.wickedboxd.app.core.designsystem.component.ShellPlaceholder
import com.wickedboxd.app.core.designsystem.component.StoryCover
import com.wickedboxd.app.core.designsystem.component.WbDimens
import com.wickedboxd.app.core.designsystem.component.WbTabStrip
import com.wickedboxd.app.core.designsystem.theme.WbTheme
import com.wickedboxd.app.domain.model.CatalogSection
import com.wickedboxd.app.feature.diary.DiaryContent

private enum class CatalogTab(@StringRes val title: Int) {
    Stories(R.string.catalog_tab_stories),
    Reviews(R.string.catalog_tab_reviews),
    Lists(R.string.catalog_tab_lists),
    Diary(R.string.catalog_tab_diary),
}

/**
 * Home screen: brand title, four tabs, and on "Stories" six horizontal sections with three covers visible per row.
 * "Diary" is the signed-in user's diary; Reviews / Lists are built in later stages (placeholder for now).
 */
@Composable
fun CatalogScreen(
    onStoryClick: (String) -> Unit,
    onSeeAll: (CatalogSection) -> Unit,
    viewModel: CatalogViewModel = hiltViewModel(),
) {
    val colors = WbTheme.colors
    val state by viewModel.state.collectAsStateWithLifecycle()
    var selectedTab by rememberSaveable { mutableStateOf(CatalogTab.Stories) }
    val storiesListState = rememberLazyListState() // hoisted so the scroll position survives tab switches

    Column(Modifier.fillMaxSize().background(colors.background)) {
        CatalogHeader(selectedTab = selectedTab, onSelect = { selectedTab = it })
        Crossfade(
            targetState = selectedTab,
            modifier = Modifier.weight(1f),
            animationSpec = tween(180),
            label = "catalogTab",
        ) { tab ->
            when (tab) {
                CatalogTab.Stories -> StoriesTab(
                    state = state,
                    listState = storiesListState,
                    coverUrl = viewModel::coverUrl,
                    onRefresh = viewModel::refresh,
                    onStoryClick = onStoryClick,
                    onSeeAll = onSeeAll,
                )
                CatalogTab.Diary -> DiaryContent(onStoryClick = onStoryClick)
                else -> ShellPlaceholder(title = stringResource(tab.title), withStatusBarPadding = false)
            }
        }
    }
}

@Composable
private fun CatalogHeader(selectedTab: CatalogTab, onSelect: (CatalogTab) -> Unit) {
    val colors = WbTheme.colors
    val tabs = CatalogTab.entries
    val titles = tabs.map { stringResource(it.title) }
    Column(Modifier.fillMaxWidth().background(colors.topBar).statusBarsPadding()) {
        Box(Modifier.fillMaxWidth().height(48.dp), contentAlignment = Alignment.Center) {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.titleLarge,
                color = colors.textPrimary,
                maxLines = 1,
            )
        }
        WbTabStrip(titles = titles, selectedIndex = tabs.indexOf(selectedTab), onSelect = { onSelect(tabs[it]) })
        HorizontalDivider(color = colors.divider)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StoriesTab(
    state: CatalogUiState,
    listState: LazyListState,
    coverUrl: (String?) -> String?,
    onRefresh: () -> Unit,
    onStoryClick: (String) -> Unit,
    onSeeAll: (CatalogSection) -> Unit,
) {
    val sections = state.sections
    val anyLoading = sections.values.any { it is SectionState.Loading }
    val allFailed = sections.values.isNotEmpty() && sections.values.all { it is SectionState.Error }
    // a section with no stories (e.g. "Trending" on a new project) is simply not shown
    val visible = CatalogSection.entries.filter { section ->
        val s = sections[section]
        !(s is SectionState.Content && s.stories.isEmpty())
    }

    PullToRefreshBox(
        isRefreshing = state.isRefreshing,
        onRefresh = onRefresh,
        modifier = Modifier.fillMaxSize(),
    ) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            // exactly three covers per row; the row scrolls sideways for more
            val itemWidth: Dp = (maxWidth - WbDimens.ScreenPadding * 2 - WbDimens.CoverSpacing * 2) / 3
            when {
                allFailed -> {
                    val kind = (sections.values.first() as SectionState.Error).kind
                    Box(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        ErrorState(kind = kind, onRetry = onRefresh)
                    }
                }
                !anyLoading && visible.isEmpty() -> {
                    Box(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        EmptyState(
                            title = stringResource(R.string.catalog_empty_title),
                            subtitle = stringResource(R.string.catalog_empty_subtitle),
                        )
                    }
                }
                else -> LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(WbDimens.SectionSpacing),
                ) {
                    items(visible, key = { it.name }) { section ->
                        SectionBlock(
                            section = section,
                            sectionState = sections[section],
                            itemWidth = itemWidth,
                            coverUrl = coverUrl,
                            onStoryClick = onStoryClick,
                            onSeeAll = onSeeAll,
                            onRetry = onRefresh,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionBlock(
    section: CatalogSection,
    sectionState: SectionState?,
    itemWidth: Dp,
    coverUrl: (String?) -> String?,
    onStoryClick: (String) -> Unit,
    onSeeAll: (CatalogSection) -> Unit,
    onRetry: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionHeader(
            title = stringResource(section.titleRes()),
            onSeeAll = if (sectionState is SectionState.Content) ({ onSeeAll(section) }) else null,
        )
        when (sectionState) {
            null, SectionState.Loading -> CoverRowSkeleton(itemWidth = itemWidth)
            is SectionState.Error -> ErrorState(kind = sectionState.kind, onRetry = onRetry, compact = true)
            is SectionState.Content -> LazyRow(
                contentPadding = PaddingValues(horizontal = WbDimens.ScreenPadding),
                horizontalArrangement = Arrangement.spacedBy(WbDimens.CoverSpacing),
            ) {
                items(sectionState.stories, key = { it.id }) { story ->
                    StoryCover(
                        title = story.title,
                        coverUrl = coverUrl(story.coverPath),
                        modifier = Modifier.width(itemWidth),
                        rating = story.myRating,
                        isFavorite = story.isFavorite,
                        onClick = { onStoryClick(story.id) },
                    )
                }
            }
        }
    }
}
