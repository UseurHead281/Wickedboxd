package com.wickedboxd.app.domain.validation

enum class UsernameProblem { Empty, TooShort, TooLong, InvalidChars, Reserved }

enum class PasswordProblem { TooShort, TooLong }

/**
 * Client-side input rules. They give instant feedback only: the database enforces the same rules
 * (CHECK constraints in supabase/migrations/0001), because client input is never trusted.
 */
object AuthValidation {
    const val USERNAME_MIN = 3
    const val USERNAME_MAX = 20
    const val PASSWORD_MIN = 8
    const val PASSWORD_MAX = 72 // bcrypt ignores everything past 72 bytes

    private val USERNAME_CHARS = Regex("^[a-z0-9_]+$")
    private val EMAIL = Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]{2,}$")
    val RESERVED_USERNAMES = setOf("admin", "administrator", "moderator", "support", "wickedboxd", "root", "system")

    fun normalizeEmail(raw: String): String = raw.trim()

    fun isValidEmail(raw: String): Boolean {
        val email = normalizeEmail(raw)
        return email.length <= 254 && EMAIL.matches(email)
    }

    /** Lower-case, no whitespace: how a username is stored. */
    fun normalizeUsername(raw: String): String = raw.lowercase().filterNot { it.isWhitespace() }

    fun usernameProblem(raw: String): UsernameProblem? {
        val name = normalizeUsername(raw)
        return when {
            name.isEmpty() -> UsernameProblem.Empty
            name.length < USERNAME_MIN -> UsernameProblem.TooShort
            name.length > USERNAME_MAX -> UsernameProblem.TooLong
            !USERNAME_CHARS.matches(name) -> UsernameProblem.InvalidChars
            name in RESERVED_USERNAMES -> UsernameProblem.Reserved
            else -> null
        }
    }

    fun passwordProblem(password: String): PasswordProblem? = when {
        password.length < PASSWORD_MIN -> PasswordProblem.TooShort
        password.length > PASSWORD_MAX -> PasswordProblem.TooLong
        else -> null
    }
}
