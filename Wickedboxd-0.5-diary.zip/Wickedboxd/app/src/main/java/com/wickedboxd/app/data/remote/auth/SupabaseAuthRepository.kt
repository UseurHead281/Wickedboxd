package com.wickedboxd.app.data.remote.auth

import android.content.Intent
import com.wickedboxd.app.core.config.BackendConfig
import com.wickedboxd.app.core.util.BackendNotConfiguredException
import com.wickedboxd.app.di.ApplicationScope
import com.wickedboxd.app.domain.model.AuthException
import com.wickedboxd.app.domain.model.AuthState
import com.wickedboxd.app.domain.model.SignUpOutcome
import com.wickedboxd.app.domain.repository.AuthRepository
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.OtpType
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.handleDeeplinks
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.auth.status.SessionStatus
import io.github.jan.supabase.postgrest.postgrest
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.mapNotNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Supabase Auth. Passwords never touch our code beyond being handed to the SDK over TLS, and the session
 * is stored encrypted ([SecureSessionManager]). Transient session states (token refresh failing while
 * offline) are ignored on purpose: the last known state stays on screen instead of kicking the user out.
 */
@Singleton
class SupabaseAuthRepository @Inject constructor(
    private val supabase: SupabaseClient,
    private val config: BackendConfig,
    @ApplicationScope scope: CoroutineScope,
) : AuthRepository {

    override val state: StateFlow<AuthState> =
        if (!config.isConfigured) {
            MutableStateFlow<AuthState>(AuthState.SignedOut)
        } else {
            supabase.auth.sessionStatus
                .mapNotNull { it.toAuthStateOrNull() }
                .stateIn(scope, SharingStarted.Eagerly, AuthState.Loading)
        }

    private val _passwordRecovery = MutableStateFlow(false)
    override val passwordRecovery: StateFlow<Boolean> = _passwordRecovery.asStateFlow()

    override suspend fun signIn(email: String, password: String) {
        authCall {
            supabase.auth.signInWith(Email) {
                this.email = email.trim()
                this.password = password
            }
        }
    }

    override suspend fun signUp(email: String, password: String, username: String): SignUpOutcome = authCall {
        supabase.auth.signUpWith(Email) {
            this.email = email.trim()
            this.password = password
            // read by the database trigger handle_new_user() to create the profile
            data = buildJsonObject {
                put("username", username)
                put("display_name", username)
            }
        }
        // With "Confirm email" switched on there is no session until the link is opened.
        if (supabase.auth.currentSessionOrNull() != null) SignUpOutcome.SignedIn else SignUpOutcome.VerificationRequired
    }

    override suspend fun isUsernameAvailable(username: String): Boolean = authCall {
        supabase.postgrest
            .rpc("is_username_available", buildJsonObject { put("p_username", username) })
            .decodeAs<Boolean>()
    }

    override suspend fun sendPasswordReset(email: String) {
        authCall { supabase.auth.resetPasswordForEmail(email.trim()) }
    }

    override suspend fun resendVerification(email: String) {
        authCall { supabase.auth.resendEmail(OtpType.Email.SIGNUP, email.trim()) }
    }

    override suspend fun updatePassword(newPassword: String) {
        authCall { supabase.auth.updateUser { password = newPassword } }
        _passwordRecovery.value = false
    }

    override suspend fun signOut() {
        _passwordRecovery.value = false
        if (config.isConfigured) authCall { supabase.auth.signOut() }
    }

    override fun handleDeepLink(intent: Intent) {
        if (!config.isConfigured) return
        val uri = intent.data ?: return
        if (uri.scheme != "wickedboxd" || uri.host != "auth-callback") return
        val isRecovery = uri.fragment?.contains("type=recovery") == true || uri.query?.contains("type=recovery") == true
        supabase.handleDeeplinks(intent) { _ ->
            if (isRecovery) _passwordRecovery.value = true
        }
    }

    private suspend fun <T> authCall(block: suspend () -> T): T {
        if (!config.isConfigured) throw AuthException(com.wickedboxd.app.domain.model.AuthError.NotConfigured)
        try {
            return block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: AuthException) {
            throw e
        } catch (e: BackendNotConfiguredException) {
            throw AuthException(com.wickedboxd.app.domain.model.AuthError.NotConfigured, e)
        } catch (e: Exception) {
            throw AuthException(e.toAuthError(), e)
        }
    }

    private fun SessionStatus.toAuthStateOrNull(): AuthState? = when (this) {
        is SessionStatus.Authenticated -> AuthState.SignedIn(session.user?.id.orEmpty(), session.user?.email)
        is SessionStatus.NotAuthenticated -> AuthState.SignedOut
        else -> null
    }
}
