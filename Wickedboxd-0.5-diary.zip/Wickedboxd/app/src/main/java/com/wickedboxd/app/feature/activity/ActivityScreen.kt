package com.wickedboxd.app.feature.activity

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.ShellPlaceholder

@Composable
fun ActivityScreen() {
    ShellPlaceholder(title = stringResource(R.string.nav_activity))
}
