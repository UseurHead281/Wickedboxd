package com.wickedboxd.app.feature.story

import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.ErrorState
import com.wickedboxd.app.core.designsystem.component.RatingInput
import com.wickedboxd.app.core.designsystem.component.RatingStars
import com.wickedboxd.app.core.designsystem.component.SkeletonBlock
import com.wickedboxd.app.core.designsystem.component.StoryCover
import com.wickedboxd.app.core.designsystem.component.WbPrimaryButton
import com.wickedboxd.app.core.designsystem.component.WbBackBar
import com.wickedboxd.app.core.designsystem.icon.WbIcon
import com.wickedboxd.app.core.designsystem.icon.WbIcons
import com.wickedboxd.app.core.designsystem.theme.CoverShape
import com.wickedboxd.app.core.designsystem.theme.WbTheme
import com.wickedboxd.app.core.util.formatRating
import com.wickedboxd.app.core.util.quantityString
import com.wickedboxd.app.domain.model.RatingBucket
import com.wickedboxd.app.domain.model.StoryCard
import com.wickedboxd.app.domain.model.StoryDetails
import java.util.Locale

private const val COLLAPSED_DESCRIPTION_LINES = 6

@Composable
fun StoryDetailScreen(
    onBack: () -> Unit,
    onLogListen: (String) -> Unit,
    viewModel: StoryDetailViewModel = hiltViewModel(),
) {
    val colors = WbTheme.colors
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val failedText = stringResource(R.string.story_action_failed)
    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is StoryDetailEvent.ActionFailed -> snackbarHostState.showSnackbar(failedText)
            }
        }
    }

    Box(Modifier.fillMaxSize().background(colors.background)) {
        Column(Modifier.fillMaxSize()) {
            WbBackBar(onBack = onBack)
            val details = state.details
            val error = state.error
            when {
                details != null -> StoryContent(
                    details = details,
                    distribution = state.distribution,
                    coverUrl = viewModel::coverUrl,
                    onLogListen = { onLogListen(details.card.id) },
                    onRate = viewModel::setRating,
                    onClearRating = viewModel::clearRating,
                    onToggleFavorite = viewModel::toggleFavorite,
                    onToggleWant = viewModel::toggleWantToListen,
                )
                state.isLoading -> DetailSkeleton()
                error != null -> ErrorState(kind = error, onRetry = viewModel::load)
            }
        }
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
        )
    }
}

@Composable
private fun StoryContent(
    details: StoryDetails,
    distribution: List<RatingBucket>,
    coverUrl: (String?) -> String?,
    onLogListen: () -> Unit,
    onRate: (Double) -> Unit,
    onClearRating: () -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleWant: () -> Unit,
) {
    val card = details.card
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp),
    ) {
        Header(card = card, coverUrl = coverUrl(card.coverPath))
        WbPrimaryButton(
            text = stringResource(R.string.story_log_listen),
            onClick = onLogListen,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        RatingSummary(card = card, distribution = distribution)
        YourRating(myRating = card.myRating, onRate = onRate, onClear = onClearRating)
        Actions(details = details, onToggleFavorite = onToggleFavorite, onToggleWant = onToggleWant)
        if (details.genres.isNotEmpty() || details.tags.isNotEmpty()) {
            Taxonomy(details)
        }
        details.description?.takeIf { it.isNotBlank() }?.let { Description(it) }
    }
}

@Composable
private fun Header(card: StoryCard, coverUrl: String?) {
    val colors = WbTheme.colors
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        StoryCover(
            title = card.title,
            coverUrl = coverUrl,
            modifier = Modifier.width(120.dp),
            rating = card.myRating,
            isFavorite = card.isFavorite,
        )
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(text = card.title, style = MaterialTheme.typography.headlineSmall, color = colors.textPrimary)
            Text(
                text = card.authorName?.let { stringResource(R.string.story_author, it) }
                    ?: stringResource(R.string.story_unknown_author),
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
            )
            card.narratorName?.let {
                Text(text = stringResource(R.string.story_narrator, it), style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary)
            }
            card.publishedYear?.let {
                Text(text = stringResource(R.string.story_year, it), style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary)
            }
        }
    }
}

@Composable
private fun RatingSummary(card: StoryCard, distribution: List<RatingBucket>) {
    val colors = WbTheme.colors
    val average = card.avgRating
    val reviews = quantityString(R.plurals.reviews_count, card.reviewsCount, card.reviewsCount)
    val diaries = quantityString(R.plurals.diary_count, card.logsCount, card.logsCount)
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = stringResource(R.string.story_rating_distribution),
            style = MaterialTheme.typography.titleSmall,
            color = colors.textSecondary,
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(MaterialTheme.shapes.large)
                .background(colors.surface)
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(
                modifier = Modifier.width(88.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = if (average != null) formatRating(average) else "—",
                    style = MaterialTheme.typography.headlineLarge,
                    color = colors.textPrimary,
                )
                if (average != null) RatingStars(rating = average, starSize = 12.dp, spacing = 1.dp)
                Text(
                    text = if (card.ratingsCount > 0) {
                        quantityString(R.plurals.ratings_count, card.ratingsCount, card.ratingsCount)
                    } else {
                        stringResource(R.string.story_no_ratings)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                    textAlign = TextAlign.Center,
                )
            }
            RatingDistributionChart(buckets = distribution, myRating = card.myRating, modifier = Modifier.weight(1f))
        }
        Text(text = "$reviews · $diaries", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
    }
}

@Composable
private fun YourRating(myRating: Double?, onRate: (Double) -> Unit, onClear: () -> Unit) {
    val colors = WbTheme.colors
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            text = stringResource(R.string.story_your_rating),
            style = MaterialTheme.typography.titleSmall,
            color = colors.textSecondary,
        )
        RatingInput(value = myRating, onValueChange = onRate)
        if (myRating != null) {
            Text(text = formatRating(myRating), style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
            TextButton(onClick = onClear) {
                Text(text = stringResource(R.string.story_clear_rating), color = colors.textSecondary)
            }
        } else {
            Text(
                text = stringResource(R.string.story_rate_hint),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun Actions(details: StoryDetails, onToggleFavorite: () -> Unit, onToggleWant: () -> Unit) {
    val uriHandler = LocalUriHandler.current
    val favorite = details.card.isFavorite
    val want = details.isWantToListen
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        StoryAction(
            icon = if (favorite) WbIcons.HeartFilled else WbIcons.Heart,
            label = stringResource(if (favorite) R.string.story_favorite_remove else R.string.story_favorite_add),
            active = favorite,
            onClick = onToggleFavorite,
            modifier = Modifier.weight(1f),
        )
        StoryAction(
            icon = if (want) WbIcons.BookmarkFilled else WbIcons.Bookmark,
            label = stringResource(if (want) R.string.story_want_remove else R.string.story_want_add),
            active = want,
            onClick = onToggleWant,
            modifier = Modifier.weight(1f),
        )
        details.externalUrl?.let { url ->
            StoryAction(
                icon = WbIcons.Headphones,
                label = stringResource(R.string.story_open_source),
                active = false,
                toggle = false,
                // there is no player in Wickedboxd: stories are listened to on their original platform
                onClick = { runCatching { uriHandler.openUri(url) } },
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun StoryAction(
    @DrawableRes icon: Int,
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    toggle: Boolean = true,
) {
    val colors = WbTheme.colors
    val tint by animateColorAsState(
        targetValue = if (active) colors.accent else colors.textPrimary,
        animationSpec = tween(160),
        label = "storyActionTint",
    )
    val interaction = if (toggle) {
        Modifier.toggleable(value = active, role = Role.Switch, onValueChange = { onClick() })
    } else {
        Modifier.clickable(role = Role.Button, onClick = onClick)
    }
    Column(
        modifier = modifier
            .clip(MaterialTheme.shapes.medium)
            .background(colors.surface)
            .then(interaction)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        WbIcon(icon, contentDescription = null, tint = tint)
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = colors.textPrimary,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun Taxonomy(details: StoryDetails) {
    val russian = Locale.getDefault().language == "ru"
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (details.genres.isNotEmpty()) {
            ChipGroup(
                title = stringResource(R.string.story_genres),
                items = details.genres.map { if (russian) it.nameRu else it.nameEn },
            )
        }
        if (details.tags.isNotEmpty()) {
            ChipGroup(title = stringResource(R.string.story_tags), items = details.tags.map { it.name })
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ChipGroup(title: String, items: List<String>) {
    val colors = WbTheme.colors
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(text = title, style = MaterialTheme.typography.titleSmall, color = colors.textSecondary)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items.forEach { text ->
                Text(
                    text = text,
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.textPrimary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(colors.surfaceElevated)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                )
            }
        }
    }
}

@Composable
private fun Description(text: String) {
    val colors = WbTheme.colors
    var expanded by rememberSaveable { mutableStateOf(false) }
    var overflows by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(
            text = stringResource(R.string.story_description),
            style = MaterialTheme.typography.titleSmall,
            color = colors.textSecondary,
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textPrimary,
            maxLines = if (expanded) Int.MAX_VALUE else COLLAPSED_DESCRIPTION_LINES,
            overflow = TextOverflow.Ellipsis,
            onTextLayout = { result -> if (!expanded) overflows = result.hasVisualOverflow },
            modifier = Modifier.animateContentSize(),
        )
        if (overflows || expanded) {
            TextButton(onClick = { expanded = !expanded }) {
                Text(
                    text = stringResource(if (expanded) R.string.story_collapse else R.string.story_read_more),
                    color = colors.accent,
                )
            }
        }
    }
}

@Composable
private fun DetailSkeleton() {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            SkeletonBlock(Modifier.width(120.dp).aspectRatio(2f / 3f), CoverShape)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SkeletonBlock(Modifier.fillMaxWidth().height(26.dp))
                SkeletonBlock(Modifier.fillMaxWidth(0.7f).height(26.dp))
                SkeletonBlock(Modifier.fillMaxWidth(0.5f).height(16.dp))
                SkeletonBlock(Modifier.fillMaxWidth(0.4f).height(16.dp))
            }
        }
        SkeletonBlock(Modifier.fillMaxWidth().height(130.dp), MaterialTheme.shapes.large)
        SkeletonBlock(Modifier.fillMaxWidth().height(72.dp), MaterialTheme.shapes.large)
    }
}
