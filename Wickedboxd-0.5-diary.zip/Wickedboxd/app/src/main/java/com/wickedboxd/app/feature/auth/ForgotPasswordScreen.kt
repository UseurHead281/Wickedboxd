package com.wickedboxd.app.feature.auth

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.AuthScaffold
import com.wickedboxd.app.core.designsystem.component.WbPrimaryButton
import com.wickedboxd.app.core.designsystem.component.WbTextLink
import com.wickedboxd.app.core.designsystem.theme.WbTheme

@Composable
fun ForgotPasswordScreen(
    onBack: () -> Unit,
    viewModel: ForgotPasswordViewModel = hiltViewModel(),
) {
    val colors = WbTheme.colors
    val state by viewModel.state.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current

    AuthScaffold(title = stringResource(R.string.forgot_title), onBack = onBack) {
        Text(
            text = stringResource(R.string.forgot_description),
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary,
        )
        EmailField(
            value = state.email,
            onValueChange = viewModel::onEmailChange,
            invalid = state.emailInvalid,
            imeAction = ImeAction.Done,
            onDone = {
                focus.clearFocus()
                viewModel.submit()
            },
        )
        state.error?.let { FormError(stringResource(it.messageRes())) }
        if (state.sent) {
            Text(
                text = stringResource(R.string.forgot_sent),
                style = MaterialTheme.typography.bodyMedium,
                color = colors.accent,
            )
        }
        WbPrimaryButton(
            text = stringResource(R.string.forgot_submit),
            onClick = viewModel::submit,
            loading = state.isLoading,
        )
        WbTextLink(text = stringResource(R.string.back_to_login), onClick = onBack)
    }
}
