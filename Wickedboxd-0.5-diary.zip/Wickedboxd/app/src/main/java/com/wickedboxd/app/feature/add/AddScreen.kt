package com.wickedboxd.app.feature.add

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wickedboxd.app.R
import com.wickedboxd.app.core.designsystem.component.RatingInput
import com.wickedboxd.app.core.designsystem.component.SkeletonBlock
import com.wickedboxd.app.core.designsystem.component.StoryCover
import com.wickedboxd.app.core.designsystem.component.WbPrimaryButton
import com.wickedboxd.app.core.designsystem.component.WbSearchField
import com.wickedboxd.app.core.designsystem.component.WbSecondaryButton
import com.wickedboxd.app.core.designsystem.component.WbTextField
import com.wickedboxd.app.core.designsystem.component.messageRes
import com.wickedboxd.app.core.designsystem.icon.WbIcon
import com.wickedboxd.app.core.designsystem.icon.WbIcons
import com.wickedboxd.app.core.designsystem.theme.WbTheme
import com.wickedboxd.app.domain.model.StoryCard
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

private const val ONE_DAY_MS = 24L * 60 * 60 * 1000

/** Listens cannot be dated in the future (the database allows today + 1 day for time-zone differences). */
@OptIn(ExperimentalMaterial3Api::class)
private object NotInTheFuture : SelectableDates {
    override fun isSelectableDate(utcTimeMillis: Long): Boolean = utcTimeMillis <= System.currentTimeMillis() + ONE_DAY_MS
    override fun isSelectableYear(year: Int): Boolean = year <= LocalDate.now().year
}

/**
 * The centre "+" button: pick a story from the catalogue, set the date, rate, add a note and/or a review,
 * mark a repeat listen. Users cannot create stories here; missing ones are suggested through the submission form.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddScreen(
    onClose: () -> Unit,
    viewModel: AddViewModel = hiltViewModel(),
) {
    val colors = WbTheme.colors
    val state by viewModel.state.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current
    var showDatePicker by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.saved.collect { onClose() }
    }

    Column(Modifier.fillMaxSize().background(colors.background).imePadding()) {
        AddTopBar(onClose)
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp),
        ) {
            StorySection(
                state = state,
                coverUrl = viewModel::coverUrl,
                onQueryChange = viewModel::onQueryChange,
                onSelect = viewModel::selectStory,
                onClear = viewModel::clearStory,
                onSearchAction = { focus.clearFocus() },
            )
            Section(R.string.add_date) {
                WbSecondaryButton(
                    text = state.date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG).withLocale(Locale.getDefault())),
                    onClick = { showDatePicker = true },
                )
            }
            Section(R.string.add_rating) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    RatingInput(value = state.rating, onValueChange = { viewModel.onRatingChange(it) }, starSize = 36.dp)
                    if (state.rating != null) {
                        TextButton(onClick = { viewModel.onRatingChange(null) }) {
                            Text(text = stringResource(R.string.story_clear_rating), color = colors.textSecondary)
                        }
                    }
                }
            }
            RelistenRow(checked = state.isRelisten, onCheckedChange = viewModel::onRelistenChange)
            WbTextField(
                value = state.note,
                onValueChange = viewModel::onNoteChange,
                label = stringResource(R.string.add_note),
                singleLine = false,
                minLines = 2,
                errorText = if (state.noteTooLong) counter(state.note.length, NOTE_MAX_LENGTH) else null,
                hintText = counter(state.note.length, NOTE_MAX_LENGTH),
            )
            WbTextField(
                value = state.review,
                onValueChange = viewModel::onReviewChange,
                label = stringResource(R.string.add_review),
                singleLine = false,
                minLines = 4,
                errorText = if (state.reviewTooLong) counter(state.review.length, REVIEW_MAX_LENGTH) else null,
                hintText = counter(state.review.length, REVIEW_MAX_LENGTH),
            )
            state.error?.let {
                Text(text = stringResource(it.messageRes()), style = MaterialTheme.typography.bodyMedium, color = colors.error)
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .background(colors.topBar)
                .navigationBarsPadding()
                .padding(16.dp),
        ) {
            WbPrimaryButton(
                text = stringResource(R.string.add_save),
                onClick = viewModel::save,
                enabled = !state.noteTooLong && !state.reviewTooLong,
                loading = state.isSaving,
            )
        }
    }

    if (showDatePicker) {
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = state.date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
            selectableDates = NotInTheFuture,
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        pickerState.selectedDateMillis?.let { ms ->
                            viewModel.onDateChange(Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate())
                        }
                        showDatePicker = false
                    },
                ) { Text(text = stringResource(R.string.action_done), color = colors.accent) }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text(text = stringResource(R.string.action_cancel), color = colors.textSecondary)
                }
            },
        ) {
            DatePicker(state = pickerState)
        }
    }
}

@Composable
private fun counter(length: Int, max: Int): String = stringResource(R.string.add_counter, length, max)

@Composable
private fun AddTopBar(onClose: () -> Unit) {
    val colors = WbTheme.colors
    Column(Modifier.fillMaxWidth().background(colors.topBar).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                WbIcon(WbIcons.Close, contentDescription = stringResource(R.string.action_close), tint = colors.textPrimary)
            }
            Text(
                text = stringResource(R.string.add_title),
                style = MaterialTheme.typography.titleMedium,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        HorizontalDivider(color = colors.divider)
    }
}

@Composable
private fun Section(titleRes: Int, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = stringResource(titleRes),
            style = MaterialTheme.typography.titleSmall,
            color = WbTheme.colors.textSecondary,
        )
        content()
    }
}

@Composable
private fun StorySection(
    state: AddUiState,
    coverUrl: (String?) -> String?,
    onQueryChange: (String) -> Unit,
    onSelect: (StoryCard) -> Unit,
    onClear: () -> Unit,
    onSearchAction: () -> Unit,
) {
    val colors = WbTheme.colors
    Section(R.string.add_story_section) {
        val story = state.story
        when {
            story != null -> Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                StoryCover(title = story.title, coverUrl = coverUrl(story.coverPath), modifier = Modifier.width(64.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = story.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = colors.textPrimary,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                    story.authorName?.let {
                        Text(text = it, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary, maxLines = 1)
                    }
                }
                TextButton(onClick = onClear) {
                    Text(text = stringResource(R.string.add_change_story), color = colors.accent)
                }
            }
            state.storyLoading -> SkeletonBlock(Modifier.fillMaxWidth().height(96.dp), MaterialTheme.shapes.medium)
            else -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                WbSearchField(
                    value = state.query,
                    onValueChange = onQueryChange,
                    hint = stringResource(R.string.add_search_hint),
                    onSearch = onSearchAction,
                )
                if (state.storyMissing) {
                    Text(
                        text = stringResource(R.string.add_story_required),
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.error,
                    )
                }
                when {
                    state.searching -> LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth(),
                        color = colors.accent,
                        trackColor = colors.surface,
                    )
                    state.results.isNotEmpty() -> Column {
                        state.results.forEach { card ->
                            PickRow(card = card, coverUrl = coverUrl(card.coverPath), onClick = { onSelect(card) })
                        }
                    }
                    state.searched -> Text(
                        text = stringResource(R.string.add_no_results),
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.textSecondary,
                    )
                }
            }
        }
    }
}

@Composable
private fun PickRow(card: StoryCard, coverUrl: String?, onClick: () -> Unit) {
    val colors = WbTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(role = Role.Button, onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StoryCover(title = card.title, coverUrl = coverUrl, modifier = Modifier.width(40.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = card.title,
                style = MaterialTheme.typography.bodyLarge,
                color = colors.textPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            card.authorName?.let {
                Text(text = it, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary, maxLines = 1)
            }
        }
    }
}

@Composable
private fun RelistenRow(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val colors = WbTheme.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .toggleable(value = checked, role = Role.Switch, onValueChange = onCheckedChange),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = stringResource(R.string.add_relisten),
            style = MaterialTheme.typography.bodyLarge,
            color = colors.textPrimary,
            modifier = Modifier.weight(1f),
        )
        Switch(
            checked = checked,
            onCheckedChange = null, // the whole row is the toggle target
            colors = SwitchDefaults.colors(
                checkedThumbColor = colors.onAccent,
                checkedTrackColor = colors.accent,
                uncheckedThumbColor = colors.textSecondary,
                uncheckedTrackColor = colors.surfaceElevated,
                uncheckedBorderColor = colors.divider,
            ),
        )
    }
}
