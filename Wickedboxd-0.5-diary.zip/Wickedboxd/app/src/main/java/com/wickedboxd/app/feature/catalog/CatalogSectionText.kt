package com.wickedboxd.app.feature.catalog

import androidx.annotation.StringRes
import com.wickedboxd.app.R
import com.wickedboxd.app.domain.model.CatalogSection

@StringRes
internal fun CatalogSection.titleRes(): Int = when (this) {
    CatalogSection.PopularThisWeek -> R.string.section_popular_week
    CatalogSection.HighestRated -> R.string.section_highest_rated
    CatalogSection.RecentlyAdded -> R.string.section_recent
    CatalogSection.Trending -> R.string.section_trending
    CatalogSection.NewDiscoveries -> R.string.section_new_discoveries
    CatalogSection.MostReviewed -> R.string.section_most_reviewed
}
