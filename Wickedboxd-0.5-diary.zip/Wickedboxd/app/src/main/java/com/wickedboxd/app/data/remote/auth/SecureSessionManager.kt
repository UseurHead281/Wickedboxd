package com.wickedboxd.app.data.remote.auth

import android.content.Context
import io.github.jan.supabase.auth.SessionManager
import io.github.jan.supabase.auth.user.UserSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

/**
 * Stores the Supabase session encrypted (see [KeystoreCipher]). The library default keeps it in plain
 * SharedPreferences. If the stored blob cannot be decrypted it is discarded: the user simply signs in again.
 */
class SecureSessionManager(context: Context) : SessionManager {

    private val prefs = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun saveSession(session: UserSession) = withContext(Dispatchers.IO) {
        val plain = json.encodeToString(UserSession.serializer(), session).toByteArray(Charsets.UTF_8)
        prefs.edit().putString(KEY, KeystoreCipher.encrypt(plain)).apply()
    }

    override suspend fun loadSession(): UserSession? = withContext(Dispatchers.IO) {
        val stored = prefs.getString(KEY, null) ?: return@withContext null
        try {
            json.decodeFromString(UserSession.serializer(), String(KeystoreCipher.decrypt(stored), Charsets.UTF_8))
        } catch (e: Exception) {
            prefs.edit().remove(KEY).apply()
            KeystoreCipher.reset()
            null
        }
    }

    override suspend fun deleteSession() = withContext(Dispatchers.IO) {
        prefs.edit().remove(KEY).apply()
    }

    private companion object {
        const val FILE = "wb_secure_session"
        const val KEY = "session"
    }
}
