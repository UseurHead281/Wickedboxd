package com.wickedboxd.app.data.local

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.wickedboxd.app.domain.model.AccentOption
import com.wickedboxd.app.domain.model.AppIconVariant
import com.wickedboxd.app.domain.model.ThemeMode
import com.wickedboxd.app.domain.model.UserSettings
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

/** Local, per-device appearance settings (theme, accent colour, launcher icon). */
@Singleton
class UserPreferencesRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>,
) {
    val settings: Flow<UserSettings> = dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { prefs ->
            val defaults = UserSettings()
            UserSettings(
                themeMode = prefs[Keys.THEME].toEnum(defaults.themeMode),
                accent = prefs[Keys.ACCENT].toEnum(defaults.accent),
                appIcon = prefs[Keys.APP_ICON].toEnum(defaults.appIcon),
            )
        }

    suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { it[Keys.THEME] = mode.name }
    }

    suspend fun setAccent(accent: AccentOption) {
        dataStore.edit { it[Keys.ACCENT] = accent.name }
    }

    suspend fun setAppIcon(icon: AppIconVariant) {
        dataStore.edit { it[Keys.APP_ICON] = icon.name }
    }

    private object Keys {
        val THEME = stringPreferencesKey("theme_mode")
        val ACCENT = stringPreferencesKey("accent")
        val APP_ICON = stringPreferencesKey("app_icon")
    }
}

private inline fun <reified E : Enum<E>> String?.toEnum(default: E): E =
    enumValues<E>().firstOrNull { it.name == this } ?: default
