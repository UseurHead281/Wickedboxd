package com.wickedboxd.app.core.navigation

import kotlinx.serialization.Serializable

/** Type-safe navigation routes (Navigation Compose 2.8+). Detail routes are added with their screens. */
@Serializable
data object CatalogRoute

@Serializable
data object SearchRoute

/** The modal "log a listen" screen; [storyId] pre-selects a story (from the story page). */
@Serializable
data class AddRoute(val storyId: String? = null)

@Serializable
data object ActivityRoute

@Serializable
data object ProfileRoute

/** Story page. The id is a UUID string, which keeps the route trivially serialisable. */
@Serializable
data class StoryRoute(val storyId: String)

/** "See all" page of a catalogue section; [section] is a CatalogSection enum name. */
@Serializable
data class StoryListRoute(val section: String)

/** Public profile of another user (or yourself, opened from search). */
@Serializable
data class UserRoute(val userId: String)
