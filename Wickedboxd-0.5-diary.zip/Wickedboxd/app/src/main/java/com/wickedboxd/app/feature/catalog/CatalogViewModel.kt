package com.wickedboxd.app.feature.catalog

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wickedboxd.app.core.config.CoverUrlResolver
import com.wickedboxd.app.core.util.ErrorKind
import com.wickedboxd.app.core.util.toErrorKind
import com.wickedboxd.app.domain.model.CatalogSection
import com.wickedboxd.app.domain.model.StoryCard
import com.wickedboxd.app.domain.repository.StoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface SectionState {
    data object Loading : SectionState
    data class Content(val stories: List<StoryCard>) : SectionState
    data class Error(val kind: ErrorKind) : SectionState
}

data class CatalogUiState(
    val sections: Map<CatalogSection, SectionState> = CatalogSection.entries.associateWith { SectionState.Loading },
    val isRefreshing: Boolean = false,
)

@HiltViewModel
class CatalogViewModel @Inject constructor(
    private val stories: StoryRepository,
    private val covers: CoverUrlResolver,
) : ViewModel() {

    private val _state = MutableStateFlow(CatalogUiState())
    val state: StateFlow<CatalogUiState> = _state.asStateFlow()

    private var loadJob: Job? = null

    init {
        load(userInitiated = false)
    }

    fun refresh() = load(userInitiated = true)

    fun coverUrl(path: String?): String? = covers.storyCover(path)

    private fun load(userInitiated: Boolean) {
        if (loadJob?.isActive == true) return
        loadJob = viewModelScope.launch {
            _state.update { current ->
                current.copy(
                    isRefreshing = userInitiated,
                    // sections that failed show their skeleton again while retrying
                    sections = current.sections.mapValues { (_, s) -> if (s is SectionState.Error) SectionState.Loading else s },
                )
            }
            coroutineScope {
                CatalogSection.entries.map { section -> async { loadSection(section) } }.awaitAll()
            }
            _state.update { it.copy(isRefreshing = false) }
        }
    }

    private suspend fun loadSection(section: CatalogSection) {
        val result: SectionState = try {
            SectionState.Content(stories.section(section, SECTION_SIZE))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            SectionState.Error(e.toErrorKind())
        }
        _state.update { current ->
            val previous = current.sections[section]
            // a failed refresh must not wipe what the user is already looking at
            val next = if (result is SectionState.Error && previous is SectionState.Content) previous else result
            current.copy(sections = current.sections + (section to next))
        }
    }

    private companion object {
        const val SECTION_SIZE = 18
    }
}
