package com.wickedboxd.app.feature.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wickedboxd.app.domain.model.AuthError
import com.wickedboxd.app.domain.model.SignUpOutcome
import com.wickedboxd.app.domain.repository.AuthRepository
import com.wickedboxd.app.domain.validation.AuthValidation
import com.wickedboxd.app.domain.validation.PasswordProblem
import com.wickedboxd.app.domain.validation.UsernameProblem
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface UsernameStatus {
    data object Idle : UsernameStatus
    data class Invalid(val problem: UsernameProblem) : UsernameStatus
    data object Checking : UsernameStatus
    data object Available : UsernameStatus
    data object Taken : UsernameStatus

    /** The lookup failed (offline?). Not fatal: the server has the final word when the account is created. */
    data object Unchecked : UsernameStatus
}

data class RegisterUiState(
    val email: String = "",
    val username: String = "",
    val password: String = "",
    val showPassword: Boolean = false,
    val usernameStatus: UsernameStatus = UsernameStatus.Idle,
    val emailInvalid: Boolean = false,
    val passwordProblem: PasswordProblem? = null,
    val isLoading: Boolean = false,
    val error: AuthError? = null,
)

@HiltViewModel
class RegisterViewModel @Inject constructor(
    private val auth: AuthRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(RegisterUiState())
    val state: StateFlow<RegisterUiState> = _state.asStateFlow()

    /** Emits the e-mail address once the account exists but still has to be verified. */
    private val _verification = Channel<String>(Channel.BUFFERED)
    val verification: Flow<String> = _verification.receiveAsFlow()

    private var usernameCheck: Job? = null

    fun onEmailChange(value: String) = _state.update { it.copy(email = value, emailInvalid = false, error = null) }

    fun onPasswordChange(value: String) = _state.update { it.copy(password = value, passwordProblem = null, error = null) }

    fun toggleShowPassword() = _state.update { it.copy(showPassword = !it.showPassword) }

    fun onUsernameChange(raw: String) {
        val value = AuthValidation.normalizeUsername(raw)
        val problem = AuthValidation.usernameProblem(value)
        _state.update {
            it.copy(
                username = value,
                error = null,
                usernameStatus = when {
                    value.isEmpty() -> UsernameStatus.Idle
                    problem != null -> UsernameStatus.Invalid(problem)
                    else -> UsernameStatus.Checking
                },
            )
        }
        usernameCheck?.cancel()
        if (value.isNotEmpty() && problem == null) {
            usernameCheck = viewModelScope.launch {
                delay(USERNAME_DEBOUNCE_MS) // one lookup after the user stops typing, not one per key press
                val status = try {
                    if (auth.isUsernameAvailable(value)) UsernameStatus.Available else UsernameStatus.Taken
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    UsernameStatus.Unchecked
                }
                _state.update { if (it.username == value) it.copy(usernameStatus = status) else it }
            }
        }
    }

    fun submit() {
        val current = _state.value
        if (current.isLoading) return
        val emailOk = AuthValidation.isValidEmail(current.email)
        val usernameProblem = AuthValidation.usernameProblem(current.username)
        val passwordProblem = AuthValidation.passwordProblem(current.password)
        val usernameBlocked = current.usernameStatus is UsernameStatus.Taken || current.usernameStatus is UsernameStatus.Checking
        if (!emailOk || usernameProblem != null || passwordProblem != null || usernameBlocked) {
            _state.update {
                it.copy(
                    emailInvalid = !emailOk,
                    passwordProblem = passwordProblem,
                    usernameStatus = usernameProblem?.let { p -> UsernameStatus.Invalid(p) } ?: it.usernameStatus,
                )
            }
            return
        }
        _state.update { it.copy(isLoading = true, error = null) }
        viewModelScope.launch {
            var outcome: SignUpOutcome? = null
            val error = runAuth { outcome = auth.signUp(current.email, current.password, current.username) }
            _state.update {
                it.copy(
                    isLoading = false,
                    error = error,
                    usernameStatus = if (error == AuthError.UsernameTaken) UsernameStatus.Taken else it.usernameStatus,
                )
            }
            if (error == null && outcome == SignUpOutcome.VerificationRequired) {
                _verification.send(AuthValidation.normalizeEmail(current.email))
            }
            // SignedIn needs no navigation: the app root reacts to AuthState
        }
    }

    private companion object {
        const val USERNAME_DEBOUNCE_MS = 400L
    }
}
