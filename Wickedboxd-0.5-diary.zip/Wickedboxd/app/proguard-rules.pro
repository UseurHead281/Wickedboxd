# Release shrinking is switched on in stage 6. Rules for Supabase/Ktor/serialization go here.
