# Extra icons (authored for Wickedboxd, NOT part of the supplied pack)

The supplied pack has no heart, check, trash, bell, lock, share or shield. These are drawn in the pack's own
style (24x24 viewBox, 1.8 stroke, round caps/joins, `currentColor`) so the app never has to mix in Material icons.
They are converted by the same pipeline (`tools/convert_assets.py`) to `ic_wb_x_<name>.xml`.
Replace any file here with your own SVG of the same name and re-run the pipeline.
