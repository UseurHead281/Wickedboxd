# Wickedboxd — SVG icon pack

22 line icons + 1 branded add-action variant for the Android app.

## Style
- 24 × 24 viewBox
- Outline icons, rounded caps and joins
- `currentColor` for easy tinting in Android / Compose
- Default stroke width: 1.8

## Main bottom navigation
- `01_catalog.svg`
- `02_search.svg`
- `03_add_log.svg` (or `03_add_log_accent.svg` for the green center action)
- `04_activity.svg`
- `05_profile.svg`

## Other UI icons
Reviews, lists, diary, star, bookmark, headphones, follow, settings, edit,
back, chevron, close, filter, calendar, clock, more and warning.

## Android usage
For Jetpack Compose, place the SVG files in `res/drawable` after importing
them as Vector Drawables in Android Studio, or convert them to XML vectors.
For a tintable icon, use the `currentColor` version and apply tint in Compose.

The icon pack is an original visual set inspired by a clean, minimal,
dark social-catalog interface; it is not a copy of Letterboxd's proprietary assets.
