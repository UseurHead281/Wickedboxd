-- =====================================================================================
-- Wickedboxd - 0003: read views and RPC functions
-- Views are `security_invoker`: they run with the CALLER's rights, so Row Level Security of the
-- underlying tables (0004) always applies. Functions that must aggregate across users that RLS hides
-- (popularity, rating distribution) are SECURITY DEFINER and return aggregates only.
-- =====================================================================================

-- ------------------------------------------------------------------ views
create or replace view public.story_cards with (security_invoker = true) as
select
  s.id,
  s.title,
  s.cover_path,
  s.published_year,
  a.name  as author_name,
  n.name  as narrator_name,
  s.avg_rating,
  s.ratings_count,
  s.reviews_count,
  s.logs_count,
  s.created_at,
  exists (select 1 from public.favorites f
          where f.user_id = (select auth.uid()) and f.story_id = s.id)            as is_favorite,
  (select r.rating from public.ratings r
          where r.user_id = (select auth.uid()) and r.story_id = s.id)            as my_rating
from public.stories s
left join public.authors   a on a.id = s.author_id
left join public.narrators n on n.id = s.narrator_id
where s.is_published;                                   -- hidden stories never reach the public catalogue

create or replace view public.story_details with (security_invoker = true) as
select
  c.*,
  s.description,
  s.external_url,
  s.author_id,
  s.narrator_id,
  coalesce((select jsonb_agg(jsonb_build_object('id', g.id, 'slug', g.slug, 'name_ru', g.name_ru, 'name_en', g.name_en)
                             order by g.sort_order, g.name_ru)
            from public.story_genres sg join public.genres g on g.id = sg.genre_id
            where sg.story_id = s.id), '[]'::jsonb)                                    as genres,
  coalesce((select jsonb_agg(jsonb_build_object('id', t.id, 'slug', t.slug, 'name', t.name) order by t.name)
            from public.story_tags st join public.tags t on t.id = st.tag_id
            where st.story_id = s.id), '[]'::jsonb)                                    as tags,
  exists (select 1 from public.want_to_listen w
          where w.user_id = (select auth.uid()) and w.story_id = s.id)                 as is_want_to_listen,
  exists (select 1 from public.listening_logs l
          where l.user_id = (select auth.uid()) and l.story_id = s.id)                 as is_listened
from public.story_cards c
join public.stories s on s.id = c.id;

create or replace view public.review_cards with (security_invoker = true) as
select
  r.id,
  r.story_id,
  r.user_id,
  r.body,
  r.contains_spoilers,
  r.likes_count,
  r.comments_count,
  r.created_at,
  r.updated_at,
  p.username,
  p.display_name,
  p.avatar_path,
  s.title       as story_title,
  s.cover_path  as story_cover_path,
  rt.rating,
  exists (select 1 from public.review_likes l
          where l.user_id = (select auth.uid()) and l.review_id = r.id) as liked_by_me
from public.reviews r
join public.profiles p on p.id = r.user_id
join public.stories  s on s.id = r.story_id and s.is_published
left join public.ratings rt on rt.user_id = r.user_id and rt.story_id = r.story_id;

create or replace view public.list_cards with (security_invoker = true) as
select
  l.id,
  l.owner_id,
  l.title,
  l.description,
  l.cover_path,
  l.visibility,
  l.stories_count,
  l.likes_count,
  l.created_at,
  l.updated_at,
  p.username      as owner_username,
  p.display_name  as owner_display_name,
  p.avatar_path   as owner_avatar_path,
  array(select s.cover_path
        from public.list_stories ls join public.stories s on s.id = ls.story_id
        where ls.list_id = l.id and s.cover_path is not null
        order by ls.position
        limit 4)                                                              as preview_covers,
  exists (select 1 from public.list_likes x
          where x.user_id = (select auth.uid()) and x.list_id = l.id)        as liked_by_me
from public.lists l
join public.profiles p on p.id = l.owner_id;

create or replace view public.diary_entries with (security_invoker = true) as
select
  d.id,
  d.user_id,
  d.story_id,
  d.listened_on,
  d.rating,
  d.note,
  d.is_relisten,
  d.review_id,
  d.created_at,
  s.title       as story_title,
  s.cover_path  as story_cover_path,
  a.name        as author_name
from public.listening_logs d
join public.stories s on s.id = d.story_id and s.is_published
left join public.authors a on a.id = s.author_id;

-- One feed for the three tabs: Following = from_followed_user, Popular = order by engagement, Recent = order by created_at.
create or replace view public.activity_feed with (security_invoker = true) as
select
  a.id,
  a.type,
  a.created_at,
  a.actor_id,
  a.story_id,
  a.review_id,
  a.list_id,
  a.target_user_id,
  p.username      as actor_username,
  p.display_name  as actor_display_name,
  p.avatar_path   as actor_avatar_path,
  s.title         as story_title,
  s.cover_path    as story_cover_path,
  rt.rating,
  l.title         as list_title,
  tp.username     as target_username,
  tp.display_name as target_display_name,
  case a.type
    when 'review' then coalesce(r.likes_count, 0)
    when 'list'   then coalesce(l.likes_count, 0)
    else 0
  end             as engagement,
  exists (select 1 from public.follows f
          where f.follower_id = (select auth.uid()) and f.followee_id = a.actor_id) as from_followed_user
from public.activity a
join public.profiles p on p.id = a.actor_id
left join public.stories  s  on s.id = a.story_id
left join public.ratings  rt on rt.user_id = a.actor_id and rt.story_id = a.story_id and a.type in ('review', 'rating')
left join public.reviews  r  on r.id = a.review_id
left join public.lists    l  on l.id = a.list_id
left join public.profiles tp on tp.id = a.target_user_id;

-- Public identity card of a user (never exposes the role). is_following / is_me are relative to the caller.
create or replace view public.profile_cards with (security_invoker = true) as
select
  p.id,
  p.username,
  p.display_name,
  p.bio,
  p.avatar_path,
  p.website_url,
  p.followers_count,
  p.following_count,
  p.created_at,
  exists (select 1 from public.follows f
          where f.follower_id = (select auth.uid()) and f.followee_id = p.id) as is_following,
  (p.id = (select auth.uid()))                                                 as is_me
from public.profiles p;

create or replace view public.moderation_history with (security_invoker = true) as
select m.id, m.created_at, m.action, m.submission_id, m.story_id, m.details,
       m.admin_id, p.username as admin_username
from public.moderation_log m
left join public.profiles p on p.id = m.admin_id;

-- ------------------------------------------------------------------ username availability (callable before sign-up)
create or replace function public.is_username_available(p_username text)
returns boolean language sql stable security definer set search_path = ''
as $$
  select
        lower(btrim(coalesce(p_username, ''))) ~ '^[a-z0-9_]{3,20}$'
    and lower(btrim(coalesce(p_username, ''))) <> all (array['admin','administrator','moderator','support','wickedboxd','root','system'])
    and not exists (select 1 from public.profiles p where p.username = lower(btrim(coalesce(p_username, ''))));
$$;

-- ------------------------------------------------------------------ search
-- Older 3-argument version (if an earlier migration run created it) would make RPC calls ambiguous.
drop function if exists public.search_stories(text, integer, integer);

-- p_scope: all | title | author | narrator | genre | tag   ("search by category")
create or replace function public.search_stories(
  p_query   text,
  p_limit   integer default 20,
  p_offset  integer default 0,
  p_scope   text    default 'all'
)
returns setof public.story_cards
language plpgsql stable security invoker set search_path = ''
as $$
declare
  v_q   text := btrim(coalesce(p_query, ''));
  v_pat text;
  v_pre text;
begin
  if p_scope is null or p_scope not in ('all', 'title', 'author', 'narrator', 'genre', 'tag') then
    raise exception 'unknown_scope' using errcode = '22023';
  end if;
  if char_length(v_q) < 2 then
    return;
  end if;
  v_pat := '%' || public.escape_like(v_q) || '%';
  v_pre := public.escape_like(v_q) || '%';
  return query
    select c.*
    from public.story_cards c
    where (p_scope in ('all', 'title')    and c.title ilike v_pat)
       or (p_scope in ('all', 'author')   and c.author_name ilike v_pat)
       or (p_scope in ('all', 'narrator') and c.narrator_name ilike v_pat)
       or (p_scope in ('all', 'genre') and exists (
             select 1 from public.story_genres sg join public.genres g on g.id = sg.genre_id
             where sg.story_id = c.id and (g.name_ru ilike v_pat or g.name_en ilike v_pat)))
       or (p_scope in ('all', 'tag') and exists (
             select 1 from public.story_tags st join public.tags t on t.id = st.tag_id
             where st.story_id = c.id and t.name ilike v_pat))
    order by case when c.title ilike v_pre then 0 when c.title ilike v_pat then 1 else 2 end,
             c.ratings_count desc, c.title
    limit least(greatest(coalesce(p_limit, 20), 1), 50)
    offset greatest(coalesce(p_offset, 0), 0);
end $$;

create or replace function public.search_suggestions(p_query text, p_limit integer default 8)
returns table (kind text, label text, ref text)
language plpgsql stable security invoker set search_path = ''
as $$
declare
  v_q   text := btrim(coalesce(p_query, ''));
  v_pat text;
  v_pre text;
begin
  if char_length(v_q) < 2 then
    return;
  end if;
  v_pat := '%' || public.escape_like(v_q) || '%';
  v_pre := public.escape_like(v_q) || '%';
  return query
  select q.kind, q.label, q.ref
  from (
    (select 1 as ord, 'story'::text as kind, c.title as label, c.id::text as ref
       from public.story_cards c where c.title ilike v_pre
       order by c.ratings_count desc, c.title limit 4)
    union all
    (select 2, 'author'::text, a.name, a.id::text
       from public.authors a where a.name ilike v_pat order by a.name limit 2)
    union all
    (select 3, 'narrator'::text, n.name, n.id::text
       from public.narrators n where n.name ilike v_pat order by n.name limit 2)
    union all
    (select 4, 'genre'::text, g.name_ru, g.slug
       from public.genres g where g.name_ru ilike v_pat or g.name_en ilike v_pat order by g.sort_order limit 2)
    union all
    (select 5, 'tag'::text, t.name, t.slug
       from public.tags t where t.name ilike v_pat order by t.name limit 2)
    union all
    (select 6, 'user'::text, p.display_name || ' (@' || p.username || ')', p.id::text
       from public.profiles p where p.username ilike v_pat or p.display_name ilike v_pat
       order by p.followers_count desc, p.username limit 2)
  ) q
  order by q.ord, q.label
  limit least(greatest(coalesce(p_limit, 8), 1), 20);
end $$;

drop function if exists public.search_users(text, integer);

create or replace function public.search_users(p_query text, p_limit integer default 20)
returns setof public.profile_cards
language plpgsql stable security invoker set search_path = ''
as $$
declare
  v_q text := btrim(coalesce(p_query, ''));
  v_u text;
begin
  if char_length(v_q) < 2 then
    return;
  end if;
  v_u := lower(ltrim(v_q, '@'));
  return query
    select c.*
    from public.profile_cards c
    where c.username ilike '%' || public.escape_like(v_u) || '%'
       or c.display_name ilike '%' || public.escape_like(v_q) || '%'
    order by (c.username = v_u) desc, c.followers_count desc, c.username
    limit least(greatest(coalesce(p_limit, 20), 1), 50);
end $$;

create or replace function public.log_search(p_query text)
returns void language plpgsql security invoker set search_path = ''
as $$
declare
  v_q text := lower(btrim(coalesce(p_query, '')));
begin
  if char_length(v_q) between 2 and 80 then
    insert into public.search_log (query) values (v_q);
  end if;
end $$;

-- Anonymous aggregate over the last 14 days; no user ids leave the database.
create or replace function public.popular_searches(p_limit integer default 10)
returns table (query text, searches bigint)
language sql stable security definer set search_path = ''
as $$
  select l.query, count(*)::bigint as searches
  from public.search_log l
  where l.created_at >= now() - interval '14 days'
    and (select auth.uid()) is not null
  group by l.query
  order by count(*) desc, max(l.created_at) desc
  limit least(greatest(coalesce(p_limit, 10), 1), 20);
$$;

-- ------------------------------------------------------------------ catalogue sections
-- p_section: recent | highest_rated | most_reviewed | popular_week | trending | new_discoveries
-- SECURITY DEFINER so popularity counts every user's activity (aggregates only); the result is
-- still limited to published stories by the story_cards view, and per-user flags use auth.uid().
create or replace function public.catalog_section(p_section text, p_limit integer default 18, p_offset integer default 0)
returns setof public.story_cards
language plpgsql stable security definer set search_path = ''
as $$
declare
  v_uid    uuid := (select auth.uid());
  v_limit  integer := least(greatest(coalesce(p_limit, 18), 1), 60);
  v_offset integer := greatest(coalesce(p_offset, 0), 0);
begin
  if v_uid is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;

  if p_section = 'recent' then
    return query
      select c.* from public.story_cards c
      order by c.created_at desc, c.id
      limit v_limit offset v_offset;

  elsif p_section = 'highest_rated' then
    -- Bayesian average (prior: 3.0 stars worth 5 votes) so one lucky 5-star vote cannot top the chart
    return query
      select c.* from public.story_cards c
      where c.ratings_count > 0
      order by ((c.avg_rating * c.ratings_count + 15.0) / (c.ratings_count + 5)) desc, c.ratings_count desc, c.id
      limit v_limit offset v_offset;

  elsif p_section = 'most_reviewed' then
    return query
      select c.* from public.story_cards c
      where c.reviews_count > 0
      order by c.reviews_count desc, c.ratings_count desc, c.id
      limit v_limit offset v_offset;

  elsif p_section = 'popular_week' then
    return query
      with ev as (
        select l.story_id from public.listening_logs l where l.created_at >= now() - interval '7 days'
        union all
        select r.story_id from public.ratings r where r.created_at >= now() - interval '7 days'
        union all
        select v.story_id from public.reviews v where v.created_at >= now() - interval '7 days'
      ),
      score as (select e.story_id, count(*) as n from ev e group by e.story_id)
      select c.* from public.story_cards c
      join score on score.story_id = c.id
      order by score.n desc, c.ratings_count desc, c.id
      limit v_limit offset v_offset;

  elsif p_section = 'trending' then
    -- momentum: events in the last 3 days minus events in the 3 days before
    return query
      with ev as (
        select l.story_id, l.created_at from public.listening_logs l where l.created_at >= now() - interval '6 days'
        union all
        select r.story_id, r.created_at from public.ratings r where r.created_at >= now() - interval '6 days'
        union all
        select v.story_id, v.created_at from public.reviews v where v.created_at >= now() - interval '6 days'
      ),
      score as (
        select e.story_id,
               count(*) filter (where e.created_at >= now() - interval '3 days')
             - count(*) filter (where e.created_at <  now() - interval '3 days') as momentum,
               count(*) as n
        from ev e group by e.story_id
      )
      select c.* from public.story_cards c
      join score on score.story_id = c.id
      where score.momentum > 0
      order by score.momentum desc, score.n desc, c.id
      limit v_limit offset v_offset;

  elsif p_section = 'new_discoveries' then
    -- well-rated stories this user has not logged yet
    return query
      select c.* from public.story_cards c
      where c.ratings_count > 0
        and not exists (select 1 from public.listening_logs l where l.user_id = v_uid and l.story_id = c.id)
      order by ((c.avg_rating * c.ratings_count + 15.0) / (c.ratings_count + 5)) desc, c.ratings_count desc, c.id
      limit v_limit offset v_offset;

  else
    raise exception 'unknown_section' using errcode = '22023';
  end if;
end $$;

-- ------------------------------------------------------------------ rating statistics
create or replace function public.story_rating_distribution(p_story_id uuid)
returns table (rating numeric, votes bigint)
language sql stable security definer set search_path = ''
as $$
  select r.rating::numeric, count(*)::bigint
  from public.ratings r
  join public.stories s on s.id = r.story_id and s.is_published
  where r.story_id = p_story_id and (select auth.uid()) is not null
  group by r.rating
  order by r.rating;
$$;

-- Respects privacy automatically: invoker rights + RLS return only what the caller may see.
create or replace function public.profile_stats(p_user_id uuid)
returns table (stories_listened bigint, total_listens bigint, average_rating numeric,
               reviews_count bigint, lists_count bigint, favorites_count bigint)
language sql stable security invoker set search_path = ''
as $$
  select
    (select count(distinct l.story_id) from public.listening_logs l where l.user_id = p_user_id),
    (select count(*)                   from public.listening_logs l where l.user_id = p_user_id),
    (select round(avg(r.rating), 2)    from public.ratings r        where r.user_id = p_user_id),
    (select count(*)                   from public.reviews v        where v.user_id = p_user_id),
    (select count(*)                   from public.lists x          where x.owner_id = p_user_id),
    (select count(*)                   from public.favorites f      where f.user_id = p_user_id);
$$;

create or replace function public.profile_rating_distribution(p_user_id uuid)
returns table (rating numeric, votes bigint)
language sql stable security invoker set search_path = ''
as $$
  select r.rating::numeric, count(*)::bigint
  from public.ratings r
  where r.user_id = p_user_id
  group by r.rating
  order by r.rating;
$$;

-- ------------------------------------------------------------------ diary
-- Logs one listen. Runs with the caller's rights, so RLS still decides what is allowed.
-- Each call creates a NEW diary entry (repeat listens are separate rows); the rating and the
-- review are upserted because a user has exactly one current rating / review per story.
create or replace function public.log_listen(
  p_story_id     uuid,
  p_listened_on  date    default null,
  p_rating       numeric default null,
  p_note         text    default null,
  p_review_body  text    default null,
  p_is_relisten  boolean default false
) returns uuid
language plpgsql security invoker set search_path = ''
as $$
declare
  v_uid       uuid := (select auth.uid());
  v_review_id uuid;
  v_log_id    uuid;
begin
  if v_uid is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  if not exists (select 1 from public.stories s where s.id = p_story_id and s.is_published) then
    raise exception 'story_not_found' using errcode = 'P0002';
  end if;

  if p_rating is not null then
    insert into public.ratings (user_id, story_id, rating)
    values (v_uid, p_story_id, p_rating)
    on conflict (user_id, story_id) do update set rating = excluded.rating;
  end if;

  if nullif(btrim(coalesce(p_review_body, '')), '') is not null then
    insert into public.reviews (user_id, story_id, body)
    values (v_uid, p_story_id, btrim(p_review_body))
    on conflict (user_id, story_id) do update set body = excluded.body
    returning id into v_review_id;
  end if;

  insert into public.listening_logs (user_id, story_id, listened_on, rating, note, review_id, is_relisten)
  values (v_uid, p_story_id, coalesce(p_listened_on, current_date), p_rating,
          nullif(btrim(coalesce(p_note, '')), ''), v_review_id, coalesce(p_is_relisten, false))
  returning id into v_log_id;

  delete from public.want_to_listen w where w.user_id = v_uid and w.story_id = p_story_id;
  return v_log_id;
end $$;

-- ------------------------------------------------------------------ story actions (idempotent, caller's rights + RLS)
create or replace function public.set_rating(p_story_id uuid, p_rating numeric)
returns void language plpgsql security invoker set search_path = ''
as $$
begin
  if (select auth.uid()) is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  insert into public.ratings (user_id, story_id, rating)
  values ((select auth.uid()), p_story_id, p_rating)
  on conflict (user_id, story_id) do update set rating = excluded.rating;
end $$;

create or replace function public.clear_rating(p_story_id uuid)
returns void language plpgsql security invoker set search_path = ''
as $$
begin
  delete from public.ratings r where r.user_id = (select auth.uid()) and r.story_id = p_story_id;
end $$;

create or replace function public.set_favorite(p_story_id uuid, p_favorite boolean)
returns void language plpgsql security invoker set search_path = ''
as $$
begin
  if (select auth.uid()) is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  if p_favorite then
    insert into public.favorites (user_id, story_id) values ((select auth.uid()), p_story_id) on conflict do nothing;
  else
    delete from public.favorites f where f.user_id = (select auth.uid()) and f.story_id = p_story_id;
  end if;
end $$;

create or replace function public.set_want_to_listen(p_story_id uuid, p_want boolean)
returns void language plpgsql security invoker set search_path = ''
as $$
begin
  if (select auth.uid()) is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  if p_want then
    insert into public.want_to_listen (user_id, story_id) values ((select auth.uid()), p_story_id) on conflict do nothing;
  else
    delete from public.want_to_listen w where w.user_id = (select auth.uid()) and w.story_id = p_story_id;
  end if;
end $$;

create or replace function public.set_follow(p_user_id uuid, p_follow boolean)
returns void language plpgsql security invoker set search_path = ''
as $$
begin
  if (select auth.uid()) is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  if p_follow then
    insert into public.follows (follower_id, followee_id) values ((select auth.uid()), p_user_id) on conflict do nothing;
  else
    delete from public.follows f where f.follower_id = (select auth.uid()) and f.followee_id = p_user_id;
  end if;
end $$;

-- ------------------------------------------------------------------ lists
create or replace function public.reorder_list(p_list_id uuid, p_story_ids uuid[])
returns void language plpgsql security invoker set search_path = ''
as $$
declare
  v_count   integer;
  v_updated integer;
begin
  select count(*) into v_count from public.list_stories ls where ls.list_id = p_list_id;
  if p_story_ids is null
     or cardinality(p_story_ids) <> v_count
     or (select count(distinct x) from unnest(p_story_ids) as x) <> v_count then
    raise exception 'invalid_order' using errcode = '22023';
  end if;

  update public.list_stories ls
     set position = o.ord
    from unnest(p_story_ids) with ordinality as o(story_id, ord)
   where ls.list_id = p_list_id and ls.story_id = o.story_id;

  get diagnostics v_updated = row_count;
  if v_updated <> v_count then            -- not the owner (RLS filtered the rows) or unknown story ids
    raise exception 'forbidden_or_invalid_order' using errcode = '42501';
  end if;
end $$;

-- ------------------------------------------------------------------ moderation (admins only, checked on the server)
create or replace function public.approve_submission(
  p_submission_id  uuid,
  p_title          text    default null,
  p_author_name    text    default null,
  p_narrator_name  text    default null,
  p_year           integer default null,
  p_description    text    default null,
  p_genre_slugs    text[]  default null,
  p_tag_names      text[]  default null,
  p_cover_path     text    default null,   -- path inside the public `covers` bucket (admin copies the image first)
  p_external_url   text    default null
) returns uuid
language plpgsql security definer set search_path = ''
as $$
declare
  v_admin      uuid := (select auth.uid());
  v_sub        public.story_submissions%rowtype;
  v_title      text;
  v_author     text;
  v_narrator   text;
  v_genres     text[];
  v_tags       text[];
  v_author_id  uuid;
  v_narr_id    uuid;
  v_story_id   uuid;
  v_genre_id   integer;
  v_tag_id     integer;
  v_slug       text;
  v_tag        text;
begin
  if not public.is_admin() then
    raise exception 'forbidden' using errcode = '42501';
  end if;

  select * into v_sub from public.story_submissions s where s.id = p_submission_id for update;
  if not found then
    raise exception 'submission_not_found' using errcode = 'P0002';
  end if;
  if v_sub.status <> 'pending' then
    raise exception 'submission_already_reviewed' using errcode = '22023';
  end if;
  if p_cover_path is not null
     and (p_cover_path !~ '^[A-Za-z0-9][A-Za-z0-9/_.-]{0,199}$' or position('..' in p_cover_path) > 0) then
    raise exception 'invalid_cover_path' using errcode = '22023';
  end if;

  v_title    := btrim(coalesce(p_title, v_sub.title));
  v_author   := nullif(btrim(coalesce(p_author_name, v_sub.author_name)), '');
  v_narrator := nullif(btrim(coalesce(p_narrator_name, v_sub.narrator_name, '')), '');
  v_genres   := coalesce(p_genre_slugs, v_sub.genre_slugs);
  v_tags     := coalesce(p_tag_names, v_sub.tag_names);

  if v_author is not null then
    select a.id into v_author_id from public.authors a where lower(btrim(a.name)) = lower(v_author);
    if v_author_id is null then
      insert into public.authors (name) values (v_author) returning id into v_author_id;
    end if;
  end if;
  if v_narrator is not null then
    select n.id into v_narr_id from public.narrators n where lower(btrim(n.name)) = lower(v_narrator);
    if v_narr_id is null then
      insert into public.narrators (name) values (v_narrator) returning id into v_narr_id;
    end if;
  end if;

  insert into public.stories (title, author_id, narrator_id, published_year, description, cover_path,
                              external_url, created_by, source_submission_id)
  values (v_title, v_author_id, v_narr_id,
          coalesce(p_year, v_sub.published_year),
          coalesce(p_description, v_sub.description),
          p_cover_path,
          coalesce(p_external_url, v_sub.external_url),
          v_admin, v_sub.id)
  returning id into v_story_id;

  foreach v_slug in array coalesce(v_genres, '{}') loop
    select g.id into v_genre_id from public.genres g where g.slug = lower(btrim(v_slug));
    if v_genre_id is null then
      raise exception 'unknown_genre: %', v_slug using errcode = '22023';
    end if;
    insert into public.story_genres (story_id, genre_id) values (v_story_id, v_genre_id) on conflict do nothing;
  end loop;

  foreach v_tag in array coalesce(v_tags, '{}') loop
    v_slug := regexp_replace(lower(btrim(v_tag)), '\s+', '-', 'g');
    continue when v_slug !~ '^[a-z0-9а-яё-]{2,40}$';
    select t.id into v_tag_id from public.tags t where t.slug = v_slug;
    if v_tag_id is null then
      insert into public.tags (slug, name) values (v_slug, left(btrim(v_tag), 40)) returning id into v_tag_id;
    end if;
    insert into public.story_tags (story_id, tag_id) values (v_story_id, v_tag_id) on conflict do nothing;
  end loop;

  update public.story_submissions s
     set status = 'approved', reviewed_by = v_admin, reviewed_at = now(), story_id = v_story_id, reject_reason = null
   where s.id = v_sub.id;

  insert into public.moderation_log (admin_id, action, submission_id, story_id, details)
  values (v_admin, 'submission_approved', v_sub.id, v_story_id,
          jsonb_build_object('title', v_title, 'submitter_id', v_sub.submitter_id));

  insert into public.notifications (user_id, type, actor_id, story_id, submission_id, message)
  select v_sub.submitter_id, 'submission_approved'::public.notification_type, v_admin, v_story_id, v_sub.id, left(v_title, 200)
  where coalesce((select s.notify_submissions from public.user_settings s where s.user_id = v_sub.submitter_id), true);

  return v_story_id;
end $$;

create or replace function public.reject_submission(p_submission_id uuid, p_reason text)
returns void language plpgsql security definer set search_path = ''
as $$
declare
  v_admin  uuid := (select auth.uid());
  v_sub    public.story_submissions%rowtype;
  v_reason text := nullif(btrim(coalesce(p_reason, '')), '');
begin
  if not public.is_admin() then
    raise exception 'forbidden' using errcode = '42501';
  end if;
  if v_reason is null or char_length(v_reason) > 1000 then
    raise exception 'reason_required' using errcode = '22023';
  end if;

  select * into v_sub from public.story_submissions s where s.id = p_submission_id for update;
  if not found then
    raise exception 'submission_not_found' using errcode = 'P0002';
  end if;
  if v_sub.status <> 'pending' then
    raise exception 'submission_already_reviewed' using errcode = '22023';
  end if;

  update public.story_submissions s
     set status = 'rejected', reviewed_by = v_admin, reviewed_at = now(), reject_reason = v_reason
   where s.id = v_sub.id;

  insert into public.moderation_log (admin_id, action, submission_id, details)
  values (v_admin, 'submission_rejected', v_sub.id,
          jsonb_build_object('title', v_sub.title, 'submitter_id', v_sub.submitter_id, 'reason', v_reason));

  insert into public.notifications (user_id, type, actor_id, submission_id, message)
  select v_sub.submitter_id, 'submission_rejected'::public.notification_type, v_admin, v_sub.id, left(v_sub.title || ': ' || v_reason, 1000)
  where coalesce((select s.notify_submissions from public.user_settings s where s.user_id = v_sub.submitter_id), true);
end $$;

-- ------------------------------------------------------------------ account deletion
-- Deleting the auth user cascades to the profile and to every row the user owns.
-- (The app removes the user's avatar from Storage first.)
create or replace function public.delete_my_account()
returns void language plpgsql security definer set search_path = ''
as $$
declare
  v_uid uuid := (select auth.uid());
begin
  if v_uid is null then
    raise exception 'not_authenticated' using errcode = '28000';
  end if;
  delete from auth.users where id = v_uid;
end $$;
