-- =====================================================================================
-- Wickedboxd - 0002: helper functions and triggers
-- Convention: every SECURITY DEFINER function pins `search_path = ''` and uses schema-qualified names.
-- =====================================================================================

-- ------------------------------------------------------------------ authorisation helpers (used by RLS policies)
-- Admin status comes from the database ONLY (profiles.role), never from the JWT, because
-- user_metadata in a JWT is client-editable.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = ''
as $$
  select exists (select 1 from public.profiles p where p.id = (select auth.uid()) and p.role = 'admin');
$$;

create or replace function public.user_allows_follow(p_user uuid)
returns boolean language sql stable security definer set search_path = ''
as $$
  select coalesce((select s.allow_follow from public.user_settings s where s.user_id = p_user), true);
$$;

create or replace function public.user_shows_following(p_user uuid)
returns boolean language sql stable security definer set search_path = ''
as $$
  select coalesce((select s.show_following from public.user_settings s where s.user_id = p_user), true);
$$;

create or replace function public.user_shows_activity(p_user uuid)
returns boolean language sql stable security definer set search_path = ''
as $$
  select coalesce((select s.show_activity from public.user_settings s where s.user_id = p_user), true);
$$;

-- May the current user see the personal content (ratings, reviews, diary, favourites...) of p_owner?
create or replace function public.can_view_user_content(p_owner uuid)
returns boolean language sql stable security definer set search_path = ''
as $$
  select
    p_owner = (select auth.uid())
    or public.is_admin()
    or exists (
      select 1 from public.user_settings s
      where s.user_id = p_owner
        and (
          s.profile_visibility = 'public'
          or (s.profile_visibility = 'followers' and exists (
                select 1 from public.follows f
                where f.follower_id = (select auth.uid()) and f.followee_id = p_owner))
        )
    );
$$;

-- Escapes %, _ and \ so user input can be used safely inside ILIKE patterns.
create or replace function public.escape_like(p_text text)
returns text language sql immutable set search_path = ''
as $$
  select replace(replace(replace(p_text, '\', '\\'), '%', '\%'), '_', '\_');
$$;

-- ------------------------------------------------------------------ updated_at
create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end $$;

do $$
declare t text;
begin
  foreach t in array array['profiles', 'user_settings', 'ratings', 'reviews', 'review_comments', 'lists', 'story_submissions'] loop
    execute format('drop trigger if exists trg_%1$s_updated on public.%1$I', t);
    execute format('create trigger trg_%1$s_updated before update on public.%1$I for each row execute function public.set_updated_at()', t);
  end loop;
end $$;

-- ------------------------------------------------------------------ sign-up: profile + settings
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
declare
  v_username text := lower(btrim(coalesce(new.raw_user_meta_data ->> 'username', '')));
  v_display  text := coalesce(nullif(btrim(coalesce(new.raw_user_meta_data ->> 'display_name', '')), ''), v_username);
begin
  if v_username !~ '^[a-z0-9_]{3,20}$' then
    raise exception 'invalid_username' using errcode = '22023';
  end if;
  insert into public.profiles (id, username, display_name) values (new.id, v_username, left(v_display, 50));
  insert into public.user_settings (user_id) values (new.id);
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ------------------------------------------------------------------ privilege-escalation guard
-- Second line of defence behind the column-level grants in 0004: a client session
-- (role `authenticated` / `anon`) can never change profiles.role or the counters.
create or replace function public.trg_profiles_guard()
returns trigger language plpgsql set search_path = ''
as $$
begin
  if current_user in ('authenticated', 'anon') and (
       new.role            is distinct from old.role
    or new.followers_count is distinct from old.followers_count
    or new.following_count is distinct from old.following_count
    or new.id              is distinct from old.id
  ) then
    raise exception 'forbidden_profile_change' using errcode = '42501';
  end if;
  return new;
end $$;

drop trigger if exists trg_profiles_guard on public.profiles;
create trigger trg_profiles_guard before update on public.profiles
  for each row execute function public.trg_profiles_guard();

-- ------------------------------------------------------------------ generic +1/-1 counters
-- usage: trg_bump_counter(<parent table>, <counter column>, <fk column in the child row>)
create or replace function public.trg_bump_counter()
returns trigger language plpgsql security definer set search_path = ''
as $$
declare
  v_parent uuid;
  v_delta  integer;
begin
  if tg_op = 'DELETE' then
    v_parent := (to_jsonb(old) ->> tg_argv[2])::uuid;
    v_delta := -1;
  else
    v_parent := (to_jsonb(new) ->> tg_argv[2])::uuid;
    v_delta := 1;
  end if;
  execute format('update public.%I set %I = greatest(%I + %s, 0) where id = $1', tg_argv[0], tg_argv[1], tg_argv[1], v_delta)
    using v_parent;
  return null;
end $$;

do $$
declare r record;
begin
  for r in
    select * from (values
      ('reviews',         'trg_reviews_count',         'stories',  'reviews_count',    'story_id'),
      ('listening_logs',  'trg_logs_count',            'stories',  'logs_count',       'story_id'),
      ('review_likes',    'trg_review_likes_count',    'reviews',  'likes_count',      'review_id'),
      ('review_comments', 'trg_review_comments_count', 'reviews',  'comments_count',   'review_id'),
      ('list_stories',    'trg_list_stories_count',    'lists',    'stories_count',    'list_id'),
      ('list_likes',      'trg_list_likes_count',      'lists',    'likes_count',      'list_id'),
      ('follows',         'trg_followers_count',       'profiles', 'followers_count',  'followee_id'),
      ('follows',         'trg_following_count',       'profiles', 'following_count',  'follower_id')
    ) as v(child, trg, parent, col, fk)
  loop
    execute format('drop trigger if exists %I on public.%I', r.trg, r.child);
    execute format('create trigger %I after insert or delete on public.%I for each row execute function public.trg_bump_counter(%L, %L, %L)',
                   r.trg, r.child, r.parent, r.col, r.fk);
  end loop;
end $$;

-- ratings feed the story's average (count + sum) - always the CURRENT rating of each user
create or replace function public.trg_ratings_aggregate()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    update public.stories set ratings_count = ratings_count + 1, ratings_sum = ratings_sum + new.rating
    where id = new.story_id;
  elsif tg_op = 'UPDATE' then
    update public.stories set ratings_sum = greatest(ratings_sum + (new.rating - old.rating), 0)
    where id = new.story_id;
  else
    update public.stories set ratings_count = greatest(ratings_count - 1, 0), ratings_sum = greatest(ratings_sum - old.rating, 0)
    where id = old.story_id;
  end if;
  return null;
end $$;

drop trigger if exists trg_ratings_aggregate on public.ratings;
create trigger trg_ratings_aggregate after insert or update of rating or delete on public.ratings
  for each row execute function public.trg_ratings_aggregate();

-- ------------------------------------------------------------------ list item position
create or replace function public.trg_list_story_position()
returns trigger language plpgsql set search_path = ''
as $$
begin
  if new.position is null then
    select coalesce(max(ls.position), 0) + 1 into new.position
    from public.list_stories ls where ls.list_id = new.list_id;
  end if;
  return new;
end $$;

drop trigger if exists trg_list_story_position on public.list_stories;
create trigger trg_list_story_position before insert on public.list_stories
  for each row execute function public.trg_list_story_position();

-- ------------------------------------------------------------------ stories: audit trail for admin changes
create or replace function public.trg_stories_before_write()
returns trigger language plpgsql set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    new.created_by := coalesce(new.created_by, (select auth.uid()));
  elsif (new.title, new.author_id, new.narrator_id, new.published_year, new.description, new.cover_path, new.external_url, new.is_published)
        is not distinct from
        (old.title, old.author_id, old.narrator_id, old.published_year, old.description, old.cover_path, old.external_url, old.is_published) then
    new.updated_at := old.updated_at;          -- counter-only update: do not touch updated_at
  else
    new.updated_at := now();
  end if;
  return new;
end $$;

drop trigger if exists trg_stories_before_write on public.stories;
create trigger trg_stories_before_write before insert or update on public.stories
  for each row execute function public.trg_stories_before_write();

create or replace function public.trg_stories_audit()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    insert into public.moderation_log (admin_id, action, story_id, details)
    values ((select auth.uid()), 'story_created', new.id, jsonb_build_object('title', new.title));
  elsif tg_op = 'UPDATE' then
    if (new.title, new.author_id, new.narrator_id, new.published_year, new.description, new.cover_path, new.external_url, new.is_published)
       is distinct from
       (old.title, old.author_id, old.narrator_id, old.published_year, old.description, old.cover_path, old.external_url, old.is_published) then
      insert into public.moderation_log (admin_id, action, story_id, details)
      values ((select auth.uid()), 'story_updated', new.id,
              jsonb_build_object('title', new.title, 'was_published', old.is_published, 'is_published', new.is_published));
    end if;
  else
    insert into public.moderation_log (admin_id, action, story_id, details)
    values ((select auth.uid()), 'story_deleted', old.id, jsonb_build_object('title', old.title));
  end if;
  return null;
end $$;

drop trigger if exists trg_stories_audit on public.stories;
create trigger trg_stories_audit after insert or update or delete on public.stories
  for each row execute function public.trg_stories_audit();

-- ------------------------------------------------------------------ submissions: anti-abuse
create or replace function public.trg_submission_guard()
returns trigger language plpgsql set search_path = ''
as $$
begin
  if (select count(*) from public.story_submissions s
      where s.submitter_id = new.submitter_id and s.status = 'pending') >= 10 then
    raise exception 'too_many_pending_submissions' using errcode = 'P0001';
  end if;
  -- review fields can only ever be set by the moderation functions
  new.status := 'pending';
  new.reviewed_by := null;
  new.reviewed_at := null;
  new.reject_reason := null;
  new.story_id := null;
  return new;
end $$;

drop trigger if exists trg_submission_guard on public.story_submissions;
create trigger trg_submission_guard before insert on public.story_submissions
  for each row execute function public.trg_submission_guard();

-- ------------------------------------------------------------------ activity feed (written ONLY by these triggers)
create or replace function public.trg_review_activity()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  -- a review replaces the "rated" item the same user just produced for the same story
  delete from public.activity
  where actor_id = new.user_id and story_id = new.story_id and type = 'rating'
    and created_at > now() - interval '5 minutes';
  insert into public.activity (actor_id, type, story_id, review_id) values (new.user_id, 'review', new.story_id, new.id);
  return null;
end $$;

drop trigger if exists trg_review_activity on public.reviews;
create trigger trg_review_activity after insert on public.reviews
  for each row execute function public.trg_review_activity();

create or replace function public.trg_rating_activity()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    insert into public.activity (actor_id, type, story_id, rating) values (new.user_id, 'rating', new.story_id, new.rating);
  else
    delete from public.activity where actor_id = old.user_id and story_id = old.story_id and type = 'rating';
  end if;
  return null;
end $$;

drop trigger if exists trg_rating_activity on public.ratings;
create trigger trg_rating_activity after insert or delete on public.ratings
  for each row execute function public.trg_rating_activity();

create or replace function public.trg_list_activity()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  if new.visibility = 'public'
     and not exists (select 1 from public.activity a where a.list_id = new.id and a.type = 'list') then
    insert into public.activity (actor_id, type, list_id) values (new.owner_id, 'list', new.id);
  end if;
  return null;
end $$;

drop trigger if exists trg_list_activity on public.lists;
create trigger trg_list_activity after insert or update of visibility on public.lists
  for each row execute function public.trg_list_activity();

create or replace function public.trg_follow_created()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.activity (actor_id, type, target_user_id) values (new.follower_id, 'follow', new.followee_id);
  if coalesce((select s.notify_new_follower from public.user_settings s where s.user_id = new.followee_id), true) then
    insert into public.notifications (user_id, type, actor_id) values (new.followee_id, 'new_follower', new.follower_id)
    on conflict (user_id, actor_id) where type = 'new_follower' do nothing;
  end if;
  return null;
end $$;

create or replace function public.trg_follow_deleted()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  delete from public.activity where actor_id = old.follower_id and type = 'follow' and target_user_id = old.followee_id;
  return null;
end $$;

drop trigger if exists trg_follow_created on public.follows;
create trigger trg_follow_created after insert on public.follows
  for each row execute function public.trg_follow_created();
drop trigger if exists trg_follow_deleted on public.follows;
create trigger trg_follow_deleted after delete on public.follows
  for each row execute function public.trg_follow_deleted();

-- ------------------------------------------------------------------ notifications (written ONLY by triggers / moderation RPCs)
create or replace function public.trg_review_like_notify()
returns trigger language plpgsql security definer set search_path = ''
as $$
declare
  v_owner uuid;
  v_story uuid;
begin
  select r.user_id, r.story_id into v_owner, v_story from public.reviews r where r.id = new.review_id;
  if v_owner is not null and v_owner <> new.user_id
     and coalesce((select s.notify_likes from public.user_settings s where s.user_id = v_owner), true) then
    insert into public.notifications (user_id, type, actor_id, review_id, story_id)
    values (v_owner, 'review_like', new.user_id, new.review_id, v_story)
    on conflict (user_id, actor_id, review_id) where type = 'review_like' do nothing;
  end if;
  return null;
end $$;

drop trigger if exists trg_review_like_notify on public.review_likes;
create trigger trg_review_like_notify after insert on public.review_likes
  for each row execute function public.trg_review_like_notify();

create or replace function public.trg_review_comment_notify()
returns trigger language plpgsql security definer set search_path = ''
as $$
declare
  v_owner uuid;
  v_story uuid;
begin
  select r.user_id, r.story_id into v_owner, v_story from public.reviews r where r.id = new.review_id;
  if v_owner is not null and v_owner <> new.user_id
     and coalesce((select s.notify_comments from public.user_settings s where s.user_id = v_owner), true) then
    insert into public.notifications (user_id, type, actor_id, review_id, story_id, message)
    values (v_owner, 'review_reply', new.user_id, new.review_id, v_story, left(new.body, 200));
  end if;
  return null;
end $$;

drop trigger if exists trg_review_comment_notify on public.review_comments;
create trigger trg_review_comment_notify after insert on public.review_comments
  for each row execute function public.trg_review_comment_notify();
