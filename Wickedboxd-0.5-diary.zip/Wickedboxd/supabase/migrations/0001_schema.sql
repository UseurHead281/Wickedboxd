-- =====================================================================================
-- Wickedboxd - 0001: schema (enums, tables, constraints, indexes)
-- Run migrations 0001..0006 in order in the Supabase SQL editor (or `supabase db push`).
-- Every statement is idempotent, so a migration can be re-run after fixing an error.
-- =====================================================================================

create extension if not exists pg_trgm with schema extensions;

-- ------------------------------------------------------------------ enums
do $$ begin create type public.user_role           as enum ('user', 'admin');                                   exception when duplicate_object then null; end $$;
do $$ begin create type public.submission_status   as enum ('pending', 'approved', 'rejected');                 exception when duplicate_object then null; end $$;
do $$ begin create type public.visibility_level    as enum ('public', 'followers', 'private');                  exception when duplicate_object then null; end $$;
do $$ begin create type public.activity_type       as enum ('review', 'rating', 'list', 'follow');              exception when duplicate_object then null; end $$;
do $$ begin create type public.notification_type   as enum ('new_follower', 'review_like', 'review_reply', 'submission_approved', 'submission_rejected'); exception when duplicate_object then null; end $$;
do $$ begin create type public.moderation_action   as enum ('submission_approved', 'submission_rejected', 'story_created', 'story_updated', 'story_deleted'); exception when duplicate_object then null; end $$;

-- ------------------------------------------------------------------ profiles & settings
create table if not exists public.profiles (
  id               uuid primary key references auth.users (id) on delete cascade,
  username         text not null,
  display_name     text not null,
  bio              text,
  avatar_path      text,                       -- object path inside the `avatars` bucket
  website_url      text,
  role             public.user_role not null default 'user',   -- changeable ONLY by the project owner (see 0002/0004)
  followers_count  integer not null default 0 check (followers_count >= 0),
  following_count  integer not null default 0 check (following_count >= 0),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  constraint profiles_username_format check (username ~ '^[a-z0-9_]{3,20}$'),
  constraint profiles_username_reserved check (username <> all (array['admin','administrator','moderator','support','wickedboxd','root','system'])),
  constraint profiles_display_name_len check (char_length(btrim(display_name)) between 1 and 50),
  constraint profiles_bio_len check (bio is null or char_length(bio) <= 300),
  constraint profiles_website_format check (website_url is null or (char_length(website_url) <= 200 and website_url ~* '^https?://[^[:space:]]+$')),
  constraint profiles_avatar_len check (avatar_path is null or char_length(avatar_path) <= 300)
);
create unique index if not exists profiles_username_key        on public.profiles (username);
create index        if not exists profiles_username_trgm_idx   on public.profiles using gin (username extensions.gin_trgm_ops);
create index        if not exists profiles_display_trgm_idx    on public.profiles using gin (display_name extensions.gin_trgm_ops);

create table if not exists public.user_settings (
  user_id              uuid primary key references public.profiles (id) on delete cascade,
  profile_visibility   public.visibility_level not null default 'public',
  show_activity        boolean not null default true,    -- appear in other people's activity feeds
  show_following       boolean not null default true,    -- show who I follow / who follows me
  allow_follow         boolean not null default true,    -- accept new followers
  notify_new_follower  boolean not null default true,
  notify_likes         boolean not null default true,
  notify_comments      boolean not null default true,
  notify_submissions   boolean not null default true,
  locale               text not null default 'ru' check (locale in ('ru', 'en')),
  updated_at           timestamptz not null default now()
);

-- ------------------------------------------------------------------ catalogue taxonomy
create table if not exists public.authors (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (char_length(btrim(name)) between 1 and 120),
  created_at  timestamptz not null default now()
);
create unique index if not exists authors_name_key       on public.authors (lower(btrim(name)));
create index        if not exists authors_name_trgm_idx  on public.authors using gin (name extensions.gin_trgm_ops);

create table if not exists public.narrators (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (char_length(btrim(name)) between 1 and 120),
  created_at  timestamptz not null default now()
);
create unique index if not exists narrators_name_key      on public.narrators (lower(btrim(name)));
create index        if not exists narrators_name_trgm_idx on public.narrators using gin (name extensions.gin_trgm_ops);

create table if not exists public.genres (
  id          integer generated always as identity primary key,
  slug        text not null unique check (slug ~ '^[a-z0-9-]{2,40}$'),
  name_ru     text not null check (char_length(name_ru) between 1 and 60),
  name_en     text not null check (char_length(name_en) between 1 and 60),
  sort_order  integer not null default 0
);

create table if not exists public.tags (
  id          integer generated always as identity primary key,
  slug        text not null unique check (slug ~ '^[a-z0-9а-яё-]{2,40}$'),
  name        text not null check (char_length(name) between 1 and 40),
  created_at  timestamptz not null default now()
);
create index if not exists tags_name_trgm_idx on public.tags using gin (name extensions.gin_trgm_ops);

-- ------------------------------------------------------------------ submissions (created before stories for the FK)
create table if not exists public.story_submissions (
  id              uuid primary key default gen_random_uuid(),
  submitter_id    uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  title           text not null check (char_length(btrim(title)) between 1 and 200),
  author_name     text not null check (char_length(btrim(author_name)) between 1 and 120),
  narrator_name   text check (narrator_name is null or char_length(narrator_name) <= 120),
  published_year  smallint check (published_year between 1800 and 2100),
  description     text check (description is null or char_length(description) <= 4000),
  genre_slugs     text[] not null default '{}' check (cardinality(genre_slugs) <= 5),
  tag_names       text[] not null default '{}' check (cardinality(tag_names) <= 10 and char_length(array_to_string(tag_names, ',')) <= 400),
  cover_path      text check (cover_path is null or char_length(cover_path) <= 300),   -- path inside the private `submission-covers` bucket
  external_url    text check (external_url is null or (char_length(external_url) <= 500 and external_url ~* '^https?://[^[:space:]]+$')),
  comment         text check (comment is null or char_length(comment) <= 1000),
  status          public.submission_status not null default 'pending',
  reviewed_by     uuid references public.profiles (id) on delete set null,
  reviewed_at     timestamptz,
  reject_reason   text check (reject_reason is null or char_length(reject_reason) <= 1000),
  story_id        uuid,                                   -- FK added below (stories is created next)
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index if not exists story_submissions_status_idx    on public.story_submissions (status, created_at);
create index if not exists story_submissions_submitter_idx on public.story_submissions (submitter_id, created_at desc);

-- ------------------------------------------------------------------ stories
create table if not exists public.stories (
  id                    uuid primary key default gen_random_uuid(),
  title                 text not null check (char_length(btrim(title)) between 1 and 200),
  author_id             uuid references public.authors (id) on delete set null,
  narrator_id           uuid references public.narrators (id) on delete set null,
  published_year        smallint check (published_year between 1800 and 2100),
  description           text check (description is null or char_length(description) <= 4000),
  cover_path            text check (cover_path is null or char_length(cover_path) <= 300),   -- path inside the public `covers` bucket
  external_url          text check (external_url is null or (char_length(external_url) <= 500 and external_url ~* '^https?://[^[:space:]]+$')),
  is_published          boolean not null default true,   -- false = hidden by an admin
  created_by            uuid references public.profiles (id) on delete set null,
  source_submission_id  uuid,                            -- FK added below
  -- denormalised aggregates, maintained ONLY by triggers (clients have no write access to them)
  ratings_count         integer not null default 0 check (ratings_count >= 0),
  ratings_sum           numeric(12,1) not null default 0 check (ratings_sum >= 0),
  avg_rating            numeric(3,2) generated always as (case when ratings_count > 0 then round(ratings_sum / ratings_count, 2) end) stored,
  reviews_count         integer not null default 0 check (reviews_count >= 0),
  logs_count            integer not null default 0 check (logs_count >= 0),   -- "added to diaries"
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);
create index if not exists stories_created_idx      on public.stories (created_at desc) where is_published;
create index if not exists stories_author_idx       on public.stories (author_id);
create index if not exists stories_narrator_idx     on public.stories (narrator_id);
create index if not exists stories_avg_rating_idx   on public.stories (avg_rating desc nulls last) where is_published;
create index if not exists stories_reviews_idx      on public.stories (reviews_count desc) where is_published;
create index if not exists stories_title_trgm_idx   on public.stories using gin (title extensions.gin_trgm_ops);

do $$ begin
  alter table public.stories add constraint stories_source_submission_fk
    foreign key (source_submission_id) references public.story_submissions (id) on delete set null;
exception when duplicate_object then null; end $$;
do $$ begin
  alter table public.story_submissions add constraint story_submissions_story_fk
    foreign key (story_id) references public.stories (id) on delete set null;
exception when duplicate_object then null; end $$;

create table if not exists public.story_genres (
  story_id  uuid    not null references public.stories (id) on delete cascade,
  genre_id  integer not null references public.genres (id)  on delete cascade,
  primary key (story_id, genre_id)
);
create index if not exists story_genres_genre_idx on public.story_genres (genre_id, story_id);

create table if not exists public.story_tags (
  story_id  uuid    not null references public.stories (id) on delete cascade,
  tag_id    integer not null references public.tags (id)    on delete cascade,
  primary key (story_id, tag_id)
);
create index if not exists story_tags_tag_idx on public.story_tags (tag_id, story_id);

-- ------------------------------------------------------------------ ratings & reviews
create table if not exists public.ratings (
  user_id     uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  story_id    uuid not null references public.stories (id) on delete cascade,
  rating      numeric(2,1) not null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  primary key (user_id, story_id),                       -- one rating per user per story
  constraint ratings_half_star check (rating between 0.5 and 5.0 and mod(rating * 2, 1) = 0)
);
create index if not exists ratings_story_rating_idx on public.ratings (story_id, rating);

create table if not exists public.reviews (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  story_id           uuid not null references public.stories (id) on delete cascade,
  body               text not null check (char_length(btrim(body)) between 1 and 5000),
  contains_spoilers  boolean not null default false,
  likes_count        integer not null default 0 check (likes_count >= 0),
  comments_count     integer not null default 0 check (comments_count >= 0),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  constraint reviews_one_per_user_story unique (user_id, story_id)   -- one current review, editable
);
create index if not exists reviews_story_idx    on public.reviews (story_id, created_at desc);
create index if not exists reviews_user_idx     on public.reviews (user_id, created_at desc);
create index if not exists reviews_created_idx  on public.reviews (created_at desc);
create index if not exists reviews_likes_idx    on public.reviews (likes_count desc);

create table if not exists public.review_likes (
  user_id     uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  review_id   uuid not null references public.reviews (id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (user_id, review_id)
);
create index if not exists review_likes_review_idx on public.review_likes (review_id);

create table if not exists public.review_comments (
  id          uuid primary key default gen_random_uuid(),
  review_id   uuid not null references public.reviews (id) on delete cascade,
  user_id     uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  body        text not null check (char_length(btrim(body)) between 1 and 1000),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists review_comments_review_idx on public.review_comments (review_id, created_at);

-- ------------------------------------------------------------------ diary
create table if not exists public.listening_logs (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  story_id     uuid not null references public.stories (id) on delete cascade,
  listened_on  date not null default current_date,
  rating       numeric(2,1),                               -- rating given at the time of this listen (snapshot)
  note         text check (note is null or char_length(note) <= 1000),
  review_id    uuid references public.reviews (id) on delete set null,
  is_relisten  boolean not null default false,
  created_at   timestamptz not null default now(),
  -- NO unique constraint on (user_id, story_id): every listen is its own entry
  constraint listening_logs_half_star check (rating is null or (rating between 0.5 and 5.0 and mod(rating * 2, 1) = 0)),
  constraint listening_logs_not_future check (listened_on <= current_date + 1)
);
create index if not exists listening_logs_user_date_idx  on public.listening_logs (user_id, listened_on desc, created_at desc);
create index if not exists listening_logs_story_idx      on public.listening_logs (story_id, created_at desc);
create index if not exists listening_logs_user_story_idx on public.listening_logs (user_id, story_id);
create index if not exists listening_logs_created_idx    on public.listening_logs (created_at desc);

-- ------------------------------------------------------------------ lists
create table if not exists public.lists (
  id             uuid primary key default gen_random_uuid(),
  owner_id       uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  title          text not null check (char_length(btrim(title)) between 1 and 100),
  description    text check (description is null or char_length(description) <= 2000),
  cover_path     text check (cover_path is null or char_length(cover_path) <= 300),   -- optional custom cover in `list-covers`
  visibility     public.visibility_level not null default 'public',
  stories_count  integer not null default 0 check (stories_count between 0 and 500),
  likes_count    integer not null default 0 check (likes_count >= 0),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists lists_owner_idx    on public.lists (owner_id, created_at desc);
create index if not exists lists_created_idx  on public.lists (created_at desc);
create index if not exists lists_likes_idx    on public.lists (likes_count desc);

create table if not exists public.list_stories (
  list_id    uuid    not null references public.lists (id) on delete cascade,
  story_id   uuid    not null references public.stories (id) on delete cascade,
  position   integer not null,
  added_at   timestamptz not null default now(),
  primary key (list_id, story_id),
  constraint list_stories_position_key unique (list_id, position) deferrable initially deferred   -- lets a reorder swap positions in one statement
);
create index if not exists list_stories_story_idx on public.list_stories (story_id);

create table if not exists public.list_likes (
  user_id     uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  list_id     uuid not null references public.lists (id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (user_id, list_id)
);
create index if not exists list_likes_list_idx on public.list_likes (list_id);

-- ------------------------------------------------------------------ social graph, favourites, want-to-listen
create table if not exists public.follows (
  follower_id  uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  followee_id  uuid not null references public.profiles (id) on delete cascade,
  created_at   timestamptz not null default now(),
  primary key (follower_id, followee_id),
  constraint follows_not_self check (follower_id <> followee_id)
);
create index if not exists follows_followee_idx on public.follows (followee_id, created_at desc);

create table if not exists public.favorites (
  user_id     uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  story_id    uuid not null references public.stories (id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (user_id, story_id)
);
create index if not exists favorites_story_idx on public.favorites (story_id);

create table if not exists public.want_to_listen (
  user_id     uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  story_id    uuid not null references public.stories (id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (user_id, story_id)
);
create index if not exists want_to_listen_story_idx on public.want_to_listen (story_id);

-- ------------------------------------------------------------------ activity, notifications, moderation, search
create table if not exists public.activity (
  id              uuid primary key default gen_random_uuid(),
  actor_id        uuid not null references public.profiles (id) on delete cascade,
  type            public.activity_type not null,
  story_id        uuid references public.stories (id) on delete cascade,
  review_id       uuid references public.reviews (id) on delete cascade,
  list_id         uuid references public.lists (id) on delete cascade,
  target_user_id  uuid references public.profiles (id) on delete cascade,
  rating          numeric(2,1),
  created_at      timestamptz not null default now(),
  constraint activity_shape check (
    (type = 'review' and review_id is not null and story_id is not null) or
    (type = 'rating' and story_id is not null and rating is not null) or
    (type = 'list'   and list_id is not null) or
    (type = 'follow' and target_user_id is not null)
  )
);
create index if not exists activity_actor_idx   on public.activity (actor_id, created_at desc);
create index if not exists activity_created_idx on public.activity (created_at desc);
create index if not exists activity_target_idx  on public.activity (target_user_id) where target_user_id is not null;

create table if not exists public.notifications (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references public.profiles (id) on delete cascade,   -- recipient
  type           public.notification_type not null,
  actor_id       uuid references public.profiles (id) on delete set null,
  story_id       uuid references public.stories (id) on delete set null,
  review_id      uuid references public.reviews (id) on delete cascade,
  submission_id  uuid references public.story_submissions (id) on delete set null,
  message        text check (message is null or char_length(message) <= 1000),
  is_read        boolean not null default false,
  created_at     timestamptz not null default now()
);
create index if not exists notifications_user_idx on public.notifications (user_id, is_read, created_at desc);
-- repeated like/unlike or follow/unfollow must not spam the recipient
create unique index if not exists notifications_follower_once on public.notifications (user_id, actor_id) where type = 'new_follower';
create unique index if not exists notifications_like_once     on public.notifications (user_id, actor_id, review_id) where type = 'review_like';

create table if not exists public.moderation_log (
  id             uuid primary key default gen_random_uuid(),
  admin_id       uuid references public.profiles (id) on delete set null,
  action         public.moderation_action not null,
  submission_id  uuid,                                  -- no FKs: the log must survive deletions
  story_id       uuid,
  details        jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now()
);
create index if not exists moderation_log_created_idx on public.moderation_log (created_at desc);
create index if not exists moderation_log_admin_idx   on public.moderation_log (admin_id);

create table if not exists public.search_log (
  id          bigint generated always as identity primary key,
  user_id     uuid not null default auth.uid() references public.profiles (id) on delete cascade,
  query       text not null check (char_length(query) between 2 and 80),
  created_at  timestamptz not null default now()
);
create index if not exists search_log_created_idx on public.search_log (created_at desc);
create index if not exists search_log_query_idx   on public.search_log (query);
