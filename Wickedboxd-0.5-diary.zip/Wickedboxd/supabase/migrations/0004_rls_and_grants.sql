-- =====================================================================================
-- Wickedboxd - 0004: Row Level Security, privileges, column grants
--
-- Security model
--   * `anon` has no access to any table. The only anonymous call is is_username_available().
--   * `authenticated` can touch a row only if an RLS policy allows it AND the column grants allow the write.
--   * Server-managed columns (profiles.role, every counter, submission status/review fields, ...) are NOT
--     in any client column grant, so no policy mistake can make them client-writable.
--   * Admin = profiles.role = 'admin', read from the database by is_admin(). The role can only be changed
--     by the project owner (SQL editor / service_role), see supabase/admin/grant_admin.sql.
--   * Policies use (select auth.uid()) so Postgres evaluates it once per statement.
-- =====================================================================================

-- ------------------------------------------------------------------ baseline privileges
revoke all on all tables    in schema public from anon;
revoke all on all sequences in schema public from anon;
revoke truncate, references, trigger on all tables in schema public from authenticated;
grant usage on schema public to anon, authenticated;
grant select on all tables in schema public to authenticated;       -- rows are still gated by RLS

-- tables created by future migrations must not be readable by anon either
alter default privileges for role postgres in schema public revoke all on tables from anon;

-- ------------------------------------------------------------------ profiles
alter table public.profiles enable row level security;
revoke insert, update, delete on public.profiles from authenticated;
grant update (username, display_name, bio, avatar_path, website_url) on public.profiles to authenticated;

drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles
  for select to authenticated using (true);                      -- identity (name, avatar, bio) is public inside the app

drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles
  for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

-- ------------------------------------------------------------------ user_settings
alter table public.user_settings enable row level security;
revoke insert, update, delete on public.user_settings from authenticated;
grant insert (user_id, profile_visibility, show_activity, show_following, allow_follow,
              notify_new_follower, notify_likes, notify_comments, notify_submissions, locale)
  on public.user_settings to authenticated;
grant update (profile_visibility, show_activity, show_following, allow_follow,
              notify_new_follower, notify_likes, notify_comments, notify_submissions, locale)
  on public.user_settings to authenticated;

drop policy if exists user_settings_select_own on public.user_settings;
create policy user_settings_select_own on public.user_settings
  for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists user_settings_insert_own on public.user_settings;
create policy user_settings_insert_own on public.user_settings
  for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists user_settings_update_own on public.user_settings;
create policy user_settings_update_own on public.user_settings
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

-- ------------------------------------------------------------------ catalogue taxonomy: everyone reads, only admins write
do $$
declare t text;
begin
  foreach t in array array['authors', 'narrators', 'genres', 'tags', 'story_genres', 'story_tags'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('grant insert, update, delete on public.%I to authenticated', t);   -- gated by the admin policies below
    execute format('drop policy if exists %I on public.%I', t || '_select', t);
    execute format('create policy %I on public.%I for select to authenticated using (true)', t || '_select', t);
    execute format('drop policy if exists %I on public.%I', t || '_admin_insert', t);
    execute format('create policy %I on public.%I for insert to authenticated with check (public.is_admin())', t || '_admin_insert', t);
    execute format('drop policy if exists %I on public.%I', t || '_admin_update', t);
    execute format('create policy %I on public.%I for update to authenticated using (public.is_admin()) with check (public.is_admin())', t || '_admin_update', t);
    execute format('drop policy if exists %I on public.%I', t || '_admin_delete', t);
    execute format('create policy %I on public.%I for delete to authenticated using (public.is_admin())', t || '_admin_delete', t);
  end loop;
end $$;

-- ------------------------------------------------------------------ stories
alter table public.stories enable row level security;
revoke insert, update on public.stories from authenticated;
grant delete on public.stories to authenticated;                 -- admin-only through the policy
grant insert (title, author_id, narrator_id, published_year, description, cover_path, external_url, is_published)
  on public.stories to authenticated;
grant update (title, author_id, narrator_id, published_year, description, cover_path, external_url, is_published)
  on public.stories to authenticated;

drop policy if exists stories_select on public.stories;
create policy stories_select on public.stories
  for select to authenticated using (is_published or public.is_admin());
drop policy if exists stories_admin_insert on public.stories;
create policy stories_admin_insert on public.stories
  for insert to authenticated with check (public.is_admin());
drop policy if exists stories_admin_update on public.stories;
create policy stories_admin_update on public.stories
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists stories_admin_delete on public.stories;
create policy stories_admin_delete on public.stories
  for delete to authenticated using (public.is_admin());

-- ------------------------------------------------------------------ story_submissions
-- Pending submissions live ONLY in this table, so they can never leak into the public catalogue.
alter table public.story_submissions enable row level security;
revoke insert, update on public.story_submissions from authenticated;
grant delete on public.story_submissions to authenticated;
grant insert (submitter_id, title, author_name, narrator_name, published_year, description,
              genre_slugs, tag_names, cover_path, external_url, comment)
  on public.story_submissions to authenticated;
grant update (title, author_name, narrator_name, published_year, description,
              genre_slugs, tag_names, cover_path, external_url, comment)
  on public.story_submissions to authenticated;

drop policy if exists submissions_select on public.story_submissions;
create policy submissions_select on public.story_submissions
  for select to authenticated using (submitter_id = (select auth.uid()) or public.is_admin());
drop policy if exists submissions_insert_own on public.story_submissions;
create policy submissions_insert_own on public.story_submissions
  for insert to authenticated with check (submitter_id = (select auth.uid()));
drop policy if exists submissions_update_own_pending on public.story_submissions;
create policy submissions_update_own_pending on public.story_submissions
  for update to authenticated
  using (submitter_id = (select auth.uid()) and status = 'pending')
  with check (submitter_id = (select auth.uid()) and status = 'pending');
drop policy if exists submissions_admin_update on public.story_submissions;
create policy submissions_admin_update on public.story_submissions
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists submissions_delete on public.story_submissions;
create policy submissions_delete on public.story_submissions
  for delete to authenticated
  using ((submitter_id = (select auth.uid()) and status = 'pending') or public.is_admin());

-- ------------------------------------------------------------------ ratings
alter table public.ratings enable row level security;
revoke insert, update on public.ratings from authenticated;
grant delete on public.ratings to authenticated;
grant insert (user_id, story_id, rating) on public.ratings to authenticated;
grant update (rating) on public.ratings to authenticated;

drop policy if exists ratings_select on public.ratings;
create policy ratings_select on public.ratings
  for select to authenticated using (public.can_view_user_content(user_id));
drop policy if exists ratings_insert_own on public.ratings;
create policy ratings_insert_own on public.ratings
  for insert to authenticated
  with check (user_id = (select auth.uid()) and exists (select 1 from public.stories s where s.id = story_id));
drop policy if exists ratings_update_own on public.ratings;
create policy ratings_update_own on public.ratings
  for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists ratings_delete_own on public.ratings;
create policy ratings_delete_own on public.ratings
  for delete to authenticated using (user_id = (select auth.uid()));

-- ------------------------------------------------------------------ reviews
alter table public.reviews enable row level security;
revoke insert, update on public.reviews from authenticated;
grant delete on public.reviews to authenticated;
grant insert (user_id, story_id, body, contains_spoilers) on public.reviews to authenticated;
grant update (body, contains_spoilers) on public.reviews to authenticated;

drop policy if exists reviews_select on public.reviews;
create policy reviews_select on public.reviews
  for select to authenticated using (public.can_view_user_content(user_id));
drop policy if exists reviews_insert_own on public.reviews;
create policy reviews_insert_own on public.reviews
  for insert to authenticated
  with check (user_id = (select auth.uid()) and exists (select 1 from public.stories s where s.id = story_id));
drop policy if exists reviews_update_own on public.reviews;
create policy reviews_update_own on public.reviews
  for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists reviews_delete_own_or_admin on public.reviews;
create policy reviews_delete_own_or_admin on public.reviews
  for delete to authenticated using (user_id = (select auth.uid()) or public.is_admin());

-- ------------------------------------------------------------------ review likes / comments
alter table public.review_likes enable row level security;
revoke insert, update on public.review_likes from authenticated;
grant delete on public.review_likes to authenticated;
grant insert (user_id, review_id) on public.review_likes to authenticated;

drop policy if exists review_likes_select_own on public.review_likes;
create policy review_likes_select_own on public.review_likes
  for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists review_likes_insert_own on public.review_likes;
create policy review_likes_insert_own on public.review_likes
  for insert to authenticated
  with check (user_id = (select auth.uid()) and exists (select 1 from public.reviews r where r.id = review_id));
drop policy if exists review_likes_delete_own on public.review_likes;
create policy review_likes_delete_own on public.review_likes
  for delete to authenticated using (user_id = (select auth.uid()));

alter table public.review_comments enable row level security;
revoke insert, update on public.review_comments from authenticated;
grant delete on public.review_comments to authenticated;
grant insert (review_id, user_id, body) on public.review_comments to authenticated;
grant update (body) on public.review_comments to authenticated;

drop policy if exists review_comments_select on public.review_comments;
create policy review_comments_select on public.review_comments
  for select to authenticated using (exists (select 1 from public.reviews r where r.id = review_id));
drop policy if exists review_comments_insert_own on public.review_comments;
create policy review_comments_insert_own on public.review_comments
  for insert to authenticated
  with check (user_id = (select auth.uid()) and exists (select 1 from public.reviews r where r.id = review_id));
drop policy if exists review_comments_update_own on public.review_comments;
create policy review_comments_update_own on public.review_comments
  for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists review_comments_delete on public.review_comments;
create policy review_comments_delete on public.review_comments
  for delete to authenticated
  using (user_id = (select auth.uid())
         or public.is_admin()
         or exists (select 1 from public.reviews r where r.id = review_id and r.user_id = (select auth.uid())));

-- ------------------------------------------------------------------ diary
alter table public.listening_logs enable row level security;
revoke insert, update on public.listening_logs from authenticated;
grant delete on public.listening_logs to authenticated;
grant insert (user_id, story_id, listened_on, rating, note, review_id, is_relisten) on public.listening_logs to authenticated;
grant update (listened_on, rating, note, review_id, is_relisten) on public.listening_logs to authenticated;

drop policy if exists listening_logs_select on public.listening_logs;
create policy listening_logs_select on public.listening_logs
  for select to authenticated using (public.can_view_user_content(user_id));
drop policy if exists listening_logs_insert_own on public.listening_logs;
create policy listening_logs_insert_own on public.listening_logs
  for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and exists (select 1 from public.stories s where s.id = story_id)
    and (review_id is null or exists (select 1 from public.reviews r where r.id = review_id and r.user_id = (select auth.uid())))
  );
drop policy if exists listening_logs_update_own on public.listening_logs;
create policy listening_logs_update_own on public.listening_logs
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (
    user_id = (select auth.uid())
    and (review_id is null or exists (select 1 from public.reviews r where r.id = review_id and r.user_id = (select auth.uid())))
  );
drop policy if exists listening_logs_delete_own on public.listening_logs;
create policy listening_logs_delete_own on public.listening_logs
  for delete to authenticated using (user_id = (select auth.uid()));

-- ------------------------------------------------------------------ lists
alter table public.lists enable row level security;
revoke insert, update on public.lists from authenticated;
grant delete on public.lists to authenticated;
grant insert (owner_id, title, description, cover_path, visibility) on public.lists to authenticated;
grant update (title, description, cover_path, visibility) on public.lists to authenticated;

drop policy if exists lists_select on public.lists;
create policy lists_select on public.lists
  for select to authenticated
  using (
    owner_id = (select auth.uid())
    or public.is_admin()
    or (
      public.can_view_user_content(owner_id)
      and (
        visibility = 'public'
        or (visibility = 'followers' and exists (
              select 1 from public.follows f
              where f.follower_id = (select auth.uid()) and f.followee_id = owner_id))
      )
    )
  );
drop policy if exists lists_insert_own on public.lists;
create policy lists_insert_own on public.lists
  for insert to authenticated with check (owner_id = (select auth.uid()));
drop policy if exists lists_update_own on public.lists;
create policy lists_update_own on public.lists
  for update to authenticated
  using (owner_id = (select auth.uid())) with check (owner_id = (select auth.uid()));
drop policy if exists lists_delete_own_or_admin on public.lists;
create policy lists_delete_own_or_admin on public.lists
  for delete to authenticated using (owner_id = (select auth.uid()) or public.is_admin());

alter table public.list_stories enable row level security;
revoke insert, update on public.list_stories from authenticated;
grant delete on public.list_stories to authenticated;
grant insert (list_id, story_id, position) on public.list_stories to authenticated;
grant update (position) on public.list_stories to authenticated;

drop policy if exists list_stories_select on public.list_stories;
create policy list_stories_select on public.list_stories
  for select to authenticated using (exists (select 1 from public.lists l where l.id = list_id));
drop policy if exists list_stories_insert_owner on public.list_stories;
create policy list_stories_insert_owner on public.list_stories
  for insert to authenticated
  with check (exists (select 1 from public.lists l where l.id = list_id and l.owner_id = (select auth.uid()))
              and exists (select 1 from public.stories s where s.id = story_id));
drop policy if exists list_stories_update_owner on public.list_stories;
create policy list_stories_update_owner on public.list_stories
  for update to authenticated
  using (exists (select 1 from public.lists l where l.id = list_id and l.owner_id = (select auth.uid())))
  with check (exists (select 1 from public.lists l where l.id = list_id and l.owner_id = (select auth.uid())));
drop policy if exists list_stories_delete_owner on public.list_stories;
create policy list_stories_delete_owner on public.list_stories
  for delete to authenticated
  using (exists (select 1 from public.lists l where l.id = list_id and l.owner_id = (select auth.uid())));

alter table public.list_likes enable row level security;
revoke insert, update on public.list_likes from authenticated;
grant delete on public.list_likes to authenticated;
grant insert (user_id, list_id) on public.list_likes to authenticated;

drop policy if exists list_likes_select_own on public.list_likes;
create policy list_likes_select_own on public.list_likes
  for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists list_likes_insert_own on public.list_likes;
create policy list_likes_insert_own on public.list_likes
  for insert to authenticated
  with check (user_id = (select auth.uid()) and exists (select 1 from public.lists l where l.id = list_id));
drop policy if exists list_likes_delete_own on public.list_likes;
create policy list_likes_delete_own on public.list_likes
  for delete to authenticated using (user_id = (select auth.uid()));

-- ------------------------------------------------------------------ follows
alter table public.follows enable row level security;
revoke insert, update on public.follows from authenticated;
grant delete on public.follows to authenticated;
grant insert (follower_id, followee_id) on public.follows to authenticated;

drop policy if exists follows_select on public.follows;
create policy follows_select on public.follows
  for select to authenticated
  using (follower_id = (select auth.uid())
         or followee_id = (select auth.uid())
         or public.user_shows_following(follower_id));
drop policy if exists follows_insert_own on public.follows;
create policy follows_insert_own on public.follows
  for insert to authenticated
  with check (follower_id = (select auth.uid())
              and followee_id <> (select auth.uid())
              and public.user_allows_follow(followee_id));
drop policy if exists follows_delete_own on public.follows;
create policy follows_delete_own on public.follows
  for delete to authenticated using (follower_id = (select auth.uid()));

-- ------------------------------------------------------------------ favourites & want-to-listen
do $$
declare t text;
begin
  foreach t in array array['favorites', 'want_to_listen'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke insert, update on public.%I from authenticated', t);
    execute format('grant delete on public.%I to authenticated', t);
    execute format('grant insert (user_id, story_id) on public.%I to authenticated', t);

    execute format('drop policy if exists %I on public.%I', t || '_select', t);
    execute format('create policy %I on public.%I for select to authenticated using (public.can_view_user_content(user_id))', t || '_select', t);
    execute format('drop policy if exists %I on public.%I', t || '_insert_own', t);
    execute format($f$create policy %I on public.%I for insert to authenticated
                      with check (user_id = (select auth.uid()) and exists (select 1 from public.stories s where s.id = story_id))$f$,
                   t || '_insert_own', t);
    execute format('drop policy if exists %I on public.%I', t || '_delete_own', t);
    execute format('create policy %I on public.%I for delete to authenticated using (user_id = (select auth.uid()))', t || '_delete_own', t);
  end loop;
end $$;

-- ------------------------------------------------------------------ activity (read-only for clients; written by triggers)
alter table public.activity enable row level security;
revoke insert, update, delete on public.activity from authenticated;

drop policy if exists activity_select on public.activity;
create policy activity_select on public.activity
  for select to authenticated
  using (
    actor_id = (select auth.uid())
    or public.is_admin()
    or (
      public.user_shows_activity(actor_id)
      and public.can_view_user_content(actor_id)
      and (type <> 'list' or exists (select 1 from public.lists l where l.id = list_id))
    )
  );

-- ------------------------------------------------------------------ notifications (clients may only mark as read / delete their own)
alter table public.notifications enable row level security;
revoke insert, update on public.notifications from authenticated;
grant delete on public.notifications to authenticated;
grant update (is_read) on public.notifications to authenticated;

drop policy if exists notifications_select_own on public.notifications;
create policy notifications_select_own on public.notifications
  for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists notifications_update_own on public.notifications;
create policy notifications_update_own on public.notifications
  for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists notifications_delete_own on public.notifications;
create policy notifications_delete_own on public.notifications
  for delete to authenticated using (user_id = (select auth.uid()));

-- ------------------------------------------------------------------ moderation log (admins read; written only by definer code)
alter table public.moderation_log enable row level security;
revoke insert, update, delete on public.moderation_log from authenticated;

drop policy if exists moderation_log_admin_select on public.moderation_log;
create policy moderation_log_admin_select on public.moderation_log
  for select to authenticated using (public.is_admin());

-- ------------------------------------------------------------------ search log (insert only; read through popular_searches())
alter table public.search_log enable row level security;
revoke select, insert, update, delete on public.search_log from authenticated;
grant insert (user_id, query) on public.search_log to authenticated;

drop policy if exists search_log_insert_own on public.search_log;
create policy search_log_insert_own on public.search_log
  for insert to authenticated with check (user_id = (select auth.uid()));

-- ------------------------------------------------------------------ views are read-only
do $$
declare v text;
begin
  foreach v in array array['story_cards', 'story_details', 'review_cards', 'list_cards',
                           'diary_entries', 'activity_feed', 'moderation_history', 'profile_cards'] loop
    execute format('revoke all on public.%I from authenticated', v);
    execute format('grant select on public.%I to authenticated', v);
  end loop;
end $$;

-- ------------------------------------------------------------------ function privileges
-- Start from nothing, then open exactly what the app needs. Trigger functions get no grants at all.
revoke all on all functions in schema public from public, anon, authenticated;

do $$
declare
  r record;
  v_signed_in text[] := array[
    -- used inside RLS policies / views (evaluated with the caller's privileges)
    'is_admin', 'can_view_user_content', 'user_allows_follow', 'user_shows_following', 'user_shows_activity', 'escape_like',
    -- RPC surface
    'search_stories', 'search_suggestions', 'search_users', 'log_search', 'popular_searches', 'catalog_section',
    'story_rating_distribution', 'profile_stats', 'profile_rating_distribution',
    'log_listen', 'reorder_list', 'approve_submission', 'reject_submission', 'delete_my_account',
    'set_rating', 'clear_rating', 'set_favorite', 'set_want_to_listen', 'set_follow'
  ];
  v_anonymous text[] := array['is_username_available'];
begin
  for r in
    select p.oid::regprocedure as sig, p.proname
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public' and p.prokind = 'f'
  loop
    if r.proname = any (v_signed_in) then
      execute format('grant execute on function %s to authenticated', r.sig);
    elsif r.proname = any (v_anonymous) then
      execute format('grant execute on function %s to anon, authenticated', r.sig);
    end if;
  end loop;
end $$;

-- ------------------------------------------------------------------ guard: every table must have RLS
do $$
declare v_missing text;
begin
  select string_agg(c.relname, ', ') into v_missing
  from pg_class c join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity;
  if v_missing is not null then
    raise exception 'Row Level Security is not enabled on: %', v_missing;
  end if;
end $$;
