-- =====================================================================================
-- Wickedboxd - 0005: Storage buckets and policies
-- Size and type limits are enforced by Storage itself (file_size_limit / allowed_mime_types),
-- so a hacked client cannot upload a 200 MB file or an .exe.
--
--   avatars            public read   users write only to  <their uid>/...
--   covers             public read   ONLY admins write       (story covers)
--   list-covers        public read   users write only to  <their uid>/...
--   submission-covers  PRIVATE       users write to <their uid>/... ; owner + admins read
-- Object names must be unguessable (use a random UUID file name).
-- =====================================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('avatars',           'avatars',           true,  2097152, array['image/jpeg', 'image/png', 'image/webp']),
  ('covers',            'covers',            true,  5242880, array['image/jpeg', 'image/png', 'image/webp']),
  ('list-covers',       'list-covers',       true,  5242880, array['image/jpeg', 'image/png', 'image/webp']),
  ('submission-covers', 'submission-covers', false, 5242880, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update
  set public             = excluded.public,
      file_size_limit    = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- ---------------------------------------------------------------- avatars & list-covers: per-user folder
do $$
declare b text;
begin
  foreach b in array array['avatars', 'list-covers'] loop
    -- upsert uploads need SELECT + INSERT + UPDATE
    execute format('drop policy if exists %I on storage.objects', 'wb_' || b || '_select');
    execute format($f$create policy %I on storage.objects for select to authenticated
                      using (bucket_id = %L and (storage.foldername(name))[1] = (select auth.uid())::text)$f$,
                   'wb_' || b || '_select', b);
    execute format('drop policy if exists %I on storage.objects', 'wb_' || b || '_insert');
    execute format($f$create policy %I on storage.objects for insert to authenticated
                      with check (bucket_id = %L and (storage.foldername(name))[1] = (select auth.uid())::text)$f$,
                   'wb_' || b || '_insert', b);
    execute format('drop policy if exists %I on storage.objects', 'wb_' || b || '_update');
    execute format($f$create policy %I on storage.objects for update to authenticated
                      using (bucket_id = %L and (storage.foldername(name))[1] = (select auth.uid())::text)
                      with check (bucket_id = %L and (storage.foldername(name))[1] = (select auth.uid())::text)$f$,
                   'wb_' || b || '_update', b, b);
    execute format('drop policy if exists %I on storage.objects', 'wb_' || b || '_delete');
    execute format($f$create policy %I on storage.objects for delete to authenticated
                      using (bucket_id = %L and (storage.foldername(name))[1] = (select auth.uid())::text)$f$,
                   'wb_' || b || '_delete', b);
  end loop;
end $$;

-- ---------------------------------------------------------------- covers: admins only
drop policy if exists wb_covers_admin_select on storage.objects;
create policy wb_covers_admin_select on storage.objects
  for select to authenticated using (bucket_id = 'covers' and public.is_admin());
drop policy if exists wb_covers_admin_insert on storage.objects;
create policy wb_covers_admin_insert on storage.objects
  for insert to authenticated with check (bucket_id = 'covers' and public.is_admin());
drop policy if exists wb_covers_admin_update on storage.objects;
create policy wb_covers_admin_update on storage.objects
  for update to authenticated
  using (bucket_id = 'covers' and public.is_admin())
  with check (bucket_id = 'covers' and public.is_admin());
drop policy if exists wb_covers_admin_delete on storage.objects;
create policy wb_covers_admin_delete on storage.objects
  for delete to authenticated using (bucket_id = 'covers' and public.is_admin());

-- ---------------------------------------------------------------- submission-covers: private
drop policy if exists wb_submission_covers_select on storage.objects;
create policy wb_submission_covers_select on storage.objects
  for select to authenticated
  using (bucket_id = 'submission-covers'
         and ((storage.foldername(name))[1] = (select auth.uid())::text or public.is_admin()));
drop policy if exists wb_submission_covers_insert on storage.objects;
create policy wb_submission_covers_insert on storage.objects
  for insert to authenticated
  with check (bucket_id = 'submission-covers' and (storage.foldername(name))[1] = (select auth.uid())::text);
drop policy if exists wb_submission_covers_delete on storage.objects;
create policy wb_submission_covers_delete on storage.objects
  for delete to authenticated
  using (bucket_id = 'submission-covers'
         and ((storage.foldername(name))[1] = (select auth.uid())::text or public.is_admin()));
