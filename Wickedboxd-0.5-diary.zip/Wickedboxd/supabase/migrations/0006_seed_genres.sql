-- =====================================================================================
-- Wickedboxd - 0006: genre taxonomy (production data, editable by admins afterwards)
-- =====================================================================================
insert into public.genres (slug, name_ru, name_en, sort_order) values
  ('creepypasta',          'Крипипаста',            'Creepypasta',          10),
  ('psychological-horror', 'Психологический ужас',  'Psychological horror', 20),
  ('paranormal',           'Паранормальное',        'Paranormal',           30),
  ('mystic',               'Мистика',               'Mystic',               40),
  ('ghost-story',          'Истории с привидениями','Ghost stories',        50),
  ('urban-legend',         'Городские легенды',     'Urban legends',        60),
  ('folk-horror',          'Фолк-хоррор',           'Folk horror',          70),
  ('cosmic-horror',        'Космический ужас',      'Cosmic horror',        80),
  ('gothic',               'Готика',                'Gothic',               90),
  ('slasher',              'Слэшер',                'Slasher',             100),
  ('survival-horror',      'Выживание',             'Survival horror',     110),
  ('body-horror',          'Боди-хоррор',           'Body horror',         120),
  ('post-apocalyptic',     'Постапокалипсис',       'Post-apocalyptic',    130),
  ('sci-fi-horror',        'Научная фантастика',    'Sci-fi horror',       140)
on conflict (slug) do nothing;
