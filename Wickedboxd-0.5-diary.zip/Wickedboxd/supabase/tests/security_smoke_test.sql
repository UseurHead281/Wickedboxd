-- =====================================================================================
-- Wickedboxd - security & integrity smoke test.            USE A DEV PROJECT, NOT PRODUCTION.
--
-- Everything runs in ONE transaction that ends with ROLLBACK, so nothing is left behind.
-- Paste the whole file into the Supabase SQL editor and run it. Read the notices: every line must
-- start with "OK". The first failing check aborts the script with "FAIL ...".
--
-- It impersonates users by setting the same JWT claim PostgREST sets (request.jwt.claims) and
-- switching to the real `authenticated` / `anon` database roles, so RLS and column grants are
-- exercised exactly as they are for the app.
--
-- Note: it inserts two rows into auth.users. If your Supabase version requires more columns there,
-- add them to the insert below.
-- =====================================================================================
begin;

-- ------------------------------------------------------------------ fixtures (as the project owner)
insert into auth.users (id, instance_id, aud, role, email, raw_user_meta_data) values
  ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
   'alice@wickedboxd.test', '{"username":"test_alice"}'),
  ('00000000-0000-0000-0000-0000000000b2', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
   'bob@wickedboxd.test',   '{"username":"test_bob"}');

insert into public.authors (name) values ('[TEST] Author');
insert into public.stories (id, title, author_id)
select 'aaaaaaaa-0000-0000-0000-000000000001', '[TEST] Published story', a.id
from public.authors a where a.name = '[TEST] Author';

do $$
begin
  if (select count(*) from public.profiles where username in ('test_alice', 'test_bob')) <> 2 then
    raise exception 'FAIL setup: sign-up trigger did not create profiles';
  end if;
  if (select count(*) from public.user_settings where user_id in
        ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-0000000000b2')) <> 2 then
    raise exception 'FAIL setup: sign-up trigger did not create user_settings';
  end if;
  raise notice 'OK   setup: profiles and settings created by the sign-up trigger';
end $$;

-- ------------------------------------------------------------------ anonymous access
set local role anon;
do $$
declare v_ok boolean;
begin
  begin
    perform 1 from public.profiles limit 1;
    raise exception 'FAIL anon: anonymous role could read profiles';
  exception when insufficient_privilege then
    raise notice 'OK   anon cannot read tables';
  end;
  select public.is_username_available('free_name_123') into v_ok;
  if v_ok is not true then raise exception 'FAIL anon: is_username_available should be callable and true'; end if;
  select public.is_username_available('test_alice') into v_ok;
  if v_ok is not false then raise exception 'FAIL anon: taken username reported as available'; end if;
  select public.is_username_available('admin') into v_ok;
  if v_ok is not false then raise exception 'FAIL anon: reserved username reported as available'; end if;
  raise notice 'OK   username availability works for anon (free / taken / reserved)';
end $$;
reset role;

-- ------------------------------------------------------------------ alice: a normal user
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}', true);
set local role authenticated;

do $$
begin
  begin
    update public.profiles set role = 'admin' where id = '00000000-0000-0000-0000-0000000000a1';
    raise exception 'FAIL T1: a user changed their own role';
  exception when insufficient_privilege then
    raise notice 'OK   T1 users cannot change profiles.role';
  end;

  begin
    update public.profiles set followers_count = 999 where id = '00000000-0000-0000-0000-0000000000a1';
    raise exception 'FAIL T1b: a user changed a counter';
  exception when insufficient_privilege then
    raise notice 'OK   T1b users cannot write counters';
  end;

  begin
    insert into public.stories (title) values ('[TEST] sneaky story');
    raise exception 'FAIL T2: a non-admin created a story';
  exception when insufficient_privilege then
    raise notice 'OK   T2 non-admins cannot create stories';
  end;

  begin
    update public.stories set ratings_count = 500 where id = 'aaaaaaaa-0000-0000-0000-000000000001';
    raise exception 'FAIL T2b: a non-admin updated a story';
  exception when insufficient_privilege then
    raise notice 'OK   T2b non-admins cannot edit stories';
  end;

  -- submitting is allowed and always lands as pending
  insert into public.story_submissions (id, title, author_name)
  values ('bbbbbbbb-0000-0000-0000-000000000001', '[TEST] Submitted story', '[TEST] New Author');
  if (select status from public.story_submissions where id = 'bbbbbbbb-0000-0000-0000-000000000001') <> 'pending' then
    raise exception 'FAIL T3: submission is not pending';
  end if;
  raise notice 'OK   T3 a user can submit a story; it is pending';

  begin
    insert into public.story_submissions (title, author_name, status) values ('[TEST] x', 'y', 'approved');
    raise exception 'FAIL T4: a user inserted an already approved submission';
  exception when insufficient_privilege then
    raise notice 'OK   T4 users cannot set submission status';
  end;

  begin
    perform public.approve_submission('bbbbbbbb-0000-0000-0000-000000000001');
    raise exception 'FAIL T5: a non-admin approved a submission';
  exception when insufficient_privilege then
    raise notice 'OK   T5 non-admins cannot approve submissions';
  end;

  begin
    insert into public.ratings (user_id, story_id, rating)
    values ('00000000-0000-0000-0000-0000000000b2', 'aaaaaaaa-0000-0000-0000-000000000001', 5);
    raise exception 'FAIL T6: alice rated as bob';
  exception when insufficient_privilege then
    raise notice 'OK   T6 users cannot write rows for someone else';
  end;

  begin
    insert into public.ratings (story_id, rating) values ('aaaaaaaa-0000-0000-0000-000000000001', 4.3);
    raise exception 'FAIL T7: a non half-star rating was accepted';
  exception when check_violation then
    raise notice 'OK   T7 ratings must be in 0.5 steps';
  end;

  insert into public.ratings (story_id, rating) values ('aaaaaaaa-0000-0000-0000-000000000001', 4.0);
  begin
    insert into public.ratings (story_id, rating) values ('aaaaaaaa-0000-0000-0000-000000000001', 4.5);
    raise exception 'FAIL T8: a second rating for the same story was accepted';
  exception when unique_violation then
    raise notice 'OK   T8 one rating per user per story';
  end;

  insert into public.reviews (story_id, body) values ('aaaaaaaa-0000-0000-0000-000000000001', 'first review');
  begin
    insert into public.reviews (story_id, body) values ('aaaaaaaa-0000-0000-0000-000000000001', 'second review');
    raise exception 'FAIL T9: a second review for the same story was accepted';
  exception when unique_violation then
    raise notice 'OK   T9 one current review per user per story';
  end;
end $$;
reset role;

-- ------------------------------------------------------------------ bob: privacy and aggregates
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}', true);
set local role authenticated;

do $$
begin
  if (select count(*) from public.story_submissions) <> 0 then
    raise exception 'FAIL T10: bob can see alice''s pending submission';
  end if;
  raise notice 'OK   T10 pending submissions are invisible to other users';

  insert into public.ratings (story_id, rating) values ('aaaaaaaa-0000-0000-0000-000000000001', 5.0);
  update public.user_settings set profile_visibility = 'private' where user_id = '00000000-0000-0000-0000-0000000000b2';
end $$;
reset role;

do $$
declare s record;
begin
  select ratings_count, avg_rating into s from public.stories where id = 'aaaaaaaa-0000-0000-0000-000000000001';
  if s.ratings_count <> 2 or s.avg_rating <> 4.50 then
    raise exception 'FAIL T11: expected 2 ratings averaging 4.50, got % / %', s.ratings_count, s.avg_rating;
  end if;
  raise notice 'OK   T11 story average is computed from the current ratings (2 ratings, 4.50)';
end $$;

select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}', true);
set local role authenticated;
do $$
begin
  if (select count(*) from public.ratings where user_id = '00000000-0000-0000-0000-0000000000b2') <> 0 then
    raise exception 'FAIL T12: a private profile''s rating is visible to another user';
  end if;
  raise notice 'OK   T12 private profile content is hidden';

  -- aggregates still count private users (the distribution is aggregate-only)
  if (select sum(votes) from public.story_rating_distribution('aaaaaaaa-0000-0000-0000-000000000001')) <> 2 then
    raise exception 'FAIL T13: rating distribution is wrong';
  end if;
  raise notice 'OK   T13 rating distribution counts all users';
end $$;
reset role;

-- ------------------------------------------------------------------ owner promotes alice -> moderation flow
update public.profiles set role = 'admin' where id = '00000000-0000-0000-0000-0000000000a1';

select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}', true);
set local role authenticated;
do $$
declare v_story uuid;
begin
  v_story := public.approve_submission('bbbbbbbb-0000-0000-0000-000000000001');
  if v_story is null then raise exception 'FAIL T14: approve_submission returned no story'; end if;
  if (select status from public.story_submissions where id = 'bbbbbbbb-0000-0000-0000-000000000001') <> 'approved' then
    raise exception 'FAIL T14: submission not marked approved';
  end if;
  if (select count(*) from public.moderation_log where submission_id = 'bbbbbbbb-0000-0000-0000-000000000001') = 0 then
    raise exception 'FAIL T14: moderation history is empty';
  end if;
  raise notice 'OK   T14 an admin can approve; story created; moderation history written';

  begin
    perform public.approve_submission('bbbbbbbb-0000-0000-0000-000000000001');
    raise exception 'FAIL T15: a submission was approved twice';
  exception when invalid_parameter_value then
    raise notice 'OK   T15 a reviewed submission cannot be reviewed again';
  end;
end $$;
reset role;

select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}', true);
set local role authenticated;
do $$
begin
  if (select count(*) from public.story_cards where title = '[TEST] Submitted story') <> 1 then
    raise exception 'FAIL T16: approved story is not in the public catalogue';
  end if;
  raise notice 'OK   T16 approved story appears in the public catalogue';
  if (select count(*) from public.notifications where type = 'submission_approved') <> 0 then
    raise exception 'FAIL T16b: bob received alice''s notification';
  end if;
  begin
    perform 1 from public.moderation_log limit 1;
    if exists (select 1 from public.moderation_log) then raise exception 'FAIL T17: non-admin can read the moderation log'; end if;
    raise notice 'OK   T17 non-admins cannot read the moderation log';
  end;
end $$;
reset role;

-- ------------------------------------------------------------------ diary: unique stories vs total listens
select set_config('request.jwt.claims', '{"sub":"00000000-0000-0000-0000-0000000000a1","role":"authenticated"}', true);
set local role authenticated;
do $$
declare s record;
begin
  perform public.log_listen('aaaaaaaa-0000-0000-0000-000000000001', current_date, 3.5, 'first listen', 'edited review', false);
  perform public.log_listen('aaaaaaaa-0000-0000-0000-000000000001', current_date, null, 'again', null, true);
  select * into s from public.profile_stats('00000000-0000-0000-0000-0000000000a1');
  if s.stories_listened <> 1 or s.total_listens <> 2 then
    raise exception 'FAIL T18: expected 1 unique story / 2 listens, got % / %', s.stories_listened, s.total_listens;
  end if;
  raise notice 'OK   T18 diary keeps every listen; stats separate unique stories from total listens';
  if (select count(*) from public.reviews where user_id = '00000000-0000-0000-0000-0000000000a1') <> 1 then
    raise exception 'FAIL T19: review was duplicated by log_listen';
  end if;
  raise notice 'OK   T19 log_listen edits the single current review instead of duplicating it';
end $$;
reset role;

rollback;   -- leave nothing behind
