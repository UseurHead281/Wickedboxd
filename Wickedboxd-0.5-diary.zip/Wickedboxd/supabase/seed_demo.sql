-- =====================================================================================
-- DEMO DATA - for DEV projects only. NEVER run this on production.
-- Fictional titles, authors and narrators (no real works), all prefixed "[DEMO]" so they are
-- obvious in the UI and trivial to remove (cleanup block at the bottom).
-- Run after migrations 0001-0006, as the project owner in the SQL editor.
-- =====================================================================================

insert into public.authors (name) values
  ('[DEMO] Анна Вельская'), ('[DEMO] Игорь Сомов'), ('[DEMO] Мария Дроздова')
on conflict do nothing;

insert into public.narrators (name) values
  ('[DEMO] Чтец Один'), ('[DEMO] Чтец Два')
on conflict do nothing;

with d (title, author, narrator, yr, descr) as (
  values
    ('[DEMO] Лампа в конце коридора',  '[DEMO] Анна Вельская',   '[DEMO] Чтец Один', 2021, 'Демонстрационная запись для разработки интерфейса. Выдуманный сюжет.'),
    ('[DEMO] Девятый этаж',            '[DEMO] Игорь Сомов',     '[DEMO] Чтец Два',  2019, 'Демонстрационная запись для разработки интерфейса. Выдуманный сюжет.'),
    ('[DEMO] Тихий абонент',           '[DEMO] Мария Дроздова',  '[DEMO] Чтец Один', 2023, 'Демонстрационная запись для разработки интерфейса. Выдуманный сюжет.'),
    ('[DEMO] Дом без окон',            '[DEMO] Анна Вельская',   '[DEMO] Чтец Два',  2020, 'Демонстрационная запись для разработки интерфейса. Выдуманный сюжет.'),
    ('[DEMO] Ночной автобус',          '[DEMO] Игорь Сомов',     '[DEMO] Чтец Один', 2022, 'Демонстрационная запись для разработки интерфейса. Выдуманный сюжет.'),
    ('[DEMO] Письма из подвала',       '[DEMO] Мария Дроздова',  '[DEMO] Чтец Два',  2018, 'Демонстрационная запись для разработки интерфейса. Выдуманный сюжет.'),
    ('[DEMO] Станция Сумеречная',      '[DEMO] Анна Вельская',   '[DEMO] Чтец Один', 2024, 'Демонстрационная запись для разработки интерфейса. Выдуманный сюжет.'),
    ('[DEMO] Эхо в колодце',           '[DEMO] Игорь Сомов',     '[DEMO] Чтец Два',  2017, 'Демонстрационная запись для разработки интерфейса. Выдуманный сюжет.')
)
insert into public.stories (title, author_id, narrator_id, published_year, description)
select d.title, a.id, n.id, d.yr, d.descr
from d
join public.authors   a on a.name = d.author
join public.narrators n on n.name = d.narrator
where not exists (select 1 from public.stories s where s.title = d.title);

insert into public.story_genres (story_id, genre_id)
select s.id, g.id
from (values
  ('[DEMO] Лампа в конце коридора', 'psychological-horror'),
  ('[DEMO] Девятый этаж',           'urban-legend'),
  ('[DEMO] Тихий абонент',          'paranormal'),
  ('[DEMO] Дом без окон',           'gothic'),
  ('[DEMO] Ночной автобус',         'ghost-story'),
  ('[DEMO] Письма из подвала',      'creepypasta'),
  ('[DEMO] Станция Сумеречная',     'cosmic-horror'),
  ('[DEMO] Эхо в колодце',          'folk-horror')
) as m (title, slug)
join public.stories s on s.title = m.title
join public.genres  g on g.slug = m.slug
on conflict do nothing;

insert into public.tags (slug, name) values
  ('неожиданная-концовка', 'неожиданная концовка'),
  ('одиночество',          'одиночество'),
  ('городская-мистика',    'городская мистика')
on conflict (slug) do nothing;

insert into public.story_tags (story_id, tag_id)
select s.id, t.id
from (values
  ('[DEMO] Лампа в конце коридора', 'одиночество'),
  ('[DEMO] Девятый этаж',           'городская-мистика'),
  ('[DEMO] Тихий абонент',          'неожиданная-концовка'),
  ('[DEMO] Ночной автобус',         'городская-мистика')
) as m (title, slug)
join public.stories s on s.title = m.title
join public.tags    t on t.slug = m.slug
on conflict do nothing;

-- ---- cleanup (run when you no longer want the demo content) ----
-- delete from public.stories   where title like '[DEMO]%';
-- delete from public.authors   where name  like '[DEMO]%';
-- delete from public.narrators where name  like '[DEMO]%';
