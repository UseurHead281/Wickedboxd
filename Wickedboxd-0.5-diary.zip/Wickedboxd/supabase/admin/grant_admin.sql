-- =====================================================================================
-- Make a user an administrator.   RUN AS THE PROJECT OWNER in the Supabase SQL editor.
--
-- This is the ONLY way to create an admin. The app cannot do it: the `role` column is not writable
-- by clients (column grants + trigger + RLS), and there is no RPC for it. Never ship a service_role
-- key in the app to "automate" this.
-- =====================================================================================

-- grant
update public.profiles set role = 'admin' where username = 'REPLACE_WITH_USERNAME';

-- revoke
-- update public.profiles set role = 'user' where username = 'REPLACE_WITH_USERNAME';

-- who are the admins right now?
select id, username, display_name, role from public.profiles where role = 'admin';
