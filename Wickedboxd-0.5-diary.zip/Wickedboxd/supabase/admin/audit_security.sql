-- =====================================================================================
-- Security audit queries. Run in the SQL editor after the migrations; every result should be EMPTY
-- (except where a comment says otherwise).
-- =====================================================================================

-- 1) tables without Row Level Security
select c.relname as table_without_rls
from pg_class c join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public' and c.relkind = 'r' and not c.relrowsecurity;

-- 2) RLS enabled but NO policy at all (nobody can read it - fine for logs, a bug elsewhere)
select c.relname as table_without_policies
from pg_class c join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public' and c.relkind = 'r' and c.relrowsecurity
  and not exists (select 1 from pg_policies p where p.schemaname = 'public' and p.tablename = c.relname);

-- 3) anything `anon` can touch in public (expected: only the is_username_available function)
select table_name, privilege_type from information_schema.role_table_grants
where grantee = 'anon' and table_schema = 'public';
select routine_name from information_schema.routine_privileges
where grantee = 'anon' and routine_schema = 'public';

-- 4) columns of sensitive tables that `authenticated` may write (review by eye)
select table_name, column_name, privilege_type
from information_schema.column_privileges
where grantee = 'authenticated' and table_schema = 'public'
  and table_name in ('profiles', 'stories', 'story_submissions') and privilege_type in ('UPDATE', 'INSERT')
order by table_name, privilege_type, column_name;
-- profiles must list ONLY: username, display_name, bio, avatar_path, website_url (UPDATE)
-- `role`, `followers_count`, `following_count`, `status`, `reviewed_by` must NOT appear anywhere.

-- 5) SECURITY DEFINER functions without a pinned search_path (expected: none)
select p.proname
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.prosecdef
  and not exists (select 1 from unnest(coalesce(p.proconfig, '{}')) c where c like 'search_path=%');

-- 6) current admins (expected: only the people you granted)
select username, role from public.profiles where role = 'admin';
